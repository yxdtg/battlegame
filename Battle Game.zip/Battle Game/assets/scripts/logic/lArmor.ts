
/**
 * 盔甲类
 */
export class lArmor {

    public id: number;

    public name: string;

    public type: number;

    /**
     * 护甲值
     */
    public armor: number;

    constructor(id: number, name: string, type: number, armor: number) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.armor = armor;
    }

}
