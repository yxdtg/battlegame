
/**
 * 枪械类
 */
export class lFirearm {

    /**
     * id
     */
    public id: number;

    /**
     * 名称
     */
    public name: string;

    /**
     * 类型
     */
    public type: number;

    /**
     * 自定义类型
     */
    public sType: number;

    /**
     * 攻击类型
     */
    public attackType: number;

    /**
     * 子弹类型
     */
    public bulletType: number;

    /**
     * 子弹数量
     */
    public bulletCount: number;

    /**
     * 子弹上限
     */
    public bulletMaxCount: number;

    /**
     * 攻击力
     */
    public attack: number;

    /**
     * 子弹速度
     */
    public bulletSpeed: number;

    /**
     * 子弹射程
     */
    public bulletRange: number;

    /**
     * 攻击间隔计数
     */
    public attackCount: number;

    /**
     * 攻击最大间隔
     */
    public attackCountMax: number;

    /**
     * 换弹时间计数
     */
    public reloadTime: number;

    /**
     * 最大换弹时间
     */
    public reloadMaxTime: number;

    constructor(id: number, name: string, type: number, sType: number, attackType: number, attack: number, bulletSpeed: number, bulletRange: number, bulletType: number, bulletMaxCount: number, attackCountMax: number, reloadMaxTime: number) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.sType = sType;
        this.attackType = attackType;
        this.attack = attack;
        this.bulletSpeed = bulletSpeed;
        this.bulletRange = bulletRange;
        this.bulletType = bulletType;
        this.bulletCount = 0;
        this.bulletMaxCount = bulletMaxCount;
        this.reloadTime = 0;
        this.reloadMaxTime = reloadMaxTime;
        this.attackCount = 0;
        this.attackCountMax = attackCountMax;
    }

}
