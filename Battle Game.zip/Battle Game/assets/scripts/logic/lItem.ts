
/**
 * 物资类
 */
export class lItem {

    /**
     * id
     */
    public id: number;

    /**
     * 类型
     */
    public type: number;

    /**
     * 名称
     */
    public name: string;

    /**
     * 数量
     */
    public count: number;

    /**
     * x坐标
     */
    public x: number;

    /**
     * y坐标
     */
    public y: number;

    public width: number;

    public height: number;

    /**
     * 自定义属性
     */
    public value: any = undefined;

    constructor(id: number, type: number, name: string, count: number, x: number, y: number) {
        this.id = id;
        this.type = type;
        this.name = name;
        this.count = count;
        this.x = x;
        this.y = y;

        this.width = 120;
        this.height = 120;
    }

}
