
/**
 * 背包类
 */
export class lPack {

    public id: number;

    public name: string;

    public type: number;

    /**
     * 重量
     */
    public weight: number;

    constructor(id: number, name: string, type: number, weight: number) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.weight = weight;
    }

}
