import { Logic } from "../scene/Logic";

/**
 * 烟雾类
 */
export class lSmoke {

    public id: number;

    public x: number;

    public y: number;

    public width: number;

    public height: number;

    public scale: number;

    public count: number;

    public countMax: number;

    public countOver: number;

    constructor(id: number, x: number, y: number, scale: number) {

        let frameRate: number = Logic.instance.frameRate;

        this.id = id;
        this.x = x;
        this.y = y;

        this.width = 100;
        this.height = 100;
        this.scale = scale;

        this.count = 0;
        this.countMax = frameRate * 6;
        this.countOver = frameRate * 4;
    }

}
