
/**
 * 投掷类
 */
export class lThrowing {

    /**
     * id
     */
    public id: number;

    /**
     * 玩家id
     */
    public parentId: number;

    /**
     * 名称
     */
    public name: string;

    /**
     * 类型
     */
    public type: number;

    /**
     * 重量
     */
    public weight: number;

    /**
     * 数量
     */
    public count: number;

    /**
     * 触发时间计数
     */
    public time: number;

    /**
     * 触发总时间
     */
    public timeMax: number;

    constructor(id: number, parentId: number, name: string, type: number, weight: number, count: number, timeMax: number) {
        this.id = id;
        this.parentId = parentId;
        this.name = name;
        this.type = type;
        this.weight = weight;
        this.count = count;
        this.time = 0;
        this.timeMax = timeMax;
    }

}
