
import { _decorator, Component, Node, resources, AudioSource, AudioClip } from 'cc';
import { GameManager } from './GameManager';
const { ccclass, property } = _decorator;

/**
 * 音频管理类
 */
@ccclass('AudioManager')
export class AudioManager extends Component {

    /**
     * 音频管理器
     */
    public static instance: AudioManager;

    private audioSource: AudioSource = undefined;

    private audioList: { [name: string]: AudioClip } = {};

    onLoad() {
        AudioManager.instance = this;
    }

    /**
     * 初始化
     */
    public init(): void {
        this.audioSource = this.node.getComponent(AudioSource);

        resources.loadDir("audio", AudioClip, (err: Error, data: AudioClip[]) => {
            if (err) {
                console.log("音频资源加载错误", err);
                return;
            }
            for (let audio of data) {
                this.audioList[audio.name] = audio;
            }
            GameManager.instance.addLoadCount();
            console.log("音频资源加载完成");
            // console.log(this.audioList);
        })
    }

    public playAudio(name: string): void {
        this.audioSource.playOneShot(this.audioList[name], 1);
    }

    public playerMusic(): void {
        this.audioSource.play();
    }

    public stopMusic(): void {
        this.audioSource.stop();
    }

}
