
import { _decorator, Component, Node, resources, Prefab, instantiate, find } from 'cc';
import { GameManager } from './GameManager';
const { ccclass, property } = _decorator;

/**
 * 场景管理类
 */
@ccclass('SceneManager')
export class SceneManager extends Component {

    // 场景层
    @property(Node)
    LayerScene: Node = undefined;

    /**
     * 场景管理器
     */
    public static instance: SceneManager;

    // 场景集合
    private sceneList: { [name: string]: Prefab } = {};

    // 当前运行场景
    private currentScene: Node = undefined;

    // 当前运行场景名称
    public currentSceneName: string = "空";

    // 游戏摄像机
    private camera: Node = undefined;

    onLoad() {
        SceneManager.instance = this;
    }

    /**
     * 初始化
     */
    public init(): void {

        this.camera = find("SceneManager/CameraGame");

        resources.loadDir("prefab/scene", Prefab, (err: Error, data: Prefab[]) => {
            if (err) {
                console.log("场景资源加载错误", err);
                return;
            }

            for (let scene of data) {
                this.sceneList[scene.data.name] = scene;
            }

            GameManager.instance.addLoadCount();
            console.log("场景资源加载完成");
            // console.log(this.sceneList);
        })
    }

    /**
     * 加载指定场景
     * @param name 场景名称
     */
    public loadScene(name: string): void {
        // 当前场景不为空? 销毁当前场景
        if (this.currentScene != undefined) {
            this.currentScene.destroy();
        }

        // 延迟到下一帧创建新场景
        this.scheduleOnce(() => {
            let scene: Node = instantiate(this.sceneList[name]);
            scene.parent = this.LayerScene;
            scene.setPosition(0, 0);

            this.currentScene = scene;

            // 初始化摄像机坐标
            this.camera.setPosition(0, 0);

            // 延迟到下一帧处理加载回调
            this.scheduleOnce(() => {
                this.loadSceneCallBack(name);
            }, 0)
        }, 0)
    }

    // 场景加载完成回调
    private loadSceneCallBack(name: string): void {
        console.log("场景加载完成: " + name);
        this.currentSceneName = name;
    }

}
