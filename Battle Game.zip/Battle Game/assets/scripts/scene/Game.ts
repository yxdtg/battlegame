
import { _decorator, Component, Node, find, Sprite, Color, instantiate, Label, UITransform, view, tween, Vec3, Vec2, ProgressBar, lerp, Touch, EventTouch, sys, GbufferStage, TweenAction, TweenSystem, size } from 'cc';
import { lBullet } from '../logic/lBullet';
import { lFirearm } from '../logic/lFirearm';
import { lFirearmBullet } from '../logic/lFirearmBullet';
import { lItem } from '../logic/lItem';
import { lMedicine } from '../logic/lMedicine';
import { lPlayer } from '../logic/lPlayer';
import { GameManager } from '../manager/GameManager';
import { NetManager } from '../manager/NetManager';
import { ResourceManager } from '../manager/ResourceManager';
import { UIManager } from '../manager/UIManager';
import { Logic } from './Logic';
import intersects from 'intersects';
import { AudioManager } from '../manager/AudioManager';
import { PoolManager } from '../manager/PoolManager';
import { MessageManager } from '../manager/MessageManager';
import { lThrowing } from '../logic/lThrowing';
import { lThrowingBullet } from '../logic/lThrowingBullet';
import { lHelmet } from '../logic/lHelmet';
import { lSmoke } from '../logic/lSmoke';
import { lPack } from '../logic/lPack';
import { lArmor } from '../logic/lArmor';
const { ccclass, property } = _decorator;


/**
 * 帧数据
 */
type Frame = {
    c: number,
    d: any[]
};

enum PlayerUseState {
    None,
    Medicine,
    Throwing,
    Reload,
    Rescue,
}


/**
 * 表现层玩家
 */
type gPlayer = {
    player: lPlayer,
    node: Node,
    angleX: number,
    angleY: number,
    active: boolean
};

/**
 * 表现层子弹
 */
type gBullet = {
    bullet: lBullet,
    node: Node,
};

/**
 * 表现层投掷
 */
type gThrowing = {
    throwing: lThrowingBullet,
    node: Node,
};


/**
 * 表现层管理类
 */
@ccclass('Game')
export class Game extends Component {

    /**
     * 玩家层
     */
    @property(Node)
    LayerPlayer: Node = undefined;

    /**
     * 子弹层
     */
    @property(Node)
    LayerBullet: Node = undefined;

    /**
     * 子弹层
     */
    @property(Node)
    LayerThrowing: Node = undefined;

    /**
     * 文本层
     */
    @property(Node)
    LayerLabel: Node = undefined;

    /**
     * 层/点
     */
    @property(Node)
    LayerPoint: Node = undefined;

    /**
     * 背景层
     */
    @property(Node)
    LayerBackGround: Node = undefined;

    /**
     * 房屋层
     */
    @property(Node)
    LayerHouse: Node = undefined;

    /**
     * 物资层
     */
    @property(Node)
    LayerItem: Node = undefined;

    /**
     * 屋顶层
     */
    @property(Node)
    LayerRoof: Node = undefined;

    /**
     * 烟雾层
     */
    @property(Node)
    LayerSmoke: Node = undefined;

    /**
     * 碰撞层
     */
    @property(Node)
    LayerCollide: Node = undefined;

    /**
     * 表现层管理器
     */
    public static instance: Game;

    /**
     * 游戏摄像机
     */
    private camera: Node = undefined;
    /**
     * 帧数据列表
     */
    private frameData: Frame[] = [];
    /**
     * 上传数据帧率
     */
    private fpsNum: number = 1 / 64;
    /**
     * 
     */
    private dtNum: number = 0;
    /**
     * 玩家列表
     */
    private gPlayerList: { [id: number]: gPlayer } = {};
    /**
     * 子弹列表
     */
    private gBulletList: { [id: number]: gBullet } = {};
    /**
     * 投掷物列表
     */
    private gThrowingList: { [id: number]: gThrowing } = {};
    /**
     * 烟雾列表
     */
    private gSmokeList: { [id: number]: Node } = {};
    /**
     * 物资列表
     */
    private gItemList: { [id: number]: Node } = {};
    /**
     * 玩家点列表
     */
    private pointList: { [id: number]: Node } = {};
    /**
     * 地图玩家点列表
     */
    private pointMapList: { [id: number]: Node } = {};

    /**
     * 队伍玩家列表
     */
    private teamList: lPlayer[] = [];

    /**
     * 屋顶列表
     */
    private roofList: Node[] = [];

    /**
     * 当前可视视图大小 w0 , h1
     */
    private viewSize: number[] = [];

    /**
     * 玩家背包操作索引
     */
    private packIndex: number = -1;

    /**
     * 玩家操作背包物资
     */
    private packItem: Node = undefined;

    /**
     * 本地uid
     */
    public uid: number = -1;

    /**
     * 物资名称列表
     */
    private itemNameList: { [name: string]: string } = {};

    /**
     * 安全区域范围
     */
    private gCircleR: number = 30000;

    /**
     * 刷新玩家显示计数
     */
    private showPlayerCount: number = 0;
    /**
     * 刷新玩家显示最大计数
     */
    private showPlayerMaxCount: number = 30;

    /**
     * 更新1计数
     */
    private updateCount1: number = 0;
    /**
     * 更新1最大计数
     */
    private updateMaxCount1: number = 15;

    /**
     * 摇杆方案
     */
    public joystickType: number = 1;

    private showX: number = -100000;

    private itemView: Node = undefined;
    private packView: Node = undefined;
    private itemViewPos: number[] = [];
    private packViewPos: number[] = [];

    onLoad() {
        Game.instance = this;
    }

    start() {

        this.scheduleOnce(() => {
            this.itemView = UIManager.instance.getUI("ViewItem1");
            this.packView = UIManager.instance.getUI("ViewPack");

            this.itemViewPos = [this.itemView.position.x, this.itemView.position.y];
            this.packViewPos = [this.packView.position.x, this.packView.position.y];

            this.packView.setPosition(this.showX, 0);
        }, 0)

        this.itemNameList = ResourceManager.instance.itemNameList;
        // console.log(this.itemNameList);

        let type: string = sys.localStorage.getItem("JoystickType");
        if (type == "2") {
            // console.log("单摇杆方案");
            this.joystickType = 2;

            this.scheduleOnce(() => {
                UIManager.instance.getUI("JoystickAttack").active = false;

                UIManager.instance.getUI("ButtonAttack").on(Node.EventType.TOUCH_START, () => {
                    this.sendPlayerAttack(1);
                }, this);
                UIManager.instance.getUI("ButtonAttack").on(Node.EventType.TOUCH_END, () => {
                    this.sendPlayerAttack(0);
                }, this);
                UIManager.instance.getUI("ButtonAttack").on(Node.EventType.TOUCH_CANCEL, () => {
                    this.sendPlayerAttack(0);
                }, this);
            }, 0)
        } else {
            this.scheduleOnce(() => {
                UIManager.instance.getUI("ButtonAttack").active = false;
            }, 0)
        }

        let hintList: string[] = [
            "武器分为两种攻击方式, 一种是滑动时持续攻击，一种是松开时一次性攻击",
            "霰弹枪类贴脸输出威力更佳哦",
            "手雷和火箭筒等爆炸类伤害会误伤到自己和队友，记得小心使用哦",
            "安全区外会持续损失血量，记得携带足够的药品哦",
            "一直被追击?找个屋子躲起来吧",
            "小地图可以看到安全区域的范围哦",
            "使用部分药品可以获取能量值，能量值可以提供持续血量回复哦",
            "救助队友时记得注意四周情况哦"
        ];

        this.scheduleOnce(() => {
            UIManager.instance.getUI("LabelHint").getComponent(Label).string = "小提示: " + hintList[Math.round(Math.random() * (hintList.length - 1))];
        }, 0)

        PoolManager.instance.initBullet();

        let nameList: string[] = ResourceManager.instance.getResNameData();

        for (let i: number = 0; i < nameList.length; i++) {
            let node: Node = instantiate(ResourceManager.instance.getObject("ItemLayer"));
            node.parent = this.LayerItem;
            node.name = nameList[i];
        }

        this.uid = NetManager.instance.uid_;
        this.viewSize = [view.getVisibleSize().width, view.getVisibleSize().height];
        this.camera = find("SceneManager/CameraGame");

        let map: Node = instantiate(ResourceManager.instance.getObject("Map0"));
        map.setPosition(0, 0);

        let backGround: Node = instantiate(ResourceManager.instance.getObject("BackGround0"));
        let backGroundCount: number = backGround.children.length;
        for (let i: number = 0; i < backGroundCount; i++) {
            backGround.children[0].getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("map0");
            backGround.children[0].parent = this.LayerBackGround;
        }
        backGround.destroy();

        for (let i: number = 1; i < map.children.length; i++) {
            let house: Node = map.children[i];
            for (let j: number = 0; j < house.getChildByName("LayerRoof").children.length; j++) {
                let roof: Node = house.getChildByName("LayerRoof").children[j];
                this.roofList.push(roof);
            }

            let backGround: Node = house.getChildByName("BackGround");
            backGround.parent = this.LayerHouse;
            backGround.setPosition(house.position.x, house.position.y);
        }

        // console.log(this.roofList);

        for (let i: number = 0; i < this.roofList.length; i++) {
            let posX: number = this.roofList[i].position.x + this.roofList[i].parent.parent.position.x;
            let posY: number = this.roofList[i].position.y + this.roofList[i].parent.parent.position.y;
            this.roofList[i].parent = this.LayerRoof;
            this.roofList[i].setPosition(posX, posY);

            this.setOpacity(this.roofList[i].getComponent(Sprite), 255);
        }

        map.destroy();

        GameManager.instance.isShowFps = true;
    }

    onDestroy() {
        AudioManager.instance.stopMusic();
        GameManager.instance.isShowFps = false;
        PoolManager.instance.clearBullet();
    }

    /**
     * 缓存帧数据
     */
    public addFrame(frame: Frame): void {
        this.frameData.push(frame);
    }

    /**
     * 上传帧数据
     */
    private fixedUpdate(): void {
        // console.log("fixedUpdate");
        if (this.frameData.length == 0) {
            return;
        }
        NetManager.instance.frame(this.frameData);
        this.frameData = [];
    }

    /**
     * 创建玩家
     */
    public createPlayer(player: lPlayer, playerList: lPlayer[]): void {
        let gPlayer: gPlayer = this.gPlayerList[player.id];
        if (gPlayer == undefined) {
            let node: Node = instantiate(ResourceManager.instance.getObject("Player"));
            node.parent = this.LayerPlayer;
            // node.getChildByName("Image").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("Player" + player.userId);
            node.setPosition(player.x, player.y);

            node.getChildByName("LabelName").getComponent(Label).string = player.name;

            let gPlayer_: gPlayer = {
                player: player,
                node: node,
                angleX: 0,
                angleY: -1,
                active: true
            }

            this.gPlayerList[player.id] = gPlayer_;
        }
    }

    /**
     * 创建子弹
     */
    public createBullet(bullet: lBullet): void {
        let node: Node = undefined;
        if (bullet.type > -1) {
            node = PoolManager.instance.createBullet();
            node.setPosition(bullet.x, bullet.y);
            node.getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("bullet_" + bullet.type);
            // node.getComponent(UITransform).width = 45;
            // node.getComponent(UITransform).height = 15;
            let r: number = Math.atan2(bullet.vectorY, bullet.vectorX);
            let angle: number = r * 180 / Math.PI;
            node.angle = angle;
        } else {
            if (bullet.type == -1) {
                node = instantiate(ResourceManager.instance.getObject("Throwing"));
                node.getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("bullet_-1");
                node.parent = this.LayerBullet;
                node.getComponent(UITransform).width = bullet.width;
                node.getComponent(UITransform).height = bullet.height;
                node.setPosition(bullet.x, bullet.y);
                this.playerFirearmAudio(1, bullet.x, bullet.y);
            }
        }

        let gBullet: gBullet = {
            bullet: bullet,
            node: node
        }
        this.gBulletList[bullet.id] = gBullet;
    }

    /**
     * 创建物资
     */
    public createItem(item: lItem): void {
        let node: Node = instantiate(ResourceManager.instance.getObject("Item"));
        node.parent = this.LayerItem.getChildByName(item.name);
        node.setPosition(item.x, item.y);
        node.getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + item.name);
        let size: number[] = ResourceManager.instance.getItemSize(item.name);
        node.getComponent(UITransform).setContentSize(size[0] * 1.15, size[1] * 1.15);
        this.gItemList[item.id] = node;
    }

    /**
     * 创建投掷物
     */
    public createThrowing(throwing: lThrowingBullet): void {
        let node: Node = instantiate(ResourceManager.instance.getObject("Throwing"));
        node.getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_throwing_" + throwing.type);

        node.parent = this.LayerThrowing;
        let size: number[] = ResourceManager.instance.getItemSize(throwing.name);
        node.getComponent(UITransform).width = size[0];
        node.getComponent(UITransform).height = size[1];
        node.setPosition(throwing.x, throwing.y);
        let r: number = Math.atan2(throwing.vectorY, throwing.vectorX);
        let angle: number = r * 180 / Math.PI;
        node.angle = angle;

        let gThrowing: gThrowing = {
            throwing: throwing,
            node: node
        }
        this.gThrowingList[throwing.id] = gThrowing;
    }

    /**
     * 创建烟雾
     */
    public createSmoke(smoket: lSmoke): void {
        let gSmoke: Node = instantiate(ResourceManager.instance.getObject("Smoke"));
        gSmoke.parent = this.LayerSmoke;
        gSmoke.setPosition(smoket.x, smoket.y);
        gSmoke.getComponent(UITransform).setContentSize(smoket.width, smoket.height);
        gSmoke.setScale(smoket.scale, smoket.scale);
        this.gSmokeList[smoket.id] = gSmoke;
    }

    /**
     * 创建文本
     */
    public createLabel(text: string): void {
        let message: Node = instantiate(ResourceManager.instance.getObject("Message0"));
        message.parent = this.LayerLabel;
        message.setPosition(0, 290);
        message.getComponent(Label).string = text;

        this.scheduleOnce(() => {
            tween(message)
                .to(1.5, { position: new Vec3(0, 480) })
                .call(() => {
                    message.destroy();
                })
                .start()
        }, 1)
    }

    /**
     * 移除子弹
     */
    public removeBullet(bullet: lBullet): void {
        let gBullet: gBullet = this.gBulletList[bullet.id];
        let node: Node = gBullet.node;
        // console.log(bullet.type);
        if (bullet.type > -1) {
            PoolManager.instance.removeBullet(node);
        } else {
            // console.log(bullet.type);
            if (bullet.type == -1) {
                node.destroy();
            }
        }

        delete this.gBulletList[bullet.id];

    }

    /**
     * 移除投掷物
     */
    public removeThrowing(throwing: lThrowingBullet): void {
        let gThrowing: gThrowing = this.gThrowingList[throwing.id];
        gThrowing.node.destroy();
        delete this.gThrowingList[throwing.id];
    }

    /**
     * 移除烟雾
     */
    public removeSmoke(smoke: lSmoke): void {
        let gSmoke: Node = this.gSmokeList[smoke.id];
        gSmoke.destroy();
        delete this.gSmokeList[smoke.id];
    }

    /**
     * 移除物资
     */
    public removeItem(id: number): void {
        this.gItemList[id].destroy();
        delete this.gItemList[id];
    }

    /**
     * 初始化玩家数据
     */
    public initPlayer(playerList: lPlayer[]): void {

        for (let i: number = 0; i < playerList.length; i++) {
            let player: lPlayer = playerList[i];
            if (player.id == this.uid) {
                NetManager.instance.teamId_ = player.teamId;
                for (let j: number = 0; j < playerList.length; j++) {
                    let otherPlayer: lPlayer = playerList[j];
                    if (otherPlayer.teamId == player.teamId) {
                        this.teamList.push(otherPlayer);
                    }
                }

                this.initTeam();

                this.camera.setPosition(player.x, player.y);
                for (let j: number = 0; j < playerList.length; j++) {
                    let otherPlayer: lPlayer = playerList[j];
                    if (otherPlayer.teamId == player.teamId && otherPlayer.id != player.id) {
                        let point: Node = instantiate(ResourceManager.instance.getObject("PointPlayer"));
                        point.parent = this.LayerPoint;
                        point.getChildByName("Label").getComponent(Label).string = otherPlayer.name;
                        point.setPosition(0, 0);

                        this.pointList[otherPlayer.id] = point;
                    }
                    if (otherPlayer.teamId == player.teamId) {
                        let point: Node = instantiate(ResourceManager.instance.getObject("PointMapPlayer"));
                        point.parent = UIManager.instance.getUI("MapView");
                        point.getChildByName("Label").getComponent(Label).string = otherPlayer.name;
                        point.setPosition(0, 0);

                        this.pointMapList[otherPlayer.id] = point;
                    }
                }

                let layoutItem1: Node = UIManager.instance.getUI("LayoutItem1");

                for (let i: number = 0; i < layoutItem1.children.length; i++) {
                    let item: Node = layoutItem1.children[i];
                    item.on(Node.EventType.TOUCH_END, (a: any) => {
                        // console.log(item);
                        if (item.getComponent(Sprite).spriteFrame != undefined) {
                            let index: number = Number(item.name.substring(4, item.name.length)) - 1;
                            // console.log("Index: " + index);
                            this.playerPickItem(index);
                        }
                    }, this);
                }

                let layoutPack: Node = UIManager.instance.getUI("LayoutPack");
                let layoutItem3: Node = UIManager.instance.getUI("LayoutItem3");

                let itemList: Node[] = [];
                for (let i: number = 0; i < layoutPack.children.length; i++) {
                    itemList.push(layoutPack.children[i]);
                }

                for (let i: number = 0; i < layoutItem3.children.length; i++) {
                    itemList.push(layoutItem3.children[i]);
                }
                for (let i: number = 0; i < itemList.length; i++) {
                    let item: Node = itemList[i];
                    item.on(Node.EventType.TOUCH_START, (a: any) => {
                        // console.log(a.touch.getUILocationX());
                        if (item.getChildByName("Image").getComponent(Sprite).spriteFrame != undefined) {
                            let index: number = Number(item.name.substring(4, item.name.length));
                            // console.log(index);
                            this.packIndex = index;
                            this.packItem = item;
                        }
                    }, this);

                    item.on(Node.EventType.TOUCH_CANCEL, (a: any) => {
                        let pos: Vec2 = a.touch.getUILocation();;

                        if (this.packItem != undefined) {
                            let touchX: number = this.packItem.parent.getComponent(UITransform).convertToNodeSpaceAR(new Vec3(pos.x, pos.y)).x;
                            // console.log(touchX);

                            if (touchX < (this.packItem.position.x - this.packItem.getComponent(UITransform).width * 0.65)) {
                                if (this.packIndex != -1) {
                                    // console.log(this.packIndex);
                                    // console.log("throwing item " + this.packIndex);
                                    this.playerThrowItem(this.packIndex);
                                    this.packIndex = -1;
                                }
                            }
                        }

                        // if (this.boxBoxCollision(touch.x, touch.y, 1, 1, pos1.x + pos2.x, pos1.y, 200, 680)) {
                        //     if (this.packIndex != -1) {
                        //         // console.log(this.packIndex);
                        //         this.playerThrowItem(this.packIndex);
                        //         this.packIndex = -1;
                        //     }
                        // }
                    }, this);
                }
            }
        }

        for (let i: number = 0; i < playerList.length; i++) {
            let player: lPlayer = playerList[i];
            if (player.teamId != NetManager.instance.teamId_) {
                this.gPlayerList[player.id].node.getChildByName("LabelName").active = false;
            }
            if (player.id != this.uid) {
                this.gPlayerList[player.id].node.getChildByName("ProgressBar").active = false;
            }
        }

    }

    /**
     * 初始化队伍
     */
    private initTeam(): void {
        let layoutTeam: Node = UIManager.instance.getUI("LayoutTeam");
        for (let i: number = 0; i < layoutTeam.children.length; i++) {
            let teamPlayer: Node = layoutTeam.getChildByName("teamPlayer" + i);
            teamPlayer.active = false;
        }
        for (let i: number = 0; i < this.teamList.length; i++) {
            let player: lPlayer = this.teamList[i];
            let teamPlayer: Node = layoutTeam.getChildByName("teamPlayer" + i);
            teamPlayer.active = true;
            teamPlayer.getChildByName("Label").getComponent(Label).string = (i + 1) + "." + player.name;
            teamPlayer.getChildByName("HpBox").getChildByName("Strip").getComponent(Sprite).fillRange = player.hp / player.hpMax;
        }
    }

    /**
     * 开始游戏
     */
    public startGame(): void {
        UIManager.instance.getUI("ViewLoad").active = false;
        AudioManager.instance.playerMusic();
    }

    public playerFirearmAudio(type: number, x: number, y: number): void {
        let gPlayer: gPlayer = this.gPlayerList[this.uid];
        if (this.boxBoxCollision(gPlayer.player.x, gPlayer.player.y, 1920, 1080, x, y, 50, 50)) {
            AudioManager.instance.playAudio("audio_firearm" + type);
        }
    }

    /**
     * 本地玩家被击败处理
     */
    public playerByBeat(surviveCount: number): void {
        if (!UIManager.instance.getUI("ViewOver").active) {
            UIManager.instance.getUI("ViewOver").getChildByName("Label").getComponent(Label).string = "第 " + surviveCount + " 名";
            UIManager.instance.getUI("ViewOver").active = true;
        }
    }

    /**
     * 玩家击败处理
     */
    public playerBeat(player: lPlayer): void {
        let gPlayer: gPlayer = this.gPlayerList[player.id];
        gPlayer.active = false;
        gPlayer.node.getChildByName("Item").active = false;
        gPlayer.node.getChildByName("Helmet").active = false;
        gPlayer.node.getChildByName("Image").angle = 0;
        gPlayer.node.getChildByName("Image").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("BoxBeat");
        gPlayer.node.getChildByName("Image").getComponent(UITransform).setContentSize(gPlayer.node.getChildByName("Image").getComponent(Sprite).spriteFrame.width * 1.25, gPlayer.node.getChildByName("Image").getComponent(Sprite).spriteFrame.height * 1.25);
    }

    /**
     * 玩家拾取物资
     */
    private playerPickItem(index: number): void {
        this.addFrame({ c: 4, d: [this.uid, index] });
    }

    /**
     * 玩家丢弃物资
     */
    private playerThrowItem(index: number): void {
        this.addFrame({ c: 8, d: [this.uid, index] });
    }

    update(dt: number) {

        // 驱动逻辑层
        Logic.instance.update(dt);

        // let circleMask: Node = UIManager.instance.getUI("CircleMask");
        // let size: number = lerp(circleMask.getComponent(UITransform).width, this.gCircleR, 0.1);
        // circleMask.getComponent(UITransform).setContentSize(size, size);

        // this.showPlayerCount += 1;

        let playerRate: number = 0.35;
        let bulletRate: number = 0.35;
        // let labelRate: number = dt * 10;
        this.showPlayerCount++;

        for (let id in this.gPlayerList) {
            let gPlayer: gPlayer = this.gPlayerList[id];
            let player: lPlayer = gPlayer.player;
            let node: Node = gPlayer.node;

            if (this.showPlayerCount == this.showPlayerMaxCount) {
                if (player.id != this.uid) {
                    if (player.state != 2) {
                        this.scheduleOnce(() => {
                            if (!this.boxBoxCollision(this.gPlayerList[this.uid].node.position.x, this.gPlayerList[this.uid].node.position.y, this.viewSize[0] + this.viewSize[0] * 0.25, this.viewSize[1] + this.viewSize[1] * 0.25, gPlayer.node.position.x, gPlayer.node.position.y, 128, 128)) {
                                if (gPlayer.active) {
                                    gPlayer.active = false;
                                    gPlayer.node.getChildByName("Image").getComponent(Sprite).spriteFrame = undefined;
                                    gPlayer.node.getChildByName("Helmet").getComponent(Sprite).spriteFrame = undefined;
                                    gPlayer.node.getChildByName("Item").getComponent(Sprite).spriteFrame = undefined;
                                }
                            } else {
                                if (!gPlayer.active) {
                                    gPlayer.active = true;
                                    gPlayer.node.getChildByName("Image").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("Player0");
                                    // gPlayer.node.getChildByName("Helmet").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("Helmet0");
                                    this.updatePlayerHelmet(player);
                                    this.updatePlayerItem(player);
                                }
                            }
                        }, 0)
                    }
                }
            }

            if (player.state != 2 || player.teamId == NetManager.instance.teamId_) {

                // if (player.id == this.uid) {
                //     this.lerpMove(player, node, playerRate);
                // } else {
                //     let posX: number = lerp(node.position.x, player.x, 0.3);
                //     let posY: number = lerp(node.position.y, player.y, 0.3);
                //     node.setPosition(posX, posY);
                // }
                this.lerpMove(player, node, playerRate);

                if (player.state != 2) {
                    if (gPlayer.angleX != player.angleX || gPlayer.angleY != player.angleY) {

                        // 计算偏移
                        let offsetX: number = (player.angleX - gPlayer.angleX) * playerRate;
                        let offsetY: number = (player.angleY - gPlayer.angleY) * playerRate;

                        // 新坐标
                        let posX: number = gPlayer.angleX + offsetX;
                        let posY: number = gPlayer.angleY + offsetY;

                        if ((offsetX > 0 && posX > player.angleX) || (offsetX < 0 && posX < player.angleX)) {
                            posX = player.angleX;
                        }
                        if ((offsetY > 0 && posY > player.angleY) || (offsetY < 0 && posY < player.angleY)) {
                            posY = player.angleY;
                        }

                        gPlayer.angleX = posX;
                        gPlayer.angleY = posY;

                        let r: number = Math.atan2(gPlayer.angleY, gPlayer.angleX);
                        let angle: number = r * 180 / Math.PI;
                        node.getChildByName("Image").angle = angle;
                        node.getChildByName("Helmet").angle = angle;
                        node.getChildByName("Item").angle = angle;
                    }
                }

                // if (player.chatCount > 0) {
                //     this.LayerPlayer.getChildByName("LabelChat").children[gPlayer.index].getComponent(Label).string = player.chatText;
                //     this.LayerPlayer.getChildByName("ChatBox").children[gPlayer.index].getComponent(Sprite).color = new Color(255, 255, 255, 205);
                // } else {
                //     this.LayerPlayer.getChildByName("LabelChat").children[gPlayer.index].getComponent(Label).string = "";
                //     this.LayerPlayer.getChildByName("ChatBox").children[gPlayer.index].getComponent(Sprite).color = new Color(255, 255, 255, 0);
                // }

                // 本地玩家
                if (player.id == this.uid) {

                    // 更新摄像机坐标
                    this.camera.setPosition(node.position.x, node.position.y);

                    this.updateCount1 += 1;
                    if (this.updateCount1 == this.updateMaxCount1) {
                        this.updateCount1 = 0;

                        for (let i: number = 0; i < this.roofList.length; i++) {
                            let roof: Node = this.roofList[i];
                            if (this.boxBoxCollision(node.position.x, node.position.y, 100, 100, roof.position.x, roof.position.y, roof.getComponent(UITransform).width, roof.getComponent(UITransform).height)) {
                                if (roof.getComponent(Sprite).color.a != 0) {
                                    this.setOpacity(roof.getComponent(Sprite), 0);
                                }
                                // console.log("碰撞ROOF");
                            } else {
                                if (roof.getComponent(Sprite).color.a == 0) {
                                    this.setOpacity(roof.getComponent(Sprite), 255);
                                }
                            }
                        }
                    }

                    for (let playerId in this.pointList) {
                        let point: Node = this.pointList[playerId];
                        let otherPlayer: Node = this.gPlayerList[playerId].node;

                        let posX: number = (otherPlayer.position.x - node.position.x);
                        let posY: number = (otherPlayer.position.y - node.position.y);

                        let viewX: number = (this.viewSize[0] * 0.5) - 24;
                        let viewY: number = (this.viewSize[1] * 0.5) - 24;

                        if (posX < viewX && posX > -viewX && posY < viewY && posY > -viewY) {
                            if (point.getComponent(Sprite).color.a == 255) {
                                point.getComponent(Sprite).color = new Color(255, 155, 115, 0);
                            }
                        } else {
                            if (point.getComponent(Sprite).color.a == 0) {
                                point.getComponent(Sprite).color = new Color(255, 155, 115, 255);
                            }
                        }

                        if (posX < -viewX) {
                            posX = -viewX;
                        }
                        if (posX > viewX) {
                            posX = viewX;
                        }
                        if (posY < -viewY) {
                            posY = -viewY;
                        }
                        if (posY > viewY) {
                            posY = viewY;
                        }

                        point.setPosition(posX, posY);
                    }

                    for (let playerId in this.pointMapList) {
                        let point: Node = this.pointMapList[playerId];
                        let otherPlayer: Node = this.gPlayerList[playerId].node;

                        let s: number = 0.025;
                        point.setPosition(otherPlayer.position.x * s, otherPlayer.position.y * s);
                    }

                    let firearm: lFirearm = player.firearmList[player.firearmIndex];
                    if (firearm != undefined) {
                        node.getChildByName("ProgressBar").getComponent(ProgressBar).progress = firearm.attackCount / firearm.attackCountMax;
                    }

                    if (player.useState == PlayerUseState.Medicine) {
                        if (!UIManager.instance.getUI("ProgressUse").active) {
                            UIManager.instance.getUI("ProgressUse").active = true;
                        }
                        let medicine: lMedicine = player.medicineList[0];
                        UIManager.instance.getUI("LabelUse").getComponent(Label).string = "正在使用 " + this.itemNameList[medicine.name];
                        UIManager.instance.getUI("ProgressUse").getComponent(ProgressBar).progress = medicine.time / medicine.timeMax;
                    }

                    if (player.useState == PlayerUseState.Reload) {
                        if (!UIManager.instance.getUI("ProgressUse").active) {
                            UIManager.instance.getUI("ProgressUse").active = true;
                        }
                        let firearm: lFirearm = player.firearmList[player.firearmIndex];
                        UIManager.instance.getUI("LabelUse").getComponent(Label).string = "正在为 " + this.itemNameList[firearm.name] + " 装载子弹";
                        UIManager.instance.getUI("ProgressUse").getComponent(ProgressBar).progress = firearm.reloadTime / firearm.reloadMaxTime;
                    }

                    if (player.useState == PlayerUseState.Rescue) {
                        if (!UIManager.instance.getUI("ProgressUse").active) {
                            UIManager.instance.getUI("ProgressUse").active = true;
                        }
                        let otherPlayer: lPlayer = player.playerList[0];
                        UIManager.instance.getUI("LabelUse").getComponent(Label).string = "正在救助 " + otherPlayer.name;
                        UIManager.instance.getUI("ProgressUse").getComponent(ProgressBar).progress = otherPlayer.rescueCount / otherPlayer.rescueMaxCount;
                    }

                    if (player.useState == PlayerUseState.None) {
                        if (UIManager.instance.getUI("ProgressUse").active) {
                            UIManager.instance.getUI("LabelUse").getComponent(Label).string = "";
                            UIManager.instance.getUI("ProgressUse").active = false;
                        }
                    }

                    if (player.state == 1) {
                        if (player.rescueCount > 0) {
                            if (!UIManager.instance.getUI("ProgressUse").active) {
                                UIManager.instance.getUI("ProgressUse").active = true;
                            }
                            UIManager.instance.getUI("LabelUse").getComponent(Label).string = "正在被救助";
                            UIManager.instance.getUI("ProgressUse").getComponent(ProgressBar).progress = player.rescueCount / player.rescueMaxCount;
                        } else {
                            if (UIManager.instance.getUI("ProgressUse").active) {
                                UIManager.instance.getUI("ProgressUse").active = false;
                            }
                            UIManager.instance.getUI("LabelUse").getComponent(Label).string = "";
                        }
                    }

                    if (player.playerList.length > 0) {
                        if (!UIManager.instance.getUI("ButtonRescue").active) {
                            UIManager.instance.getUI("ButtonRescue").active = true;
                        }
                    } else {
                        if (UIManager.instance.getUI("ButtonRescue").active) {
                            UIManager.instance.getUI("ButtonRescue").active = false;
                        }
                    }

                    let layoutTeam: Node = UIManager.instance.getUI("LayoutTeam");
                    for (let i: number = 0; i < this.teamList.length; i++) {
                        let player: lPlayer = this.teamList[i];
                        let teamPlayer: Node = layoutTeam.getChildByName("teamPlayer" + i);
                        if (player.state == 0) {
                            teamPlayer.getChildByName("HpBox").getChildByName("Strip").getComponent(Sprite).color = new Color(255, 255, 255, 255);
                            teamPlayer.getChildByName("HpBox").getChildByName("Strip").getComponent(Sprite).fillRange = player.hp / player.hpMax;
                        }
                        if (player.state == 1) {
                            teamPlayer.getChildByName("HpBox").getChildByName("Strip").getComponent(Sprite).color = new Color(255, 0, 0, 255);
                            teamPlayer.getChildByName("HpBox").getChildByName("Strip").getComponent(Sprite).fillRange = player.shp / player.shpMax;
                        }
                        if (player.state == 2) {
                            teamPlayer.getChildByName("HpBox").getChildByName("Strip").getComponent(Sprite).color = new Color(255, 255, 255, 255);
                            teamPlayer.getChildByName("HpBox").getChildByName("Strip").getComponent(Sprite).fillRange = 0;
                        }
                    }

                    if (player.state == 0) {
                        UIManager.instance.getUI("HpStrip").getComponent(Sprite).color = new Color(255, 255, 255, 255);
                        UIManager.instance.getUI("HpStrip").getComponent(Sprite).fillRange = player.hp / player.hpMax;
                        UIManager.instance.getUI("MpStrip").getComponent(Sprite).fillRange = player.mp / player.mpMax;
                    }
                    if (player.state == 1) {
                        UIManager.instance.getUI("HpStrip").getComponent(Sprite).color = new Color(255, 0, 0, 255);
                        UIManager.instance.getUI("HpStrip").getComponent(Sprite).fillRange = player.shp / player.shpMax;
                    }
                    if (player.state == 2) {
                        UIManager.instance.getUI("HpStrip").getComponent(Sprite).color = new Color(255, 255, 255, 255);
                        UIManager.instance.getUI("HpStrip").getComponent(Sprite).fillRange = 0;
                    }

                }
            }
        }

        if (this.showPlayerCount == this.showPlayerMaxCount) {
            this.showPlayerCount = 0;
        }

        for (let id in this.gThrowingList) {
            let gThrowing: gThrowing = this.gThrowingList[id];
            let throwing: lThrowingBullet = gThrowing.throwing;
            let node: Node = gThrowing.node;

            if (throwing.count > 0) {
                this.lerpMove(throwing, node, bulletRate);
            }
        }

        // for (let id in this.labelList) {

        //     // 获取到对象及逻辑
        //     let gLabel: gLabel = this.labelList[id];
        //     let label: lLabel = gLabel.label;
        //     let node: Node = gLabel.node;

        //     this.lerpMove(label, node, labelRate);
        //     let scale: number = label.scale * gLabel.scale;
        //     node.setScale(scale, scale);
        // }

        this.dtNum += dt;

        if (this.dtNum >= this.fpsNum) {
            let count: number = Math.floor(this.dtNum / this.fpsNum);

            for (let i: number = 0; i < count; i++) {
                this.fixedUpdate();
            }

            this.dtNum -= count * this.fpsNum;
        }
    }

    public updateBullet(bullet: lBullet): void {
        let gBullet: gBullet = this.gBulletList[bullet.id];
        let node: Node = gBullet.node;
        node.setPosition(bullet.x, bullet.y);
    }

    public updateSmoke(smoke: lSmoke): void {
        let gSmoke: Node = this.gSmokeList[smoke.id];
        gSmoke.setScale(smoke.scale, smoke.scale);
    }

    /**
     * 更新存活数量
     */
    public updateSurvive(surviveCount: number): void {
        UIManager.instance.getUI("LabelSurvive").getComponent(Label).string = "存活: " + surviveCount;
    }

    /**
     * 更新安全区域范围
     */
    public updateCircle(r: number): void {
        this.gCircleR = r;

        let circleMask: Node = UIManager.instance.getUI("CircleMask");
        circleMask.getComponent(UITransform).setContentSize(this.gCircleR, this.gCircleR);
        let s: number = 0.025;
        UIManager.instance.getUI("MapMask").getComponent(UITransform).setContentSize(this.gCircleR * s, this.gCircleR * s);
    }

    /**
     * 更新游戏时间
     */
    public updateTime(gameTime: number): void {
        let f: any = Math.floor(gameTime / 60); // 获取分
        let s: any = gameTime % 60; // 获取秒
        f += "";
        s += "";
        f = (f.length == 1) ? "0" + f : f;
        s = (s.length == 1) ? "0" + s : s;
        // console.log(f + ":" + s);
        UIManager.instance.getUI("LabelTime").getComponent(Label).string = f + ":" + s;
    }

    /**
     * 更新物资拾取列表
     */
    public updatePickItem(player: lPlayer): void {
        let layoutItem1: Node = UIManager.instance.getUI("LayoutItem1");

        for (let i: number = 0; i < layoutItem1.children.length; i++) {
            if (layoutItem1.children[i].getComponent(Sprite).spriteFrame != undefined) {
                layoutItem1.children[i].getComponent(Sprite).spriteFrame = undefined;
                layoutItem1.children[i].getChildByName("Image").getComponent(Sprite).spriteFrame = undefined;
                layoutItem1.children[i].getChildByName("LabelName").getComponent(Label).string = "";
                layoutItem1.children[i].getChildByName("LabelCount").getComponent(Label).string = "";
            }
        }

        if (player.itemList.length > 0) {
            for (let i: number = 0; i < player.itemList.length; i++) {
                let item: lItem = player.itemList[i];
                if (layoutItem1.children.length > i) {
                    let size: number[] = ResourceManager.instance.getItemSize(item.name);
                    layoutItem1.children[i].getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("box0");
                    layoutItem1.children[i].getChildByName("Image").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + item.name);
                    layoutItem1.children[i].getChildByName("Image").getComponent(UITransform).setContentSize(size[0], size[1]);
                    layoutItem1.children[i].getChildByName("LabelName").getComponent(Label).string = this.itemNameList[item.name];
                    if (item.type != 1) {
                        layoutItem1.children[i].getChildByName("LabelCount").getComponent(Label).string = "" + item.count;
                    } else {
                        layoutItem1.children[i].getChildByName("LabelCount").getComponent(Label).string = "";
                    }
                }
            }
        }

        let itemCount: number = player.itemList.length;
        if (itemCount > 10) {
            itemCount = 10;
        }

        // 手动刷新来达到模拟触摸效果
        UIManager.instance.getUI("ViewItem1C").setPosition(UIManager.instance.getUI("ViewItem1C").position.x, UIManager.instance.getUI("ViewItem1C").position.y);
        // 更新高度
        UIManager.instance.getUI("ViewItem1C").getComponent(UITransform).height = itemCount * 80;
    }

    /**
     * 更新药品列表
     */
    public updateMedicine(medicineList: lMedicine[]): void {

        let layoutMedicine = UIManager.instance.getUI("LayoutMedicine");
        let count: number = medicineList.length;

        for (let i: number = 0; i < layoutMedicine.children.length + 1; i++) {
            if (i == 0) {
                UIManager.instance.getUI("MedicineBox").getChildByName("Image").getComponent(Sprite).spriteFrame = undefined;
                UIManager.instance.getUI("MedicineBox").getChildByName("LabelCount").getComponent(Label).string = "";
            } else {
                layoutMedicine.children[i - 1].getComponent(Sprite).spriteFrame = undefined;
                layoutMedicine.children[i - 1].getChildByName("Image").getComponent(Sprite).spriteFrame = undefined;
                layoutMedicine.children[i - 1].getChildByName("LabelCount").getComponent(Label).string = "";
            }
        }

        for (let i: number = 0; i < count; i++) {
            let medicine: lMedicine = medicineList[i];
            if (medicine != undefined) {
                let size: number[] = ResourceManager.instance.getItemSize(medicine.name);
                if (i == 0) {
                    UIManager.instance.getUI("MedicineBox").getChildByName("Image").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + medicine.name);
                    UIManager.instance.getUI("MedicineBox").getChildByName("Image").getComponent(UITransform).setContentSize(size[0], size[1]);
                    UIManager.instance.getUI("MedicineBox").getChildByName("LabelCount").getComponent(Label).string = "" + medicine.count;
                } else {
                    layoutMedicine.children[i - 1].getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("box0");
                    layoutMedicine.children[i - 1].getChildByName("Image").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + medicine.name);
                    layoutMedicine.children[i - 1].getChildByName("Image").getComponent(UITransform).setContentSize(size[0], size[1]);
                    layoutMedicine.children[i - 1].getChildByName("LabelCount").getComponent(Label).string = "" + medicine.count;
                }
            }
        }
    }

    /**
     * 更新投掷物列表
     */
    public updateThrowing(throwingList: lThrowing[]): void {

        let layoutThrowing = UIManager.instance.getUI("LayoutThrowing");
        let count: number = throwingList.length;

        for (let i: number = 0; i < layoutThrowing.children.length + 1; i++) {
            if (i == 0) {
                UIManager.instance.getUI("ThrowingBox").getChildByName("Image").getComponent(Sprite).spriteFrame = undefined;
                UIManager.instance.getUI("ThrowingBox").getChildByName("LabelCount").getComponent(Label).string = "";
            } else {
                layoutThrowing.children[i - 1].getComponent(Sprite).spriteFrame = undefined;
                layoutThrowing.children[i - 1].getChildByName("Image").getComponent(Sprite).spriteFrame = undefined;
                layoutThrowing.children[i - 1].getChildByName("LabelCount").getComponent(Label).string = "";
            }
        }

        for (let i: number = 0; i < count; i++) {
            let throwing: lThrowing = throwingList[i];
            if (throwing != undefined) {
                let size: number[] = ResourceManager.instance.getItemSize(throwing.name);
                if (i == 0) {
                    UIManager.instance.getUI("ThrowingBox").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("box0");
                    UIManager.instance.getUI("ThrowingBox").getChildByName("Image").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + throwing.name);
                    UIManager.instance.getUI("ThrowingBox").getChildByName("Image").getComponent(UITransform).setContentSize(size[0], size[1]);
                    UIManager.instance.getUI("ThrowingBox").getChildByName("LabelCount").getComponent(Label).string = "" + throwing.count;
                } else {
                    layoutThrowing.children[i - 1].getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("box0");
                    layoutThrowing.children[i - 1].getChildByName("Image").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + throwing.name);
                    layoutThrowing.children[i - 1].getChildByName("Image").getComponent(UITransform).setContentSize(size[0], size[1]);
                    layoutThrowing.children[i - 1].getChildByName("LabelCount").getComponent(Label).string = "" + throwing.count;
                }
            }
        }
    }

    /**
     * 更新枪械列表
     */
    public updateFirearm(player: lPlayer): void {

        let firearmList: lFirearm[] = player.firearmList;

        let a: number = 0;
        let b: number = 255;

        for (let i: number = 0; i < 2; i++) {
            let weapon: Node = UIManager.instance.getUI("ButtonWeapon" + i);
            this.setOpacity(weapon.getChildByName("Image").getComponent(Sprite), a);
            this.setOpacity(weapon.getChildByName("LabelName").getComponent(Label), a);
            this.setOpacity(weapon.getChildByName("LabelBullet").getComponent(Label), a);
            this.setOpacity(weapon.getChildByName("LabelBulletType").getComponent(Label), a);
        }

        for (let i: number = 0; i < firearmList.length; i++) {
            let firearm: lFirearm = firearmList[i];
            let weapon: Node = UIManager.instance.getUI("ButtonWeapon" + i);
            this.setOpacity(weapon.getChildByName("Image").getComponent(Sprite), b);
            this.setOpacity(weapon.getChildByName("LabelName").getComponent(Label), b);
            this.setOpacity(weapon.getChildByName("LabelBullet").getComponent(Label), b);
            this.setOpacity(weapon.getChildByName("LabelBulletType").getComponent(Label), b);
            let size: number[] = ResourceManager.instance.getItemSize(firearm.name);
            weapon.getChildByName("Image").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + firearm.name);
            weapon.getChildByName("Image").getComponent(UITransform).setContentSize(size[0], size[1]);
        }

    }

    /**
     * 更新枪械子弹
     */
    public updateFirearmBullet(player: lPlayer): void {

        let firearmList: lFirearm[] = player.firearmList;
        let bulletList: lFirearmBullet[] = player.bulletList;

        for (let i: number = 0; i < firearmList.length; i++) {
            let weapon: Node = UIManager.instance.getUI("ButtonWeapon" + i);
            let firearm: lFirearm = firearmList[i];

            let count: number = 0;
            for (let j: number = 0; j < bulletList.length; j++) {
                let bullet: lFirearmBullet = bulletList[j];
                if (bullet.type == firearm.bulletType) {
                    count = bullet.count;
                }
            }

            weapon.getChildByName("LabelName").getComponent(Label).string = this.itemNameList[firearm.name];
            weapon.getChildByName("LabelBulletType").getComponent(Label).string = this.itemNameList["bullet_" + firearm.bulletType];
            weapon.getChildByName("LabelBullet").getComponent(Label).string = firearm.bulletCount + " / " + count;
        }
    }

    /**
     * 更新玩家背包重量
     */
    public updatePlayerWeight(player: lPlayer): void {
        UIManager.instance.getUI("LabelWeight").getComponent(Label).string = player.weight + "/" + player.weightMax;
    }

    /**
     * 更新玩家使用状态
     */
    public updatePlayerItem(player: lPlayer): void {
        let gPlayer: gPlayer = this.gPlayerList[player.id];
        let node: Node = gPlayer.node;
        if (this.uid == player.id) {
            for (let i: number = 0; i < 2; i++) {
                UIManager.instance.getUI("ButtonWeapon" + i).setScale(1, 1);
            }
            UIManager.instance.getUI("ButtonWeapon" + player.firearmIndex).setScale(0.9, 0.9);
        }

        if (gPlayer.active) {
            if (player.useState == PlayerUseState.None) {
                node.getChildByName("Item").getComponent(Sprite).spriteFrame = undefined;
                if (player.firearmList.length > 0) {
                    let firearm: lFirearm = player.firearmList[player.firearmIndex];
                    if (firearm != undefined) {
                        node.getChildByName("Item").getComponent(UITransform).setAnchorPoint(-0.25, 0.5);
                        let size: number[] = ResourceManager.instance.getItemSize(firearm.name);
                        node.getChildByName("Item").getComponent(UITransform).setContentSize(size[0], size[1]);
                        node.getChildByName("Item").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + player.firearmList[player.firearmIndex].name);
                    }
                }
            } else {
                if (player.useState == PlayerUseState.Medicine) {
                    if (player.medicineList.length > 0) {
                        node.getChildByName("Item").getComponent(UITransform).setAnchorPoint(-0.8, 0.5);
                        let size: number[] = ResourceManager.instance.getItemSize(player.medicineList[0].name);
                        node.getChildByName("Item").getComponent(UITransform).setContentSize(size[0], size[1]);
                        node.getChildByName("Item").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + player.medicineList[0].name);
                    } else {
                        node.getChildByName("Item").getComponent(Sprite).spriteFrame = undefined;
                    }
                } else {
                    if (player.useState == PlayerUseState.Reload) {
                        let firearm: lFirearm = player.firearmList[player.firearmIndex];
                        if (firearm != undefined) {
                            node.getChildByName("Item").getComponent(UITransform).setAnchorPoint(-0.25, 0.5);
                            let size: number[] = ResourceManager.instance.getItemSize(firearm.name);
                            node.getChildByName("Item").getComponent(UITransform).setContentSize(size[0], size[1]);
                            node.getChildByName("Item").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + player.firearmList[player.firearmIndex].name);
                        }
                    } else {
                        if (player.useState == PlayerUseState.Throwing) {
                            if (player.throwingList.length > 0) {
                                node.getChildByName("Item").getComponent(UITransform).setAnchorPoint(-0.8, 0.5);
                                let size: number[] = ResourceManager.instance.getItemSize(player.throwingList[0].name);
                                node.getChildByName("Item").getComponent(UITransform).setContentSize(size[0], size[1]);
                                node.getChildByName("Item").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + player.throwingList[0].name);
                            } else {
                                node.getChildByName("Item").getComponent(Sprite).spriteFrame = undefined;
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * 更新玩家头盔
     */
    public updatePlayerHelmet(player: lPlayer): void {
        let helmet: lHelmet = player.helmetList[0];
        let gPlayer: gPlayer = this.gPlayerList[player.id];
        let node: Node = gPlayer.node;

        if (helmet == undefined) {
            node.getChildByName("Helmet").getComponent(Sprite).spriteFrame = undefined;
            return;
        }

        node.getChildByName("Helmet").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + helmet.name);
    }

    /**
     * 更新玩家背包列表
     */
    public updatePlayerPack(player: lPlayer): void {
        let layoutPack: Node = UIManager.instance.getUI("LayoutPack");
        let layoutItem3: Node = UIManager.instance.getUI("LayoutItem3");

        for (let i: number = 0; i < layoutPack.children.length; i++) {
            let itemNode: Node = layoutPack.children[i];
            if (itemNode.getComponent(Sprite).spriteFrame != undefined) {
                itemNode.getComponent(Sprite).spriteFrame = undefined;
                itemNode.getChildByName("Image").getComponent(Sprite).spriteFrame = undefined;
                itemNode.getChildByName("LabelName").getComponent(Label).string = "";
                itemNode.getChildByName("LabelCount").getComponent(Label).string = "";
            }
        }

        for (let i: number = 0; i < layoutItem3.children.length; i++) {
            let itemNode: Node = layoutItem3.children[i];
            if (itemNode.getChildByName("Image").getComponent(Sprite).spriteFrame != undefined) {
                itemNode.getChildByName("Image").getComponent(Sprite).spriteFrame = undefined;
                itemNode.getChildByName("LabelName").getComponent(Label).string = "";
            }
        }

        let count1: number = 0;
        for (let i: number = 0; i < player.firearmList.length; i++) {
            let firearm: lFirearm = player.firearmList[i];
            let itemNode: Node = layoutItem3.children[count1];
            let size: number[] = ResourceManager.instance.getItemSize(firearm.name);
            itemNode.getChildByName("Image").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + firearm.name);
            itemNode.getChildByName("Image").getComponent(UITransform).setContentSize(size[0], size[1]);
            itemNode.getChildByName("LabelName").getComponent(Label).string = this.itemNameList[firearm.name];
            count1++;
        }

        count1 = 2;
        for (let i: number = 0; i < player.helmetList.length; i++) {
            let helmet: lHelmet = player.helmetList[i];
            let itemNode: Node = layoutItem3.children[count1];
            let size: number[] = ResourceManager.instance.getItemSize(helmet.name);
            itemNode.getChildByName("Image").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + helmet.name);
            itemNode.getChildByName("Image").getComponent(UITransform).setContentSize(size[0], size[1]);
            itemNode.getChildByName("LabelName").getComponent(Label).string = this.itemNameList[helmet.name];
            count1++;
        }

        count1 = 3;
        for (let i: number = 0; i < player.armorList.length; i++) {
            let armor: lArmor = player.armorList[i];
            let itemNode: Node = layoutItem3.children[count1];
            let size: number[] = ResourceManager.instance.getItemSize(armor.name);
            itemNode.getChildByName("Image").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + armor.name);
            itemNode.getChildByName("Image").getComponent(UITransform).setContentSize(size[0], size[1]);
            itemNode.getChildByName("LabelName").getComponent(Label).string = this.itemNameList[armor.name];
            count1++;
        }

        count1 = 4;
        for (let i: number = 0; i < player.packList.length; i++) {
            let pack: lPack = player.packList[i];
            let itemNode: Node = layoutItem3.children[count1];
            let size: number[] = ResourceManager.instance.getItemSize(pack.name);
            itemNode.getChildByName("Image").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + pack.name);
            itemNode.getChildByName("Image").getComponent(UITransform).setContentSize(size[0], size[1]);
            itemNode.getChildByName("LabelName").getComponent(Label).string = this.itemNameList[pack.name];
            count1++;
        }

        let count: number = 0;
        for (let i: number = 0; i < player.medicineList.length; i++) {
            let medicine: lMedicine = player.medicineList[i];
            let itemNode: Node = layoutPack.children[count];
            itemNode.getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("box0");
            let size: number[] = ResourceManager.instance.getItemSize(medicine.name);
            itemNode.getChildByName("Image").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + medicine.name);
            itemNode.getChildByName("Image").getComponent(UITransform).setContentSize(size[0], size[1]);
            itemNode.getChildByName("LabelName").getComponent(Label).string = this.itemNameList[medicine.name];
            itemNode.getChildByName("LabelCount").getComponent(Label).string = "" + medicine.count;
            count++;
        }

        for (let i: number = 0; i < player.throwingList.length; i++) {
            let throwing: lThrowing = player.throwingList[i];
            let itemNode: Node = layoutPack.children[count];
            itemNode.getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("box0");
            let size: number[] = ResourceManager.instance.getItemSize(throwing.name);
            itemNode.getChildByName("Image").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + throwing.name);
            itemNode.getChildByName("Image").getComponent(UITransform).setContentSize(size[0], size[1]);
            itemNode.getChildByName("LabelName").getComponent(Label).string = this.itemNameList[throwing.name];
            itemNode.getChildByName("LabelCount").getComponent(Label).string = "" + throwing.count;
            count++;
        }

        for (let i: number = 0; i < player.bulletList.length; i++) {
            let bullet: lFirearmBullet = player.bulletList[i];
            let itemNode: Node = layoutPack.children[count];
            itemNode.getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("box0");
            let size: number[] = ResourceManager.instance.getItemSize(bullet.name);
            itemNode.getChildByName("Image").getComponent(Sprite).spriteFrame = ResourceManager.instance.getImage("item_" + bullet.name);
            itemNode.getChildByName("Image").getComponent(UITransform).setContentSize(size[0], size[1]);
            itemNode.getChildByName("LabelName").getComponent(Label).string = this.itemNameList[bullet.name];
            itemNode.getChildByName("LabelCount").getComponent(Label).string = "" + bullet.count;
            count++;
        }
    }

    /**
     * 发送玩家移动向量
     * @param angle 角度
     * @param type 类型
     */
    public sendPlayerVector(angle: number, type: number): void {
        this.addFrame({ c: 2, d: [this.uid, angle, type] });
    }

    /**
     * 发送玩家旋转向量
     * @param angle 角度
     * @param type 类型
     */
    public sendPlayerAngle(angle: number): void {
        this.addFrame({ c: 12, d: [this.uid, angle] });
    }

    /**
     * 发送玩家攻击状态
     * @param type 类型
     */
    public sendPlayerAttack(type: number): void {
        this.addFrame({ c: 3, d: [this.uid, type] });
    }

    /**
     * 设置 药品/投掷物 展开/关闭 视图
     */
    public setUnfurl(a: any, b: string): void {
        let layoutName: string = "Layout" + b;
        let unfurlName: string = "Unfurl" + b;

        if (b == "Medicine") {
            UIManager.instance.getUI(layoutName);
            let gPlayer: gPlayer = this.gPlayerList[this.uid];

            this.updateMedicine(gPlayer.player.medicineList);
        }

        if (UIManager.instance.getUI(layoutName).active) {
            UIManager.instance.getUI(layoutName).active = false;
            UIManager.instance.getUI(unfurlName).setScale(1, 1);
        } else {
            UIManager.instance.getUI(layoutName).active = true;
            UIManager.instance.getUI(unfurlName).setScale(1, -1);
        }

    }

    /**
     * 设置枪械装载子弹
     */
    public setFirearmReload(a: any, b: string): void {
        let type: number = Number(b);
        // 换弹
        if (type == 0) {
            this.addFrame({ c: 7, d: [this.uid, 0] });
        } else {
            // 取消换弹
            if (type == 1) {
                this.addFrame({ c: 7, d: [this.uid, 1] });
            }
        }
    }

    /**
     * 设置玩家操作药品
     */
    public setMedicineBox(a: any, b: string): void {
        let type: number = Number(b);
        // 使用
        if (type == -1) {
            this.addFrame({ c: 5, d: [this.uid, 0] });
        } else {
            // 取消使用
            if (type == -2) {
                this.addFrame({ c: 5, d: [this.uid, -1] });
            } else {
                // 选择
                let index: number = Number(b);
                if (UIManager.instance.getUI("LayoutMedicine").getChildByName("MedicineBox" + index).getComponent(Sprite).color.a != 0) {
                    this.addFrame({ c: 5, d: [this.uid, 1, index] });

                    this.setUnfurl(0, "Medicine");
                }
            }
        }
    }

    /**
     * 设置玩家操作投掷物
     */
    public setThrowingBox(a: any, b: string): void {
        let type: number = Number(b);
        // 使用
        if (type == -1) {
            this.addFrame({ c: 10, d: [this.uid, 0] });
        } else {
            // 选择
            this.addFrame({ c: 10, d: [this.uid, 1, 1] });
        }
    }

    /**
     * 设置物资拾取视图显示
     */
    public setItemViewShow(): void {
        if (this.itemView.position.x != this.showX) {
            this.itemView.setPosition(this.showX, 0);
        } else {
            this.itemView.setPosition(this.itemViewPos[0], this.itemViewPos[1]);
        }
    }

    /**
     * 设置背包视图显示
     */
    public setItemPackViewShow(a: any, b: string): void {
        if (this.packView.position.x != this.showX) {
            this.packView.setPosition(this.showX, 0);
        } else {
            this.packView.setPosition(this.packViewPos[0], this.packViewPos[1]);
        }
    }

    /**
     * 设置小地图视图显示
     */
    public setMapViewShow(): void {
        if (UIManager.instance.getUI("MapView").active) {
            UIManager.instance.getUI("MapView").active = false;
        } else {
            UIManager.instance.getUI("MapView").active = true;
        }
    }

    /**
     * 设置玩家武器索引切换
     */
    public setWeaponIndexSwap(): void {
        this.addFrame({ c: 11, d: [this.uid] });
    }

    /**
     * 设置玩家选择武器索引
     */
    public setWeaponIndex(a: any, b: string): void {
        let index: number = Number(b);

        this.addFrame({ c: 6, d: [this.uid, index] });
    }

    /**
     * 设置玩家操作救助
     */
    public setRescue(a: any, b: string): void {
        let type: number = Number(b);

        this.addFrame({ c: 9, d: [this.uid, type] });
    }

    /**
     * 插值移动
     * @param obj 对象
     * @param node 节点
     * @param rate 速率
     */
    private lerpMove(obj: any, node: Node, rate: number): void {

        let nodeX: number = node.position.x;
        let nodeY: number = node.position.y;

        if (nodeX != obj.x || nodeY != obj.y) {

            // 计算偏移
            let offsetX: number = (obj.x - nodeX) * rate;
            let offsetY: number = (obj.y - nodeY) * rate;

            // 新坐标
            let posX: number = nodeX + offsetX;
            let posY: number = nodeY + offsetY;

            if ((offsetX > 0 && posX > obj.x) || (offsetX < 0 && posX < obj.x)) {
                posX = obj.x;
            }
            if ((offsetY > 0 && posY > obj.y) || (offsetY < 0 && posY < obj.y)) {
                posY = obj.y;
            }

            node.setPosition(posX, posY);
        }
    }

    /**
     * 返回主界面
     */
    public backMain(): void {
        // 退出房间
        NetManager.instance.room(1);
        NetManager.instance.gameOver();
    }

    /**
     * 继续重连
     */
    public reconnect(): void {
        NetManager.instance.reconnectCountClear();
    }

    /**
     * 设置透明度
     * @param sprite obj
     * @param opacity 0 ~ 255
     */
    private setOpacity(sprite: any, opacity: number): void {
        sprite.color = new Color(sprite.color.r, sprite.color.g, sprite.color.b, opacity);
    }

    /**
     * 矩形与矩形碰撞检测
     */
    private boxBoxCollision(x1: number, y1: number, width1: number, height1: number, x2: number, y2: number, width2: number, height2: number): boolean {
        return intersects.boxBox(x1 - width1 / 2, y1 - height1 / 2, width1, height1, x2 - width2 / 2, y2 - height2 / 2, width2, height2);
    }
}
