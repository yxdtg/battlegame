
import { _decorator, Component, Node, EditBox, sys } from 'cc';
import { MessageManager } from '../manager/MessageManager';
import { NetManager } from '../manager/NetManager';
import { UIManager } from '../manager/UIManager';
const { ccclass, property } = _decorator;

/**
 * 主界面管理类
 */
@ccclass('Main')
export class Main extends Component {

    /**
     * 主界面管理器
     */
    public static instance: Main;

    onLoad() {
        Main.instance = this;
    }

    // 创建队组
    public createGroup(): void {
        NetManager.instance.group(0);
    }

    // 加入队组
    public joinGroup(): void {
        NetManager.instance.group(1);
    }

    // 离开队组
    public leaveGroup(): void {
        NetManager.instance.group(2);
    }

    // 踢出小队
    public outGroup(a: any, b: string): void {
        let index: number = Number(b);
        NetManager.instance.group(3, index);
    }

    // 队组匹配
    public matchGroup(): void {
        NetManager.instance.match(0);
    }

    // 取消队组匹配
    public overMatchGroup(): void {
        NetManager.instance.match(1);
    }

    // 复制队组号到剪切版
    public copyGroupId(): void {
        let groupId: string = "" + NetManager.instance.groupId_;
        if (sys.os == sys.OS.ANDROID) {
            jsb.copyTextToClipboard(groupId);
            MessageManager.instance.createMessage("复制小队码成功");
        } else {
            MessageManager.instance.createMessage("错误");
        }
    }

    public setJoystickType(): void {
        let type: string = sys.localStorage.getItem("JoystickType");
        if (type == undefined) {
            MessageManager.instance.createMessage("现在是单摇杆方案");
            sys.localStorage.setItem("JoystickType", "2");
        } else {
            if (type == "1") {
                MessageManager.instance.createMessage("现在是单摇杆方案");
                sys.localStorage.setItem("JoystickType", "2");
            } else {
                if (type == "2") {
                    MessageManager.instance.createMessage("现在是双摇杆方案");
                    sys.localStorage.setItem("JoystickType", "1");
                }
            }
        }
    }

}
