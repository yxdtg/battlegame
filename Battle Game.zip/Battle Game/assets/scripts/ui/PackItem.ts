
import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('PackItem')
export class PackItem extends Component {

    private touchX: number = 0;

    onLoad() {
        this.node.on(Node.EventType.TOUCH_START, () => {

        })

        this.node.on(Node.EventType.TOUCH_CANCEL, () => {
            
        })
    }

}
