
import { _decorator, Component, Node } from 'cc';
import { UIManager } from '../manager/UIManager';
const { ccclass, property } = _decorator;

/**
 * UI类
 */
@ccclass('UI')
export class UI extends Component {

    @property
    names: string = "";

    @property
    active: boolean = true;

    @property
    persistence: boolean = false;

    start() {
        if (this.names == "") {
            this.names = this.node.name;
        }
        if (this.persistence) {
            UIManager.instance.setPersistence(this.names, this.node);
        } else {
            UIManager.instance.setUI(this.names, this.node);
        }
        if (!this.active) {
            // 延迟到下一帧处理，防止子节点没有注册时间
            this.scheduleOnce(() => {
                this.node.active = false;
            }, 0)
        }
    }

    onDestroy() {
        if (!this.persistence) {
            UIManager.instance.removeUI(this.names);
        }
    }

}
