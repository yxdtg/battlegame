declare module "*.css";
declare module "*.html";