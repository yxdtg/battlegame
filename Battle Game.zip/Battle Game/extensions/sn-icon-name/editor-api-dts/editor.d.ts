declare namespace Editor {
    interface IPanel {
        /**
         * 监听面板事件
         */
        linsteners?: IPanelListeners
        /**
         * 面板的内容
         */
        template?: string,
        /**
         * 面板上的样式
         */
        style?: string,
        /**
         * 快捷选择器
         */
        $?: {
            elem: string,
            [key: string]: string
        },
        /**面板启动后触发的钩子函数 */
        ready(): void | Promise<void>;
        /**
         * 当面板尝试被关闭的时候，将会触发这个函数，beforeClose 可以是一个 async 函数，可以进行异步判断，如果 return false，则会终止当前的关闭操作。
         * 请不要在这个函数里执行实际的销毁和关闭相关的逻辑代码，这一步骤只是进行询问，实际的销毁请放到 close 函数里。
         * 请谨慎使用 如果判断错误，可能导致编辑器或者面板窗口无法正常关闭。
         */
        beforeClose?(): boolean | Promise<boolean>
        /**
         * 当窗口内的所有面板允许关闭后，会触发面板的 close，一旦触发 close，结束后将强制关闭窗口，所以请在 close 进行数据的保存，如果出现异常关闭，请做好数据的备份，以便在重新启动的时候尽可能恢复数据。
         */
        close?(): void | Promise<void>;
        /**
         * 面板上定义的方法。面板对外的功能都需要封装成方法，以函数为单位对外提供。消息也可以直接触发面板上的方法，详细请参考 消息通信
            https://docs.cocos.com/creator/3.0/manual/zh/editor/extension/contributions-messages.html
            这个对象里都是函数，请不要挂载其他类型的对象到这里。
         */
        methods?: { [key: string]: Function }
    }
    interface IPanelListeners {
        /**面板显示的时候触发的钩子 */
        show?(): void;
        /**面板隐藏的时候触发的钩子 */
        hide?(): void
        /**
         * 面板大小更改的时候触发
         */
        resize?(): void
    }
    interface IMain {
        /** 当扩展被启动的时候执行 */
        load?(): void
        /**当扩展被关闭的时候执行 */
        unload?(): void
        /**扩展内定义的方法 */
        methods?: { [key: string]: Function }
    }
    class Message {
        /**
         * 方法只发送消息，并不会等待返回。如果不需要返回数据，且不关心是否执行完成，请使用这个方法。
         * @param pkgName 
         * @param message 
         * @param args 
         */
        static send(pkgName: string, message: string, ...args): void;
        /**
         * request 方法返回一个 promise 对象，这个 promise 会接收消息处理后返回的数据。
         * @param pkgName 
         * @param message 
         * @param args 
         */
        static request(pkgName: string, message: string, ...args): Promise<any>
        /**
         * broadcast 方法只发送，并且发送给所有监听对应消息的功能扩展。
         * @param pkgName 
         * @param actionName 
         * @param args 
         */
        static broadcast(pkgName: string, actionName: string, ...args): void;
    }
    interface ProfileInfo {
        editor: { [ key: string ]: ProfileItem };
        project: { [ key: string ]: ProfileItem };
    }
    
    interface ProfileItem {
        /**
         * 配置的默认数据
         */
        default: any;
        /**
         * 配置更改后，会自动发送这个消息进行通知
         */
        message: string;
        /**
         * 简单的描述配置信息的作用，支持 i18n:key 语法
         */
        label: string;
    }
    class Profile {
        /**
         * 读取编辑器配置
         * @param pkgName 
         * @param key 
         * @param protocol 
         */
        static getConfig(pkgName: string, key: string, protocol: string): Promise<ProfileItem>
        /**
         *  读取项目配置
         * @param pkgName 
         * @param key 
         * @param protocol 
         */
        static getProject(pkgName: string, key: string, protocol: string): Promise<ProfileItem>
    }
    class Panel {
        /**
         * 打开panel
         * @param panelID 
         * @param args 
         */
        static open(panelID: string, ...args): void
        /**
         * 关闭panel
         * @param panelID 
         * @param args 
         */
        static close(panelID: string, ...args): void
        /**
         * 是否有这个panel
         * @param panelID 
         */
        static has(panelID: string): Promise<boolean>
        /**
         * 聚焦panel
         * @param panelID 
         */
        static focus(panelID: string): void
    }
    class I18n {
        /**
         * 获取当前语言的文本
         * @param key 
         */
        static t(key: string, r: any): string
        /**
         * 当前语言
         * 
         */
        static getLanguage(): string
    }
}