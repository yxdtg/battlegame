const { createFilter, dataToEsm } = require("rollup-pluginutils");
/**
 * @type {import("rollup").Plugin}
 */
const cccssHtmlImportPlugin = {
    name: "rollup-plugin-cccsshtml-import",
    transform(code, id) {
        const filter = createFilter(["**/*.html", "**/*.css"]);
        if (!filter(id)) return;
        // console.log("code:", code);
        // console.log("id:", id);
        return { code: dataToEsm(code) };
    }
}
module.exports = cccssHtmlImportPlugin;