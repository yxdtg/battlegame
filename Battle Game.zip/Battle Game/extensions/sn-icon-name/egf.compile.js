const path = require("path");
const cccssHtmlImportPlugin = require("./egf-plugin-cccsshtml.js");
const fs = require("fs");
/**
 * @type {IEgfCompileOption}
 */
const option = {
    entry: [
        "./src/main/main.ts",
        "./src/renderer/default/default.ts",
        "./src/renderer/panel/panel.ts",
        "./src/renderer/panel2/panel2.ts"
    ],
    outputDir: "dist",
    plugins: [cccssHtmlImportPlugin],
    chunkFileNames: (chunkInfo) => {

        const modulePaths = Object.keys(chunkInfo.modules);
        if (modulePaths.length > 1) {
            let modulePath;
            let chunkKeys = [];
            for (let i = 0; i < modulePaths.length; i++) {
                modulePath = modulePaths[i];
                if (modulePath.includes("node_modules")) {
                    let packagePath = modulePath;
                    while (packagePath !== ".") {
                        packagePath = path.dirname(packagePath);
                        if (fs.existsSync(path.posix.join(packagePath, "package.json"))) {
                            break;
                        }
                    }
                    if (packagePath !== ".") {
                        const packageJson = require(path.posix.join(packagePath, "package.json"));
                        const pName = packageJson.name.replace("/", "-")
                        chunkKeys.push(pName)
                    }
                } else {
                    chunkKeys.push(path.basename(modulePath).replace(path.extname(modulePath), ""));
                }
            }
            return chunkKeys.join("_") + ".js";
        } else {
            return "[name].js"
        }

    }



}
module.exports = option;