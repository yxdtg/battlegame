export class MainRenderCommon {
    doSommonCommon() {
    }
}