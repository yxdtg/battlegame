export class hello {
    static sayHello() {

    }
}