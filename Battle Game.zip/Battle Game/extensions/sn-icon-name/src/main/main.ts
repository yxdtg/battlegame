import { MainRenderCommon } from "../common/main-render-common";
import { hello } from "./hello";
import { App } from "@ailhc/egf-core"
import { pluginName } from "../common/const";
//使用npm包
// console.log(`使用一个npm包`)
// console.log(new App());
let app = new App()
const fs = require("fs");

const main: Editor.IMain = {
    /**
     * // 当扩展被启动的时候执行
     */
    load() {
        console.log(`插件加载<----`);


    },
    /**扩展内定义的方法 */
    unload() {
        console.log(`插件卸载---->`);
    },
    methods: {
        log() {
            console.log('Hello World');
        },
        "open-default"() {
            //打开默认面板
            Editor.Panel.open('sn-icon-name');
        },
        open() {
            // 打开指定面板panel 插件名.面板名
            Editor.Panel.open('sn-icon-name.panel');
        },
        open2() {
            // 打开指定面板panel2 在package.json注册
            Editor.Panel.open('sn-icon-name.panel2');
        },
        'say-hello'() {
            // console.log('Hello World!');
            // hello.sayHello()
            // Editor.log(require.main.paths)

            // console.log("hhh")
            // send message
            Editor.Message.send(pluginName, 'hello');
        },
        clicked(args: any[]) {
            console.log("执行操作..>");

            let project_path: string = Editor.Project.path;
            if (!fs.existsSync(project_path + "/native/engine/android")) {
                console.log("未构建安卓项目，请先构建一个安卓项目");
                return;
            }

            // 初始化数据
            let app_name_en: string = args[0][0];
            let app_name_zh: string = args[0][1];
            let app_name_translatable: boolean = args[1];

            let name_path: string = project_path + "/native/engine/android/res/values/strings.xml";

            // 数据处理
            let data: string = "<resources>\n    <string name={a} translatable={b}>{c}</string> \n</resources>";
            data = data.replace(/{a}/, '"' + app_name_en + '"');
            data = data.replace(/{b}/, '"' + app_name_translatable + '"');
            data = data.replace(/{c}/, app_name_zh);

            // 处理文件
            fs.unlinkSync(name_path);
            fs.writeFileSync(name_path, data, 'utf8');

            // 完成
            console.log("游戏名称更改完成~");
        },
        clicked1(args: any[]) {
            console.log("执行操作..>");

            let project_path: string = Editor.Project.path;
            if (!fs.existsSync(project_path + "/native/engine/android")) {
                console.log("未构建安卓项目，请先构建一个安卓项目");
                return;
            }

            let bufferList: { [name: string]: string } = args[0];

            let names: string[] = [];
            for (let name in bufferList) {
                if (bufferList[name] == undefined) {
                    names.push(name);
                }
            }

            if (names.length > 0) {
                console.log("---游戏图标为空---");
                for (let i: number = 0; i < names.length; i++) {
                    let name: string = names[i];
                    console.log("游戏图标 " + name + "x" + name + " 为空");
                }
                return;
            }

            // console.log("生成");
            // let icon_48_path: string = project_path + "/native/engine/android/res/mipmap-mdpi/ic_launcher.png";
            // let icon_72_path: string = project_path + "/native/engine/android/res/mipmap-hdpi/ic_launcher.png";
            // let icon_96_path: string = project_path + "/native/engine/android/res/mipmap-xhdpi/ic_launcher.png";
            // let icon_144_path: string = project_path + "/native/engine/android/res/mipmap-xxhdpi/ic_launcher.png";
            // let icon_192_path: string = project_path + "/native/engine/android/res/mipmap-xxxhdpi/ic_launcher.png";

            let icon_path: { [name: string]: string } = {
                "48": project_path + "/native/engine/android/res/mipmap-mdpi/ic_launcher.png",
                "72": project_path + "/native/engine/android/res/mipmap-hdpi/ic_launcher.png",
                "96": project_path + "/native/engine/android/res/mipmap-xhdpi/ic_launcher.png",
                "144": project_path + "/native/engine/android/res/mipmap-xxhdpi/ic_launcher.png",
                "192": project_path + "/native/engine/android/res/mipmap-xxxhdpi/ic_launcher.png"
            }

            for (let name in bufferList) {
                let buffer: Buffer = Buffer.from(bufferList[name], 'base64');
                // console.log(buffer);
                createImage(icon_path[name], buffer);
            }

            function createImage(path: string, dataBuffer: Buffer) {
                fs.unlinkSync(path);
                fs.writeFileSync(path, dataBuffer);
            }

            console.log("游戏图标更换完成~");
        }
    }
}
//主进程和渲染进程共用代码
// console.log(`使用共用代码`)
new MainRenderCommon().doSommonCommon();
module.exports = main;


