import { MainRenderCommon } from '../../common/main-render-common';
import { PanelCommon } from '../panel-common';
import { App } from "@ailhc/egf-core"
console.log(new App());

import panelcss from "./css/panel.css";
import panelHtml from "./html/panel.html";
import { pluginName } from '../../common/const';
(new PanelCommon()).sayCommon("")
new MainRenderCommon().doSommonCommon()
const defaultPanel: Editor.IPanel = {
    // 监听面板事件
    linsteners: {
        // 面板显示的时候触发的钩子
        show() {
            console.log("default显示状态", this.hidden);
        },
        // 面板隐藏的时候触发的钩子
        hide() {
            console.log("default显示状态", this.hidden);
        },
        /**
         * 面板大小更改的时候触发
         */
        resize() {
            console.log(this.clientHeight);
            console.log(this.clientWidth);
        },
    },
    /**
     * 面板的内容
     */
    template: panelHtml,
    /**
     * 面板上的样式
     */
    style: panelcss,
    /**
     * 快捷选择器
     */
    $: {
        elem: "div",
        btn: '#btn',
        label: '#label',
    },
    methods: {
        hello() {
            this.$.label.innerText = '来啊玩转游戏开发!';
        }
    },
    /**面板启动后触发的钩子函数 */
    ready(): void {
        this.$.btn.addEventListener('confirm', () => {
            Editor.Message.send(pluginName, 'clicked');
        });
    },
    /**
     * 当面板尝试被关闭的时候，将会触发这个函数，beforeClose 可以是一个 async 函数，可以进行异步判断，如果 return false，则会终止当前的关闭操作。

请不要在这个函数里执行实际的销毁和关闭相关的逻辑代码，这一步骤只是进行询问，实际的销毁请放到 close 函数里。

请谨慎使用 如果判断错误，可能导致编辑器或者面板窗口无法正常关闭。
     */
    beforeClose(): boolean {
        return undefined;
    },
    /**面板关闭后的钩子函数 */
    close(): void {

    }
}
module.exports = defaultPanel;
// export default panel;