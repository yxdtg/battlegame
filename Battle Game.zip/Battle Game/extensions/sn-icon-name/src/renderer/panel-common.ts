export class PanelCommon {
    sayCommon(text: string) {
        console.log(text);
    }
}