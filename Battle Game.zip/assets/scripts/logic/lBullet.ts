
/**
 * 子弹类
 */
export class lBullet {

    /**
     * 子弹id
     */
    public id: number;

    /**
     * 子弹类型
     */
    public type: number;

    /**
     * 玩家id
     */
    public parentId: number;

    /**
     * 队伍id
     */
    public teamId: number;

    /**
     * 子弹x坐标
     */
    public x: number;

    /**
     * 子弹y坐标
     */
    public y: number;

    /**
     * 子弹宽度
     */
    public width: number;

    /**
     * 子弹高度
     */
    public height: number;

    /**
     * 攻击计数
     */
    public count: number;

    /**
     * 攻击值
     */
    public attack: number;

    /**
     * 向量x
     */
    public vectorX: number;

    /**
     * 向量y
     */
    public vectorY: number;

    /**
     * 移动速度
     */
    public speed: number;

    /**
     * 被攻击玩家id列表
     */
    public playerIds: number[];

    constructor(id: number, parentId: number, teamId: number, type: number, attack: number, x: number, y: number, vectorX: number, vectorY: number, speed: number, count: number) {
        this.id = id;
        this.parentId = parentId;
        this.teamId = teamId;

        this.type = type;
        this.attack = attack;

        this.x = x;
        this.y = y;
        if (type == -1) {
            this.width = 360;
            this.height = 360;
        }
        if (type == 0) {
            this.width = 24;
            this.height = 24;
        }
        if (type == 1) {
            this.width = 24;
            this.height = 24;
        }
        if (type == 2) {
            this.width = 24;
            this.height = 24;
        }
        if (type == 3) {
            this.width = 24;
            this.height = 24;
        }
        if (type == 4) {
            this.width = 24;
            this.height = 24;
        }
        this.vectorX = vectorX;
        this.vectorY = vectorY;

        this.speed = speed;

        this.playerIds = [];

        this.count = count;
    }

}