
/**
 * 枪械子弹类
 */
export class lFirearmBullet {

    /**
     * id
     */
    public id: number;

    /**
     * 名称
     */
    public name: string;

    /**
     * 类型
     */
    public type: number;

    /**
     * 重量
     */
    public weight: number;

    /**
     * 数量
     */
    public count: number;

    constructor(id: number, name: string, type: number, weight: number, count: number) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.weight = weight;
        this.count = count;
    }

}
