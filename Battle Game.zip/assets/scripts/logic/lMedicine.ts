
/**
 * 药品类
 */
export class lMedicine {

    /**
     * id
     */
    public id: number;

    /**
     * 名称
     */
    public name: string;

    /**
     * 重量
     */
    public weight: number;

    /**
     * 数量
     */
    public count: number;

    /**
     * 使用时间计数
     */
    public time: number;

    /**
     * 使用消耗时间
     */
    public timeMax: number;

    constructor(id: number, name: string, weight: number, count: number, timeMax: number) {
        this.id = id;
        this.name = name;
        this.weight = weight;
        this.count = count;
        this.time = 0;
        this.timeMax = timeMax;
    }

}
