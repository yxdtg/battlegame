import { Logic } from "../scene/Logic";
import { lArmor } from "./lArmor";
import { lFirearm } from "./lFirearm";
import { lFirearmBullet } from "./lFirearmBullet";
import { lHelmet } from "./lHelmet";
import { lItem } from "./lItem";
import { lMedicine } from "./lMedicine";
import { lPack } from "./lPack";
import { lThrowing } from "./lThrowing";

/**
 * 玩家类
 */
export class lPlayer {

    /**
     * 玩家id
     */
    public id: number;

    /**
     * 玩家昵称
     */
    public name: string;

    /**
     * 是否是机器人
     */
    public isRobot: boolean;

    /**
     * 角色id
     */
    public userId: number;

    /**
     * 队伍id
     */
    public teamId: number;

    /**
     * 玩家x坐标
     */
    public x: number;

    /**
     * 玩家y坐标
     */
    public y: number;

    /**
     * 玩家角度
     */
    public angle: number;

    /**
     * 玩家是否在攻击
     */
    public isAttack: boolean;

    /**
     * 玩家血量
     */
    public hp: number;

    /**
     * 玩家最大血量
     */
    public hpMax: number;


    /**
     * 玩家能量
     */
    public mp: number;

    /**
     * 玩家最大能量
     */
    public mpMax: number;

    /**
     * 玩家被击倒血量
     */
    public shp: number;

    /**
     * 玩家被击倒最大血量
     */
    public shpMax: number;

    /**
     * 玩家x向量
     */
    public vectorX: number;

    /**
     * 玩家x向量
     */
    public vectorY: number;

    /**
     * 玩家旋转x向量
     */
    public angleX: number;

    /**
     * 玩家旋转y向量
     */
    public angleY: number;

    /**
     * 玩家移动速度
     */
    public speed: number;

    /**
     * 玩家宽度
     */
    public width: number;

    /**
     * 玩家高度
     */
    public height: number;

    /**
     * 临时计数
     */
    public count: number;

    public itemList: lItem[] = [];

    /**
     * 药品背包
     */
    public medicineList: lMedicine[] = [];

    /**
     * 投掷品背包
     */
    public throwingList: lThrowing[] = [];

    /**
     * 枪械背包
     */
    public firearmList: lFirearm[] = [];

    /**
     * 枪械使用索引
     */
    public firearmIndex: number;

    /**
     * 子弹背包
     */
    public bulletList: lFirearmBullet[] = [];

    public helmetList: lHelmet[] = [];
    public armorList: lArmor[] = [];
    public packList: lPack[] = [];

    public playerList: lPlayer[] = [];

    public rescueCount: number;
    public rescueMaxCount: number;

    /**
     * 重量
     */
    public weight: number;
    /**
     * 最大重量
     */
    public weightMax: number;

    /**
     * 玩家状态 0-存活 1-倒下 2-被击败
     */
    public state: number;

    /**
     * 玩家使用状态 0-无 1-使用药品 2-换弹 3-救助队友 4-准备投掷
     */
    public useState: number;

    /**
     * 玩家在圈时间计数
     */
    public circleCount: number;
    /**
     * 玩家在圈最大时间
     */
    public circleMaxCount: number;

    constructor(id: number, name: string, isRobot: boolean, userId: number, teamId: number) {

        let frameRate: number = Logic.instance.frameRate;

        this.id = id;
        this.name = name;
        this.isRobot = isRobot;
        this.userId = userId;
        this.teamId = teamId;

        this.isAttack = false;

        this.x = 0;
        this.y = 0;
        this.angle = 0;

        this.hpMax = 1000;
        this.hp = this.hpMax;
        this.mpMax = 1000;
        this.mp = 0;

        this.shpMax = 500;
        this.shp = this.shpMax;

        this.weight = 0;
        this.weightMax = 400;
        this.count = 0;
        this.state = 0;
        this.useState = 0;

        this.rescueCount = 0;
        this.rescueMaxCount = frameRate * 5;

        this.circleCount = 0;
        this.circleMaxCount = frameRate * 1;

        this.firearmIndex = 0;

        this.vectorX = 0;
        this.vectorY = 0;
        this.angleX = 1;
        this.angleY = 0;

        this.speed = 6;

        this.width = 60;
        this.height = 60;
    }

}