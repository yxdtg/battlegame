
export class lThrowingBullet {

    /**
     * id
     */
    public id: number;

    /**
     * 玩家id
     */
    public parentId: number;

    /**
     * 名称
     */
    public name: string;

    /**
     * 队伍id
     */
    public teamId: number;

    /**
     * 类型
     */
    public type: number;

    /**
     * x坐标
     */
    public x: number;

    /**
     * y坐标
     */
    public y: number;

    /**
     * 宽度
     */
    public width: number;

    /**
     * 高度
     */
    public height: number;

    /**
     * 攻击计数
     */
    public count: number;

    /**
     * 向量x
     */
    public vectorX: number;

    /**
     * 向量y
     */
    public vectorY: number;

    constructor(id: number, parentId: number, name: string, teamId: number, type: number, x: number, y: number, width: number, height: number, vectorX: number, vectorY: number, count: number) {
        this.id = id;
        this.parentId = parentId;
        this.name = name;
        this.teamId = teamId;
        this.type = type;

        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.vectorX = vectorX;
        this.vectorY = vectorY;

        this.count = count;
    }

}
