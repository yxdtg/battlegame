
import { _decorator, Component, Node, game, Vec2, instantiate, UITransform, Label } from 'cc';
import { lFirearm } from '../logic/lFirearm';
import { lFirearmBullet } from '../logic/lFirearmBullet';
import { lMedicine } from '../logic/lMedicine';
import { AudioManager } from './AudioManager';
import { NetManager } from './NetManager';
import { ResourceManager } from './ResourceManager';
import { SceneManager } from './SceneManager';
import { UIManager } from './UIManager';
const { ccclass, property } = _decorator;

/**
 * 游戏管理类
 */
@ccclass('GameManager')
export class GameManager extends Component {

    /**
     * 游戏管理器
     */
    public static instance: GameManager;

    private loadCount: number = 0; // 数据加载计数
    private loadMaxCount: number = 14; // 数据最大加载计数

    public isShowFps: boolean = false; // 是否显示游戏帧率
    private dtNum: number = 0; // 间隔时间
    private fpsCount: number = 0; // Fps计数

    onLoad() {
        GameManager.instance = this;
    }

    start() {
        this.initData();
    }

    update(dt: number) {
        if (this.isShowFps) {
            this.showFps(dt);
        }
    }

    // 初始化数据
    private initData(): void {
        SceneManager.instance.init();
        ResourceManager.instance.init();
        AudioManager.instance.init();
    }

    // 初始化游戏
    private initGame(): void {
        console.log("初始化游戏资源");

        ResourceManager.instance.initData();

        this.setGameFrame(61);

        SceneManager.instance.loadScene("Connect");
        // NetManager.instance.init();
        // this.logMap();
        // this.logData();
    }

    /**
     * 数据加载计数+1
     */
    public addLoadCount(): void {
        this.loadCount++;
        // console.log(this.loadCount);
        if (this.loadCount == this.loadMaxCount) {
            // 延迟到下一帧初始化游戏
            this.scheduleOnce(() => {
                this.initGame();
            }, 0)
        }
    }

    /**
     * 设置游戏帧率
     * @param value 帧率
     */
    public setGameFrame(value: number): void {
        game.frameRate = value;
    }

    /**
     * 设置显示游戏帧率
     * @param is boolean
     */
    public setShowFps(is: boolean): void {
        this.isShowFps = is;
    }

    /**
     * 退出游戏
     */
    public quitGame(): void {
        game.end();
    }

    /**
     * 显示游戏帧率
     * @param dt 帧间隔时间
     */
    private showFps(dt: number): void {
        this.dtNum += dt;
        this.fpsCount += 1;
        if (this.dtNum >= 1) {
            this.dtNum = 0;
            if (UIManager.instance.getUI("LabelFps") != undefined) {
                UIManager.instance.getUI("LabelFps").getComponent(Label).string = "FPS:" + this.fpsCount;
            }
            // console.log("Fps: " + this.fpsCount);
            this.fpsCount = 0;
        }
    }

    private logMap(): void {
        let map: Node = instantiate(ResourceManager.instance.getObject("Map0"));
        map.parent = this.node;
        map.setPosition(0, 0);

        let collideList: any[] = [];
        for (let i: number = 1; i < map.children.length; i++) {
            let house: Node = map.children[i];
            let layerBox: Node = house.getChildByName("LayerBox");
            for (let j: number = 0; j < layerBox.children.length; j++) {
                let box: Node = layerBox.children[j];
                collideList.push({ x: house.position.x + box.position.x, y: house.position.y + box.position.y, width: box.getComponent(UITransform).width, height: box.getComponent(UITransform).height });
            }
        }
        console.log(JSON.stringify(collideList));
    }

    private logData(): void {
        let r: number = -180;

        let vectorList: { [angle: number]: { x: number, y: number } } = {};
        for (let i: number = 0; i < 361; i++) {
            let z: any = r / 180 * Math.PI;
            let dx: any = Math.cos(z);
            let dy: any = Math.sin(z);
            let vector: { x: number, y: number } = this.getVector(dx, dy);
            vectorList[r] = vector;
            r++;
        }
        console.log(JSON.stringify(vectorList));
    }

    /**
     * 求向量
     * @param x x
     * @param y y
     * @returns // { x: vectorX, y: vecotrY }
     */
    private getVector(x: number, y: number): { x: number, y: number } {
        // let vectorX: number = y / (Math.sqrt(x * x + y * y));
        // let vecotrY: number = -x / (Math.sqrt(x * x + y * y));
        let vector: Vec2 = new Vec2(x, y);
        vector.normalize();
        let vectorX: number = Math.floor(vector.x * 1000) / 1000;
        let vecotrY: number = Math.floor(vector.y * 1000) / 1000;
        return { x: vectorX, y: vecotrY };
        // return { x: vector.x, y: vector.y };
    }



}