

import { _decorator, Component, Node, EditBox, Label, Color } from 'cc';
const { ccclass, property } = _decorator;

import { UIManager } from './UIManager';
import { SceneManager } from "./SceneManager";
import { network } from '../tool/network';
import { cmd } from '../tool/cmdClient';
import { MessageManager } from './MessageManager';
import { Logic } from '../scene/Logic';
import { GameManager } from './GameManager';
import { ResourceManager } from './ResourceManager';


/**
 * 帧数据
 */
type Frame = {
    c: number,
    d: any[]
};

// 错误码
let ErrorList: { [type: number]: string } = {
    0: "小队不存在",
    1: "匹配中无法执行该操作",
    2: "只有队长才可以执行该操作",
}

/**
 * 网络管理类
 */
@ccclass('NetManager')
export class NetManager extends Component {

    /**
     * 网络管理器
     */
    public static instance: NetManager;

    private logic_: Logic = undefined;

    /**
     * 用户uid
     */
    public uid_: number = -1;
    /**
     * 用户昵称
     */
    public name_: string = "";
    /**
     * 用户队组id
     */
    public groupId_: number = -1;
    /**
     * 用户房间id
     */
    public roomId_: number = -1;
    /**
     * 用户队伍id
     */
    public teamId_: number = -1;
    /**
     * 用户帧索引
     */
    public frame_: number = 0;
    /**
     * 服务器ip
     */
    public host: string = "127.0.0.1"; // 
    // private host: string = "47.110.94.166"; // 
    /**
     * 端口
     */
    private port: number = 4001;

    /**
     * 用户连接状态
     */
    public connectState: boolean = false;
    /**
     * 用户重连计数
     */
    private reconnectCount: number = 0;

    onLoad() {
        NetManager.instance = this;
    }

    start() {
        this.scheduleOnce(() => {
            this.sendHeartbeat();
        }, 3)
        this.scheduleOnce(() => {
            this.reconnect();
        }, 2)
    }

    /**
     * 继续重连
     */
    public reconnectCountClear(): void {
        this.reconnectCount = 0;
        UIManager.instance.getUI("PageReconnect").active = false;
    }

    // 重新连接
    public reconnect(): void {
        this.scheduleOnce(() => {
            this.reconnect();
        }, 2)

        if (this.uid_ != -1 && !this.connectState) {
            if (this.reconnectCount < 10) {
                MessageManager.instance.createMessage("尝试连接服务器", 0, 1);
                this.connectServer(this.host, this.port);
                this.reconnectCount++;
                if (this.reconnectCount == 10) {
                    if (this.roomId_ == -1) {
                        MessageManager.instance.createMessage("服务器或网络错误", 0, 1);
                        SceneManager.instance.loadScene("Login");
                    } else {
                        // 房间内
                        UIManager.instance.getUI("PageReconnect").active = true;
                    }
                }
            }
        }
    }

    /**
     * 初始化
     */
    public init(): void {
        network.onOpen(this.onOpen, this);
        network.onClose(this.onClose, this);

        this.connectServer(this.host, this.port);
    }

    /**
    * 初始化数据
    */
    private initData(): void {
        delete this.logic_;
        this.uid_ = -1;
        this.name_ = "";
        this.groupId_ = -1;
        this.roomId_ = -1;
        this.teamId_ = -1;
        this.frame_ = 0;
    }

    // 发送心跳包
    public sendHeartbeat(): void {
        this.scheduleOnce(() => {
            this.sendHeartbeat();
        }, 3)

        if (this.uid_ != -1) {
            if (this.connectState) {
                this.ping();
            }
        }
    }

    /**
     * 游戏结束
     */
    public gameOver(): void {
        // 初始化数据
        let uid: number = this.uid_;
        let name: string = this.name_;
        this.initData();
        this.uid_ = uid;
        this.name_ = name;

        SceneManager.instance.loadScene("Main");
    }


    /**
     * 连接服务器
     * @param host 地址
     * @param port 端口
     */
    private connectServer(host: string, port: number): void {
        network.connect(host, port);
    }

    /**
     * 注册消息监听
     */
    private addHandler(): void {
        network.onOpen(this.onOpen, this);
        network.onClose(this.onClose, this);

        network.addHandler(cmd.connector_main_ping, this.onPing, this);
        network.addHandler(cmd.connector_main_login, this.onLogin, this);
        network.addHandler(cmd.connector_main_group, this.onGroup, this);
        network.addHandler(cmd.connector_main_match, this.onMatch, this);
        network.addHandler(cmd.connector_main_frame, this.onFrame, this);
        network.addHandler(cmd.connector_main_room, this.onRoom, this);
        network.addHandler(cmd.connector_main_error, this.onError, this);
    }

    /**
     * 移除消息监听
     */
    private removeHandler(): void {
        network.offOpen();
        network.offClose();

        network.removeThisHandlers(this);
    }

    // 连接服务器成功
    private onOpen(): void {
        console.log("连接服务器成功");
        MessageManager.instance.createMessage("连接服务器成功", 0, 1);
        if (SceneManager.instance.currentSceneName == "Connect") {
            SceneManager.instance.loadScene("Login");
        }
        this.connectState = true;

        this.removeHandler();
        this.addHandler();

        if (this.uid_ != -1) {
            this.room(0);
        }
    }

    // 与服务器断开连接
    private onClose(): void {
        // this.connectState = false;
        if (SceneManager.instance.currentSceneName == "Connect") {
            UIManager.instance.getUI("ViewConnect").active = false;
            MessageManager.instance.createMessage("服务器连接错误", 0, 1);
        } else {
            MessageManager.instance.createMessage("与服务器断开连接", 0, 1);
        }
        console.log("与服务器断开连接");

    }

    // Ping消息监听
    private onPing(msg: any): void {
        // console.log(msg);
    }

    // 登录消息监听
    private onLogin(pack: any): void {
        let msg: { type: number, data: any[] } = this.getMsg(pack, ["type", "data"]);

        let types: string[] = ["登录成功"];
        let data: { uid: number, name: string } = { uid: msg.data[0], name: msg.data[1] };
        this.uid_ = data.uid;
        this.name_ = data.name;
        MessageManager.instance.createMessage(types[msg.type] + "欢迎, " + this.name_, 0, 1);
        console.log(types[msg.type] + ", " + "uid: " + this.uid_ + ", name: " + this.name_);
        SceneManager.instance.loadScene("Main");
    }

    // 队组消息监听
    public onGroup(pack: any): void {
        let msg: { type: number, data: any } = this.getMsg(pack, ["type", "data"]);

        let type: number = msg.type;
        let data: any = msg.data;
        let groupId: number = data[0];
        let groupList: any[] = data[1];

        // 创建队组
        if (type == 0) {
            console.log("创建队组");
            MessageManager.instance.createMessage("创建小队成功", 0, 1);
            UIManager.instance.getUI("PageGroup").active = true;
        }
        // 加入队组
        if (type == 1) {
            console.log("加入队组");
            MessageManager.instance.createMessage("加入小队成功", 0, 1);
            UIManager.instance.getUI("PageGroup").active = true;
        }
        // 离开队组
        if (type == 2) {
            console.log("离开队组");
            MessageManager.instance.createMessage("退出小队成功", 0, 1);
            UIManager.instance.getUI("PageGroup").active = false;
        }
        // 离开队组(被踢)
        if (type == 3) {
            console.log("离开队组(被踢)");
            MessageManager.instance.createMessage("您被踢出了小队", 0, 1);
            UIManager.instance.getUI("PageGroup").active = false;
        }
        // 更新队组
        if (type == 4) {
            // console.log("更新队组", groupList);
            this.groupId_ = groupId;
            UIManager.instance.getUI("LabelGroupId").getComponent(Label).string = "小队码: " + this.groupId_;
            let groupPlayerList: Node[] = UIManager.instance.getUI("LayoutGroup").children;
            for (let i: number = 0; i < groupPlayerList.length; i++) {
                let groupPlayer: Node = groupPlayerList[i];
                groupPlayer.getChildByName("Label").getComponent(Label).string = (i + 1) + "._";
                groupPlayer.getChildByName("Label").getComponent(Label).color = new Color(255, 255, 255, 255);
                groupPlayer.getChildByName("Button").active = false;
            }
            for (let i: number = 0; i < groupPlayerList.length; i++) {
                let groupPlayer: Node = groupPlayerList[i];
                if (i < groupList.length) {
                    groupPlayer.getChildByName("Label").getComponent(Label).string = (i + 1) + "._" + groupList[i].name;
                    if (groupList[i].name == this.name_) {
                        groupPlayer.getChildByName("Label").getComponent(Label).color = new Color(255, 0, 0, 255);
                    }
                    if (i != 0) {
                        groupPlayer.getChildByName("Button").active = true;
                    }
                }
            }
        }
    }

    // 匹配消息监听
    public onMatch(pack: any) {

        let msg: { type: number, data: any } = this.getMsg(pack, ["type", "data"]);

        // console.log(msg);
        let type: number = msg.type;
        let data: any = msg.data;

        // 匹配中
        if (type == 0) {
            console.log("匹配中");
            MessageManager.instance.createMessage("匹配中", 0, 1);
            UIManager.instance.getUI("ViewMatch").active = true;
        }
        // 匹配取消
        if (type == 1) {
            console.log("匹配取消");
            MessageManager.instance.createMessage("匹配取消", 0, 1);
            UIManager.instance.getUI("ViewMatch").active = false;
        }
        // 匹配成功
        if (type == 2) {
            console.log("匹配成功");
            MessageManager.instance.createMessage("匹配成功", 0, 1);
            this.roomId_ = data.roomId;
            console.log("房间id: " + this.roomId_);
            this.logic_ = new Logic();
            SceneManager.instance.loadScene("Game");
        }
    }

    // 帧数据
    public onFrame(pack: any): void {

        let msg: { type: number, data: any[] } = this.getMsg(pack, ["type", "data"]);

        // console.log(msg);
        if (this.roomId_ == -1) {
            return;
        }
        let type: number = msg.type;
        let data: Frame[] = msg.data;

        // 收到数据帧
        if (type == 0) {
            this.addFrame(data);
        }
    }

    // 房间
    public onRoom(pack: any): void {

        let msg: { type: number, data: any } = this.getMsg(pack, ["type", "data"]);

        let type: number = msg.type;
        let data: any = msg.data;

        console.log("重连"); // 2022年4月2日22:36:46 未完善 明天继续 拜拜cocos vscode 晚安
        // 完成 2022年4月3日11:36:07
        // 重连大厅
        if (type == 0) {
            console.log("重连大厅");
            console.log(msg);
            this.initData();
            this.uid_ = data.id;
            this.name_ = data.name;
            SceneManager.instance.loadScene("Main");
        }

        // 重连房间
        if (type == 1) {
            console.log("重连房间");
            console.log("Frame Count: " + data.length);
            for (let i: number = 0; i < data.length; i++) {
                this.addFrame(data[i]);
            }
        }

        // 房间不存在
        if (type == 2) {
            console.log("房间不存在");
            MessageManager.instance.createMessage("游戏已结束", 0, 1);
            this.gameOver();
            this.uid_ = data.id;
            this.name_ = data.name;
        }

    }

    // 错误码
    public onError(pack: any): void {
        let msg: { type: number } = this.getMsg(pack, ["type"]);
        // console.log(msg);
        MessageManager.instance.createMessage(ErrorList[msg.type], 0, 1);
    }

    /**
     * 心跳
     */
    public ping(): void {
        this.sendMessage(cmd.connector_main_ping, { uid: this.uid_ });
    }

    /**
     * 登录
     * @param name 昵称
     */
    public login(name: string): void {
        this.sendMessage(cmd.connector_main_login, { name: name });
    }

    /**
     * 队组
     * @param type 类型 0-创建 1-加入 2-离开 3-踢出
     */
    public group(type: number, removeId?: number): void {
        // console.log(type, this.uid_);
        // 创建队组
        if (type == 0) {
            this.sendMessage(cmd.connector_main_group, { type: type, uid: this.uid_ });
        }
        // 加入队组
        if (type == 1) {
            let str: string = UIManager.instance.getUI("EditBoxGroupId").getComponent(EditBox).string;
            if (str.length != 0) {
                let groupId: number = Number(str);
                this.sendMessage(cmd.connector_main_group, { type: type, uid: this.uid_, groupId: groupId });
            } else {
                console.log("队组id不可为空");
                MessageManager.instance.createMessage("小队码不可为空");
            }
        }
        // 离开队组
        if (type == 2) {
            this.sendMessage(cmd.connector_main_group, { type: type, uid: this.uid_, groupId: this.groupId_ });
        }
        // 队组中移除指定玩家
        if (type == 3) {
            this.sendMessage(cmd.connector_main_group, { type: type, uid: this.uid_, groupId: this.groupId_, removeId: removeId });
        }
    }

    /**
     * 匹配
     * @param type 类型 0-发起匹配 1-取消匹配
     */
    public match(type: number): void {
        // 发起匹配
        if (type == 0) {
            this.sendMessage(cmd.connector_main_match, { type: type, uid: this.uid_, groupId: this.groupId_ });
        }
        if (type == 1) {
            this.sendMessage(cmd.connector_main_match, { type: type, uid: this.uid_, groupId: this.groupId_ });
        }
    }

    /**
     * 帧数据
     * @param type 类型
     * @param data 数据
     */
    public frame(data: Frame[]): void {
        // 发送帧数据包
        this.sendMessage(cmd.connector_main_frame, { roomId: this.roomId_, data: data });
    }

    /**
     * 房间
     * @param type 类型
     */
    public room(type: number): void {
        // 断线重连
        if (type == 0) {
            this.sendMessage(cmd.connector_main_room, { type: type, uid: this.uid_, name: this.name_, roomId: this.roomId_, frame: this.frame_ });
        }
        // 退出房间
        if (type == 1) {
            this.sendMessage(cmd.connector_main_room, { type: type, uid: this.uid_, name: "", roomId: this.roomId_, frame: 0 });
        }
    }

    /**
     * 收到帧数据
     * @param frame 
     */
    private addFrame(frame: Frame[]): void {
        this.frame_ += 1;
        Logic.instance.addFrame(frame);
        Logic.instance.addFrame([]);
        // Logic.instance.addFrame([]);
    }

    /**
     * 向服务器发送消息
     * @param cmd_ 消息类型
     * @param data_ 消息数据
     */
    public sendMessage(cmd_: cmd, data_: any): void {
        // console.log("处理前:", data_);
        let datas: any[] = [];
        for (let s in data_) {
            datas.push(data_[s]);
        }
        // console.log("处理后: ", datas);
        network.sendMsg(cmd_, datas);
    }

    private getMsg(data: any[], msgList: string[]): any {
        let msg: any = {};
        for (let i: number = 0; i < msgList.length; i++) {
            msg[msgList[i]] = data[i];
        }
        return msg;
    }

    update() {
        network.readMsg();
    }
}
