
import { _decorator, Component, Node, resources, Prefab, SpriteFrame, Sprite } from 'cc';
import { lArmor } from '../logic/lArmor';
import { lFirearm } from '../logic/lFirearm';
import { lFirearmBullet } from '../logic/lFirearmBullet';
import { lHelmet } from '../logic/lHelmet';
import { lMedicine } from '../logic/lMedicine';
import { lPack } from '../logic/lPack';
import { lThrowing } from '../logic/lThrowing';
import { GameManager } from './GameManager';
const { ccclass, property } = _decorator;

/**
 * 资源管理类
 */
@ccclass('ResourceManager')
export class ResourceManager extends Component {

    /**
     * 资源管理器
     */
    public static instance: ResourceManager;

    // 对象集合
    private objectList: { [name: string]: Prefab } = {};

    // 图片集合
    private imageList: { [name: string]: SpriteFrame } = {};

    private itemSizeList: { [name: string]: number[] } = {};

    public vectorList: { [angle: number]: { x: number, y: number } } = {};

    public nameList: string[] = [];
    public mapList: { [id: number]: any[] } = {};
    public medicineList: lMedicine[] = []; // 药品列表
    public throwingList: lThrowing[] = []; // 投资物列表
    public firearmList: lFirearm[] = []; // 枪械列表
    public firearmBulletList: lFirearmBullet[] = []; // 子弹列表
    public helmetList: lHelmet[] = []; // 头盔列表
    public armorList: lArmor[] = []; // 盔甲列表
    public packList: lPack[] = []; // 背包列表

    /**
     * 物资名称列表
     */
    public itemNameList: { [name: string]: string } = {};
    public frameRate: number = 40; // 逻辑帧率

    onLoad() {
        ResourceManager.instance = this;
    }

    /**
     * 初始化
     */
    public init(): void {

        resources.loadDir("prefab/object", Prefab, (err: Error, data: Prefab[]) => {
            if (err) {
                console.log("对象资源加载错误", err);
                return;
            }

            for (let object of data) {
                this.objectList[object.data.name] = object;
            }

            GameManager.instance.addLoadCount();
            console.log("对象资源加载完成");
            // console.log(this.objectList);
        })

        resources.loadDir("image", SpriteFrame, (err: Error, data: SpriteFrame[]) => {
            if (err) {
                console.log("图片资源加载错误", err);
                return;
            }

            for (let image of data) {
                this.imageList[image.name] = image;
            }

            GameManager.instance.addLoadCount();
            console.log("图片资源加载完成");
            // console.log(this.imageList);

        })

        resources.load("json/table/vector", (err: Error, data: any) => {
            if (err) {
                console.log("json加载错误", err);
                return;
            }

            this.vectorList = data.json;
            GameManager.instance.addLoadCount();
        })


        resources.load("json/table/name", (err: Error, data: any) => {
            if (err) {
                console.log("json加载错误", err);
                return;
            }

            this.nameList = data.json.data;
            // console.log(this.nameList);
            GameManager.instance.addLoadCount();
        })

        resources.load("json/table/firearm", (err: Error, data: any) => {
            if (err) {
                console.log("firearm数据加载错误", err);
                return;
            }

            let objList: lFirearm[] = data.json;
            for (let i: number = 0; i < objList.length; i++) {
                let obj: lFirearm = objList[i];
                this.itemNameList["firearm_" + obj.name] = (obj as any).fName;
                this.addFirearm(obj.name, obj.type, obj.sType, obj.attackType, obj.attack, obj.bulletSpeed, obj.bulletRange, obj.bulletType, obj.bulletMaxCount, obj.attackCountMax, obj.reloadMaxTime);
            }

            GameManager.instance.addLoadCount();
        })

        resources.load("json/table/medicine", (err: Error, data: any) => {
            if (err) {
                console.log("medicine数据加载错误", err);
                return;
            }

            let objList: lMedicine[] = data.json;
            for (let i: number = 0; i < objList.length; i++) {
                let obj: lMedicine = objList[i];
                this.itemNameList["medicine_" + obj.name] = (obj as any).fName;
                this.addMedicine(obj.name, obj.weight, obj.timeMax);
            }

            GameManager.instance.addLoadCount();
        })

        resources.load("json/table/throwing", (err: Error, data: any) => {
            if (err) {
                console.log("throwing数据加载错误", err);
                return;
            }

            let objList: lThrowing[] = data.json;
            for (let i: number = 0; i < objList.length; i++) {
                let obj: lThrowing = objList[i];
                this.itemNameList["throwing_" + obj.name] = (obj as any).fName;
                this.addThrowing(obj.name, obj.type, obj.weight, obj.timeMax);
            }

            GameManager.instance.addLoadCount();
        })

        resources.load("json/table/bullet", (err: Error, data: any) => {
            if (err) {
                console.log("bullet数据加载错误", err);
                return;
            }

            let objList: lFirearmBullet[] = data.json;
            for (let i: number = 0; i < objList.length; i++) {
                let obj: lFirearmBullet = objList[i];
                this.itemNameList["bullet_" + obj.name] = (obj as any).fName;
                this.addFirearmBullet(obj.name, obj.weight, obj.type);
            }

            GameManager.instance.addLoadCount();
        })

        resources.load("json/table/helmet", (err: Error, data: any) => {
            if (err) {
                console.log("helmet数据加载错误", err);
                return;
            }

            let objList: lHelmet[] = data.json;
            for (let i: number = 0; i < objList.length; i++) {
                let obj: lHelmet = objList[i];
                this.itemNameList["helmet_" + obj.name] = (obj as any).fName;
                this.addHelmet(obj.name, obj.type, obj.armor);
            }

            GameManager.instance.addLoadCount();
        })

        resources.load("json/table/armor", (err: Error, data: any) => {
            if (err) {
                console.log("armor数据加载错误", err);
                return;
            }

            let objList: lArmor[] = data.json;
            for (let i: number = 0; i < objList.length; i++) {
                let obj: lArmor = objList[i];
                this.itemNameList["armor_" + obj.name] = (obj as any).fName;
                this.addArmor(obj.name, obj.type, obj.armor);
            }

            GameManager.instance.addLoadCount();
        })

        resources.load("json/table/pack", (err: Error, data: any) => {
            if (err) {
                console.log("pack数据加载错误", err);
                return;
            }

            let objList: lPack[] = data.json;
            for (let i: number = 0; i < objList.length; i++) {
                let obj: lPack = objList[i];
                this.itemNameList["pack_" + obj.name] = (obj as any).fName;
                this.addPack(obj.name, obj.type, obj.weight);
            }

            GameManager.instance.addLoadCount();
        })

        resources.load("json/map/map0", (err: Error, data: any) => {
            if (err) {
                console.log("map数据加载错误", err);
                return;
            }

            this.mapList[0] = data.json;
            GameManager.instance.addLoadCount();
        })
    }

    // 获取随机昵称
    public getRandomName(): string {
        let index: number = Math.round(Math.random() * (this.nameList.length - 1));
        let name: string = this.nameList[index];
        return name;
    }

    /**
     * 获取指定对象资源
     * @param name 对象名称
     * @returns 对象资源
     */
    public getObject(name: string): Prefab {
        return this.objectList[name];
    }

    /**
     * 获取指定图片资源
     * @param name 图片名称
     * @returns 图片资源
     */
    public getImage(name: string): SpriteFrame {
        return this.imageList[name];
    }

    /**
     * 获取指定物资尺寸
     * @param name 物资名称
     * @returns 尺寸列表
     */
    public getItemSize(name: string): number[] {
        return this.itemSizeList[name];
    }

    /**
     * 初始化资源尺寸
     * @param nameList 
     */
    private initResSize(nameList: string[]): void {
        let s: number = 0.75;
        // console.log(nameList);
        for (let i: number = 0; i < nameList.length; i++) {
            let name: string = nameList[i];
            let sprite: SpriteFrame = this.getImage("item_" + name);
            this.itemSizeList[name] = [sprite.width * s, sprite.height * s];
        }
    }

    /**
     * 初始化数据
     */
    public initData(): void {
        // console.log(this.getResNameData());
        this.initResSize(this.getResNameData());
    }

    /**
     * 获取资源名称数据
     * @returns 
     */
    public getResNameData(): string[] {
        let nameList: string[] = [];
        for (let i: number = 0; i < this.firearmList.length; i++) {
            nameList.push(this.firearmList[i].name);
        }
        for (let i: number = 0; i < this.medicineList.length; i++) {
            nameList.push(this.medicineList[i].name);
        }
        for (let i: number = 0; i < this.throwingList.length; i++) {
            nameList.push(this.throwingList[i].name);
        }
        for (let i: number = 0; i < this.firearmBulletList.length; i++) {
            nameList.push(this.firearmBulletList[i].name);
        }
        for (let i: number = 0; i < this.helmetList.length; i++) {
            nameList.push(this.helmetList[i].name);
        }
        for (let i: number = 0; i < this.armorList.length; i++) {
            nameList.push(this.armorList[i].name);
        }
        for (let i: number = 0; i < this.packList.length; i++) {
            nameList.push(this.packList[i].name);
        }

        return nameList;
    }

    /**
     * 添加枪械数据
     * @param name 名字
     * @param type 枪械类型
     * @param attack 攻击力
     * @param bulletType 子弹类型
     * @param bulletMaxCount 弹容量
     * @param attackCountMax 攻击间隔
     * @param reloadMaxTime 换弹时间
     */
    private addFirearm(name: string, type: number, sType: number, attackType: number, attack: number, bulletSpeed: number, bulletRange: number, bulletType: number, bulletMaxCount: number, attackCountMax: number, reloadMaxTime: number,): void {
        let firearm: lFirearm = new lFirearm(0, "firearm_" + name, type, sType, attackType, attack, bulletSpeed, this.mul(bulletRange, this.frameRate), bulletType, bulletMaxCount, this.mul(attackCountMax, this.frameRate), this.mul(reloadMaxTime, this.frameRate));
        this.firearmList.push(firearm);
    }

    /**
     * 添加药品数据
     * @param name 名称
     * @param timeMax 使用时间
     */
    private addMedicine(name: string, weight: number, timeMax: number): void {
        let medicine: lMedicine = new lMedicine(0, "medicine_" + name, weight, 0, this.mul(timeMax, this.frameRate));
        this.medicineList.push(medicine);
    }

    /**
     * 添加投掷物数据
     * @param name 名称
     * @param timeMax 触发时间
     */
    private addThrowing(name: string, type: number, weight: number, timeMax: number): void {
        let throwing: lThrowing = new lThrowing(0, 0, "throwing_" + name, type, weight, 0, this.mul(timeMax, this.frameRate));
        this.throwingList.push(throwing);
    }

    /**
     * 添加子弹数据
     * @param name 名称
     * @param type 类型
     */
    private addFirearmBullet(name: string, weight: number, type: number): void {
        let firearmBullet: lFirearmBullet = new lFirearmBullet(0, "bullet_" + name, type, weight, 0);
        this.firearmBulletList.push(firearmBullet);
    }

    /**
     * 添加头盔数据
     * @param name 名称
     * @param type 类型
     */
    private addHelmet(name: string, type: number, armor: number): void {
        let helmet: lHelmet = new lHelmet(0, "helmet_" + name, type, armor);
        this.helmetList.push(helmet);
    }

    /**
     * 添加盔甲数据
     * @param name 名称
     * @param type 类型
     */
     private addArmor(name: string, type: number, armor: number): void {
        let larmor: lArmor = new lArmor(0, "armor_" + name, type, armor);
        this.armorList.push(larmor);
    }

    /**
     * 添加背包数据
     * @param name 名称
     * @param type 类型
     */
    private addPack(name: string, type: number, weight: number): void {
        let pack: lPack = new lPack(0, "pack_" + name, type, weight);
        this.packList.push(pack);
    }

    /**
     * 两数相乘
     * @param num1 数1
     * @param num2 数2
     * @returns num1 * num2
     */
    private mul(num1: number, num2: number): number {
        return Math.ceil(Math.floor((num1 * 1000) * (num2 * 1000)) / 1000000);
    }
}
