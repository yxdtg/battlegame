
import { _decorator, Component, Node } from 'cc';
import { NetManager } from '../manager/NetManager';
import { UIManager } from '../manager/UIManager';
const { ccclass, property } = _decorator;

@ccclass('Connect')
export class Connect extends Component {

    private hostList: string[] = ["127.0.0.1", "47.110.94.166", "47.110.53.253"];

    public setSeverHost(a: any, b: string): void {
        let type: number = Number(b);
        NetManager.instance.host = this.hostList[type];
        UIManager.instance.getUI("ViewConnect").active = true;
        NetManager.instance.init();
    }

}
