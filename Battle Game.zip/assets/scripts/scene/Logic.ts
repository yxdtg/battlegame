
import { _decorator, Vec2 } from 'cc';
import { lBullet } from '../logic/lBullet';
import { lPlayer } from '../logic/lPlayer';
import intersects from 'intersects';
import { Game } from './Game';
import { lMedicine } from '../logic/lMedicine';
import { lItem } from '../logic/lItem';
import { lFirearm } from '../logic/lFirearm';
import { lFirearmBullet } from '../logic/lFirearmBullet';
import { ResourceManager } from '../manager/ResourceManager';
import { lThrowing } from '../logic/lThrowing';
import { lThrowingBullet } from '../logic/lThrowingBullet';
import { lHelmet } from '../logic/lHelmet';
import { lSmoke } from '../logic/lSmoke';
import { lPack } from '../logic/lPack';
import { lArmor } from '../logic/lArmor';
const { ccclass, property } = _decorator;

/**
 * 帧数据
 */
type Frame = {
    /**
     * 指令
     */
    c: number,
    /**
     * 数据
     */
    d: any[]
};

/**
 * 碰撞类
 */
type Collide = {
    /**
     * x坐标
     */
    x: number,
    /**
     * y坐标
     */
    y: number,
    /**
     * 宽度
     */
    width: number,
    /**
     * 高度
     */
    height: number
}

/**
 * 物资类型
 */
enum ItemType {
    /**
     * 药品
     */
    Medicine,
    /**
     * 枪械
     */
    Firearm,
    /**
     * 子弹
     */
    Bullet,
    /**
     * 投掷物
     */
    Throwing,
    /**
     * 头盔
     */
    Helmet,
    /**
     * 盔甲
     */
    Armor,
    /**
     * 背包
     */
    Pack,
}

/**
 * 玩家使用状态
 */
enum PlayerUseState {
    /**
     * 空闲
     */
    None,
    /**
     * 使用药品
     */
    Medicine,
    /**
     * 准备使用投掷物
     */
    Throwing,
    /**
     * 换弹中
     */
    Reload,
    /**
     * 救助队友
     */
    Rescue,
}

/**
 * 逻辑层管理类
 */
export class Logic {

    /**
     * 逻辑层管理器
     */
    public static instance: Logic;

    /**
     * 指令列表
     */
    private cmdList: { [index: number]: string };

    /**
     * 角度向量列表
     */
    private vectorList: { [angle: number]: { x: number, y: number } };
    /**
     * 药品列表
     */
    private medicineList: lMedicine[];
    /**
     * 枪械列表
     */
    private firearmList: lFirearm[];
    /**
     * 投掷物列表
     */
    private throwingList: lThrowing[];
    /**
     * 投掷物子弹列表
     */
    private throwingBulletList: lThrowingBullet[];
    /**
     * 烟雾列表
     */
    private smokeList: lSmoke[];
    /**
     * 枪械子弹列表
     */
    private firearmBulletList: lFirearmBullet[];
    /**
     * 头盔列表
     */
    private helmetList: lHelmet[];
    /**
     * 盔甲列表
     */
    private armorList: lArmor[];
    /**
     * 背包列表
     */
    private packList: lPack[];

    /**
     * 逻辑帧率
     */
    public frameRate: number;
    /**
     * 随机数种子
     */
    private seed: number;

    /**
     * 执行数据 帧率
     */
    private fpsNum: number;
    /**
     * 执行数据 计数
     */
    private dtNum: number;

    /**
     * 帧数据列表
     */
    private frameList: Frame[][];
    /**
     * 帧索引
     */
    private frameIndex: number;

    /**
     * 碰撞列表
     */
    private collideList: Collide[];
    /**
     * 玩家列表
     */
    private playerList: lPlayer[];
    /**
     * 子弹列表
     */
    private bulletList: lBullet[];
    /**
     * 物资列表
     */
    private itemList: lItem[];

    /**
     * 唯一id
     */
    private id: number;

    /**
     * 地图宽度
     */
    private mapWidth: number;
    /**
     * 地图高度
     */
    private mapHeight: number;
    /**
     * 地图 1/2 X
     */
    private mapX: number;
    /**
     * 地图 1/2 Y
     */
    private mapY: number;

    /**
     * 玩家存活计数
     */
    private surviveCount: number;

    /**
     * 能量效果计数
     */
    private mpCount: number;
    /**
     * 能量效果计数上限
     */
    private mpMaxCount: number;

    /**
     * 安全区域范围
     */
    private circleR: number;
    /**
     * 安全区域外攻击力
     */
    private circleAttack: number;
    /**
     * 安全区域收缩间隔计数
     */
    private circleTime: number;
    /**
     * 安全区域最大收缩间隔
     */
    private circleMaxTime: number;
    /**
     * 安全区域收缩计数
     */
    private circleCount: number;
    /**
     *  安全区域收缩最大计数
     */
    private circleMaxCount: number;

    /**
     * 机器人逻辑更新计数
     */
    private robotCount: number;
    /**
     * 机器人逻辑最大更新计数
     */
    private robotMaxCount: number;

    /**
     * 是否初始化
     */
    private isInit: boolean;
    /**
     * 战斗是否结束
     */
    private isOver: boolean;

    /**
     * 开始战斗计数
     */
    private startCount: number;

    /**
     * 游戏时间
     */
    private gameTime: number;
    /**
     * 游戏时间更新计数
     */
    private gameTimeCount: number;
    /**
     * 游戏时间最大更新计数
     */
    private gameTimeMaxCount: number;

    constructor() {
        Logic.instance = this;

        this.cmdList = {
            0: "setSeed",
            1: "createPlayer",
            2: "setPlayerVector",
            3: "setPlayerAttack",
            4: "playerPickItem",
            5: "setPlayerMedicine",
            6: "setPlayerWeaponIndex",
            7: "setPlayerFirearmBullet",
            8: "playerThrowItem",
            9: "playerRescue",
            10: "setPlayerThrowing",
            11: "setWeaponIndexSwap",
            12: "setPlayerAngle",
        };

        this.vectorList = ResourceManager.instance.vectorList;
        this.medicineList = ResourceManager.instance.medicineList;
        this.firearmList = ResourceManager.instance.firearmList;
        this.throwingList = ResourceManager.instance.throwingList;
        this.firearmBulletList = ResourceManager.instance.firearmBulletList;
        this.helmetList = ResourceManager.instance.helmetList;
        this.armorList = ResourceManager.instance.armorList;
        this.packList = ResourceManager.instance.packList;
        this.collideList = ResourceManager.instance.mapList[0];

        this.throwingBulletList = [];
        this.smokeList = [];

        this.frameRate = ResourceManager.instance.frameRate;

        this.seed = 999;

        this.fpsNum = 1 / (this.frameRate + 1);
        this.dtNum = 0;

        this.frameList = [];
        this.frameIndex = 0;

        this.playerList = [];
        this.bulletList = [];
        this.itemList = [];

        this.id = 0;

        this.mapWidth = 20000;
        this.mapHeight = 20000;
        this.mapX = this.mapWidth / 2;
        this.mapY = this.mapHeight / 2;

        this.surviveCount = 0;

        this.mpCount = 0;
        this.mpMaxCount = 3 * this.frameRate;

        this.circleR = 30000;
        this.circleAttack = 10;
        this.circleTime = 0;
        this.circleMaxTime = 45 * this.frameRate;
        this.circleCount = 0;
        this.circleMaxCount = 25 * this.frameRate;

        this.robotCount = 0;
        this.robotMaxCount = 15;

        this.isInit = false;
        this.isOver = false;

        this.startCount = 5 * this.frameRate;
        this.gameTime = 0;
        this.gameTimeCount = 0;
        this.gameTimeMaxCount = this.frameRate;
    }

    /**
     * 收到数据帧
     * @param frameData 数据
     */
    public addFrame(frameData: Frame[]): void {
        this.frameList.push(frameData);
    }

    /**
     * 驱动帧循环
     */
    private actuatedFrame(): void {
        let frameCount: number = this.frameList.length - this.frameIndex;
        // console.log("frameCount: " + frameCount);

        if (frameCount > 100) {
            for (let i: number = 0; i < 100; i++) {
                this.executeFrame();
            }
        } else {
            if (frameCount > 50) {
                for (let i: number = 0; i < 50; i++) {
                    this.executeFrame();
                }
            } else {
                if (frameCount > 1) {
                    for (let i: number = 0; i < frameCount - 1; i++) {
                        this.executeFrame();
                    }
                } else {
                    this.executeFrame();
                }
            }
        }

        // frameCount = this.frameList.length - this.frameIndex;
        // console.log("frameCount: " + (this.frameList.length - this.frameIndex));
    }

    /**
     * 执行帧指令
     */
    private executeFrame(): void {

        if (this.frameIndex == this.frameList.length) {
            return;
        }

        for (let i: number = 0; i < this.frameList[this.frameIndex].length; i++) {
            let frame: Frame = this.frameList[this.frameIndex][i];
            // console.log(frame);

            this[this.cmdList[frame.c]](frame.d);
        }

        this.frameIndex++;

        this.updateData();
    }

    /**
     * 设置随机数种子
     */
    private setSeed(msg: any[]): void {
        let data: { seed: number } = {
            seed: msg[0],
        };

        this.seed = data.seed;
        console.log("随机数种子:" + this.seed);

        let pos: number = 9500;
        // let name: string = "medicine_";
        // 创建药品
        for (let i: number = 0; i < 64; i++) {
            this.createItem("medicine_0", ItemType.Medicine, this.randomRangeInt(1, 3), this.randomRange(-pos, pos), this.randomRange(-pos, pos));
        }
        for (let i: number = 0; i < 48; i++) {
            this.createItem("medicine_1", ItemType.Medicine, this.randomRangeInt(1, 2), this.randomRange(-pos, pos), this.randomRange(-pos, pos));
        }
        for (let i: number = 0; i < 24; i++) {
            this.createItem("medicine_2", ItemType.Medicine, this.randomRangeInt(1, 1), this.randomRange(-pos, pos), this.randomRange(-pos, pos));
        }

        // 创建手雷
        for (let i: number = 0; i < 48; i++) {
            this.createItem("throwing_0", ItemType.Throwing, this.randomRangeInt(1, 2), this.randomRange(-pos, pos), this.randomRange(-pos, pos));
        }

        // 创建烟雾弹
        for (let i: number = 0; i < 32; i++) {
            this.createItem("throwing_1", ItemType.Throwing, this.randomRangeInt(1, 2), this.randomRange(-pos, pos), this.randomRange(-pos, pos));
        }

        // 创建头盔
        for (let i: number = 0; i < 48; i++) {
            this.createItem("helmet_" + 1, ItemType.Helmet, 1, this.randomRange(-pos, pos), this.randomRange(-pos, pos));
        }
        // 创建头盔
        for (let i: number = 0; i < 24; i++) {
            this.createItem("helmet_" + 2, ItemType.Helmet, 1, this.randomRange(-pos, pos), this.randomRange(-pos, pos));
        }
        // 创建头盔
        for (let i: number = 0; i < 8; i++) {
            this.createItem("helmet_" + 3, ItemType.Helmet, 1, this.randomRange(-pos, pos), this.randomRange(-pos, pos));
        }
        // 创建头盔
        for (let i: number = 0; i < 8; i++) {
            this.createItem("helmet_" + 4, ItemType.Helmet, 1, this.randomRange(-pos, pos), this.randomRange(-pos, pos));
        }

        // 创建盔甲
        for (let i: number = 0; i < 48; i++) {
            this.createItem("armor_" + 1, ItemType.Armor, 1, this.randomRange(-pos, pos), this.randomRange(-pos, pos));
        }

        // 创建盔甲
        for (let i: number = 0; i < 24; i++) {
            this.createItem("armor_" + 2, ItemType.Armor, 1, this.randomRange(-pos, pos), this.randomRange(-pos, pos));
        }

        // 创建盔甲
        for (let i: number = 0; i < 8; i++) {
            this.createItem("armor_" + 3, ItemType.Armor, 1, this.randomRange(-pos, pos), this.randomRange(-pos, pos));
        }

        // 创建盔甲
        for (let i: number = 0; i < 8; i++) {
            this.createItem("armor_" + 4, ItemType.Armor, 1, this.randomRange(-pos, pos), this.randomRange(-pos, pos));
        }

        for (let i: number = 0; i < 24; i++) {
            this.createItem("pack_" + 0, ItemType.Pack, 1, this.randomRange(-pos, pos), this.randomRange(-pos, pos));
        }
        for (let i: number = 0; i < 18; i++) {
            this.createItem("pack_" + 1, ItemType.Pack, 1, this.randomRange(-pos, pos), this.randomRange(-pos, pos));
        }
        for (let i: number = 0; i < 12; i++) {
            this.createItem("pack_" + 2, ItemType.Pack, 1, this.randomRange(-pos, pos), this.randomRange(-pos, pos));
        }

        let firearmMinBullets: { [type: number]: number } = {
            0: 40,
            1: 10,
            2: 10,
            3: 10,
            4: 20,
            5: 3,
            6: 20,
        };

        let firearmMaxBullets: { [type: number]: number } = {
            0: 80,
            1: 20,
            2: 20,
            3: 20,
            4: 40,
            5: 3,
            6: 40,
        };

        let firearmMaxCounts: { [type: number]: number } = {
            0: 48,
            1: 48,
            2: 48,
            3: 48,
            4: 48,
            5: 8,
            6: 48,
        };

        // 创建武器
        for (let i: number = 0; i < 7; i++) {
            let type: number = i;
            for (let j: number = 0; j < firearmMaxCounts[type]; j++) {
                let posX: number = this.randomRange(-pos, pos);
                let posY: number = this.randomRange(-pos, pos);
                this.createFirearm(posX, posY, type, this.randomRangeInt(firearmMinBullets[type], firearmMaxBullets[type]));
            }
        }

        // 创建子弹
        for (let i: number = 0; i < 256; i++) {
            let posX: number = this.randomRange(-pos, pos);
            let posY: number = this.randomRange(-pos, pos);
            let type: number = this.randomInt(2);
            this.createItem("bullet_" + type, ItemType.Bullet, this.randomRangeInt(40, 80), posX, posY);
        }

        // 创建子弹
        for (let i: number = 0; i < 128; i++) {
            let posX: number = this.randomRange(-pos, pos);
            let posY: number = this.randomRange(-pos, pos);
            let type: number = this.randomInt(2);
            this.createItem("bullet_" + type, ItemType.Bullet, this.randomRangeInt(80, 160), posX, posY);
        }
    }

    /**
     * 设置玩家移动向量
     */
    private setPlayerVector(msg: any[]): void {
        let data: { id: number, angle: number, type: number } = {
            id: msg[0],
            angle: msg[1],
            type: msg[2]
        };

        let player: lPlayer = this.getPlayer(data.id);
        if (player == undefined) {
            return;
        }

        if (data.type == 1) {
            let vector: { x: number, y: number } = this.getAngleVector(data.angle);
            player.vectorX = vector.x;
            player.vectorY = vector.y;
        } else {
            player.vectorX = 0;
            player.vectorY = 0;
        }
    }

    /**
     * 设置玩家角度
     */
    private setPlayerAngle(msg: any[]): void {
        let data: { id: number, angle: number } = {
            id: msg[0],
            angle: msg[1],
        };

        let player: lPlayer = this.getPlayer(data.id);
        if (player == undefined) {
            return;
        }

        let vector: { x: number, y: number } = this.getAngleVector(data.angle);
        player.angle = data.angle;
        player.angleX = vector.x;
        player.angleY = vector.y;
    }

    /**
     * 设置玩家攻击状态
     */
    private setPlayerAttack(msg: any[]): void {
        let data: { id: number, type: number } = {
            id: msg[0],
            type: msg[1],
        };

        let player: lPlayer = this.getPlayer(data.id);
        if (player == undefined) {
            return;
        }

        // 松开 处理一次性攻击
        if (data.type == 0) {
            if (player.state == 0) {
                if (player.useState == PlayerUseState.None) {
                    let firearm: lFirearm = player.firearmList[player.firearmIndex];
                    if (firearm != undefined) {
                        if (firearm.attackType == 1) {
                            if (firearm.attackCount == firearm.attackCountMax) {
                                firearm.attackCount = 0;
                                if (firearm.bulletCount > 0) {
                                    firearm.bulletCount -= 1;
                                    Game.instance.playerFirearmAudio(0, player.x, player.y);
                                    if (firearm.type == 1 || firearm.type == 4) {
                                        this.createBullet(player.id, player.teamId, firearm.bulletType, firearm.attack, player.x, player.y, player.angleX, player.angleY, firearm.bulletSpeed, firearm.bulletRange);
                                    }
                                    if (firearm.type == 2) {
                                        let s: number = 0;
                                        let r: number = 0;
                                        if (firearm.sType == 0) {
                                            s = 3;
                                            r = 7;
                                        }
                                        if (firearm.sType == 1) {
                                            s = 5;
                                            r = 5;
                                        }
                                        let angle: number = this.getAngleR(player.angle - (Math.ceil(s / 2) * r));
                                        for (let j: number = 0; j < s; j++) {
                                            angle += r;
                                            let angleR: number = this.getAngleR(angle);
                                            let vector: { x: number, y: number } = this.getAngleVector(angleR);
                                            this.createBullet(player.id, player.teamId, firearm.bulletType, firearm.attack, player.x, player.y, vector.x, vector.y, firearm.bulletSpeed, firearm.bulletRange);
                                        }
                                    }
                                    if (player.id == Game.instance.uid) {
                                        Game.instance.updateFirearmBullet(player);
                                        Game.instance.updatePlayerPack(player);
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (player.useState == PlayerUseState.Throwing) {
                        let throwing: lThrowing = player.throwingList[0];
                        if (throwing != undefined) {
                            throwing.count -= 1;

                            this.createThrowingBullet(throwing.parentId, throwing.name, player.teamId, throwing.type, player.x, player.y, 50, 50, this.mul(player.angleX, 12), this.mul(player.angleY, 12), 3 * this.frameRate);

                            if (throwing.count == 0) {
                                player.throwingList.splice(0, 1);
                                player.useState = PlayerUseState.None;
                            }

                            this.updatePlayerWeight(player);

                            Game.instance.updatePlayerItem(player);
                            if (player.id == Game.instance.uid) {
                                Game.instance.updateThrowing(player.throwingList);
                                Game.instance.updatePlayerPack(player);
                                Game.instance.updatePlayerWeight(player);
                            }
                        }
                    }
                }
            }

            player.isAttack = false;
        } else {
            // 持续攻击
            player.isAttack = true;
            let firearm: lFirearm = player.firearmList[player.firearmIndex];
            if (firearm != undefined) {
                if (firearm.bulletCount == 0) {
                    let bullet: lFirearmBullet = this.getPlayerFirearmBullet(player.bulletList, firearm.bulletType);
                    if (bullet != undefined) {
                        this.setPlayerFirearmBullet([player.id, 0]);
                    }
                }
            }

        }
    }

    /**
     * 玩家操作药品
     */
    private setPlayerMedicine(msg: any[]): void {
        let data: { id: number, type: number, index: number } = {
            id: msg[0],
            type: msg[1],
            index: msg[2],
        };

        // console.log(data);

        let player: lPlayer = this.getPlayer(data.id);
        if (player == undefined) {
            return;
        }

        if (player.state != 0) {
            return;
        }

        if (player.medicineList[0] == undefined) {
            return;
        }

        // 使用药品
        if (data.type == 0) {
            if (player.useState == PlayerUseState.None || player.useState == PlayerUseState.Throwing) {
                player.useState = PlayerUseState.Medicine;
            }
        }

        // 取消使用药品
        if (data.type == -1) {
            if (player.useState == PlayerUseState.Medicine) {
                player.useState = PlayerUseState.None;
                if (player.medicineList[0] != undefined) {
                    player.medicineList[0].time = 0;
                }
            }
        }

        Game.instance.updatePlayerItem(player);

        // 使用中无法选择药品
        if (player.useState == PlayerUseState.Medicine) {
            return;
        }
        // 选择药品索引
        if (data.type == 1) {
            if (player.medicineList[data.index] != undefined) {
                player.medicineList = this.arrIndexA(player.medicineList, data.index);
                if (player.id == Game.instance.uid) {
                    Game.instance.updateMedicine(player.medicineList);
                }
            }
        }
    }

    /**
     * 玩家操作投掷物
     */
    private setPlayerThrowing(msg: any[]): void {
        let data: { id: number, type: number, index: number } = {
            id: msg[0],
            type: msg[1],
            index: msg[2],
        };

        // console.log(data);

        let player: lPlayer = this.getPlayer(data.id);
        if (player == undefined) {
            return;
        }

        if (player.state != 0) {
            return;
        }

        // 准备投掷
        if (data.type == 0) {
            if (player.throwingList.length > 0) {
                if (player.useState == PlayerUseState.None) {
                    player.useState = PlayerUseState.Throwing;
                } else {
                    if (player.useState == PlayerUseState.Throwing) {
                        player.useState = PlayerUseState.None;
                    }
                }
            }
        }

        // 选择投掷物索引
        if (data.type == 1) {
            if (player.throwingList[data.index] != undefined) {
                player.throwingList = this.arrIndexA(player.throwingList, data.index);
                if (player.id == Game.instance.uid) {
                    Game.instance.updateThrowing(player.throwingList);
                }
            }
        }

        Game.instance.updatePlayerItem(player);
    }

    /**
     * 玩家装载子弹
     */
    private setPlayerFirearmBullet(msg: any[]): void {
        let data: { id: number, type: number } = {
            id: msg[0],
            type: msg[1],
        };

        // console.log(data);

        let player: lPlayer = this.getPlayer(data.id);
        if (player == undefined) {
            return;
        }

        if (player.state != 0) {
            return;
        }

        if (player.firearmList[player.firearmIndex] == undefined) {
            return;
        }

        // 换弹
        if (data.type == 0) {
            if (player.useState == PlayerUseState.None) {
                let bullet: lFirearmBullet = this.getPlayerFirearmBullet(player.bulletList, player.firearmList[player.firearmIndex].bulletType);
                if (bullet != undefined) {
                    let firearm: lFirearm = player.firearmList[player.firearmIndex];
                    if (firearm != undefined) {
                        if (firearm.bulletCount < firearm.bulletMaxCount) {
                            player.useState = PlayerUseState.Reload;
                        }
                    }
                }
            }
        }

        // 取消换弹
        if (data.type == 1) {
            if (player.useState == PlayerUseState.Reload) {
                player.useState = PlayerUseState.None;
                player.firearmList[player.firearmIndex].reloadTime = 0;
            }
        }

        Game.instance.updatePlayerItem(player);
    }

    /**
     * 设置玩家武器索引
     */
    public setPlayerWeaponIndex(msg: any[]): void {
        let data: { id: number, index: number } = {
            id: msg[0],
            index: msg[1],
        };

        let player: lPlayer = this.getPlayer(data.id);
        if (player == undefined) {
            return;
        }

        if (player.firearmList[data.index] == undefined) {
            return;
        }

        if (player.state != 0) {
            return;
        }

        if (player.useState == PlayerUseState.None || player.useState == PlayerUseState.Throwing) {
            if (player.useState == PlayerUseState.Throwing) {
                player.useState = PlayerUseState.None;
            }
            player.firearmIndex = data.index;

            Game.instance.updatePlayerItem(player);
        }
    }

    /**
     * 交换玩家武器索引
     */
    public setWeaponIndexSwap(msg: any[]): void {
        let data: { id: number } = {
            id: msg[0],
        };

        let player: lPlayer = this.getPlayer(data.id);
        if (player == undefined) {
            return;
        }

        if (player.firearmList.length != 2) {
            return;
        }

        if (player.state != 0) {
            return;
        }

        if (player.useState != PlayerUseState.None) {
            return;
        }

        player.firearmList = this.arrIndexA(player.firearmList, 1);

        Game.instance.updatePlayerItem(player);
        if (player.id == Game.instance.uid) {
            Game.instance.updateFirearm(player);
            Game.instance.updateFirearmBullet(player);
            Game.instance.updatePlayerPack(player);
        }
    }

    /**
     * 创建投掷物
     */
    private createThrowingBullet(parentId: number, name: string, teamId: number, type: number, x: number, y: number, width: number, height: number, vectorX: number, vectorY: number, count: number): void {
        let throwingBullet: lThrowingBullet = new lThrowingBullet(this.getId(), parentId, name, teamId, type, x, y, width, height, vectorX, vectorY, count);
        this.throwingBulletList.push(throwingBullet);
        Game.instance.createThrowing(throwingBullet);
    }

    /**
     * 创建玩家
     */
    private createPlayer(msg: any[]): void {
        let data: { id: number, name: string, isRobot: boolean, teamId: number } = {
            id: msg[0],
            name: msg[1],
            isRobot: msg[2],
            teamId: msg[3]
        };

        let player: lPlayer = new lPlayer(data.id, data.name, data.isRobot, 0, data.teamId);

        if (player.isRobot) {
            let name: string = ResourceManager.instance.nameList[this.randomInt(ResourceManager.instance.nameList.length - 1)];
            player.name = name;
        }

        let posX: number = this.randomRange(-9500, 9500);
        let posY: number = this.randomRange(-9500, 9500);
        for (let i: number = 0; i < this.playerList.length; i++) {
            let otherPlayer: lPlayer = this.playerList[i];
            if (otherPlayer.teamId == player.teamId) {
                posX = otherPlayer.x;
                posY = otherPlayer.y;
            }
        }
        player.x = posX;
        player.y = posY;
        // player.x = 0;
        // player.y = 0;

        this.playerList.push(player);

        let helmet: lHelmet = this.getHelmet("helmet_0");
        player.helmetList.push(helmet);

        let armor: lArmor = this.getArmor("armor_0");
        player.armorList.push(armor);

        this.updatePlayerWeight(player);

        Game.instance.createPlayer(player, this.playerList);

        Game.instance.updatePlayerItem(player);
        Game.instance.updatePlayerHelmet(player);
        if (player.id == Game.instance.uid) {
            // for (let i: number = 0; i < 1; i++) {
            //     let type: number = 5;
            //     let item: lItem = this.createItem("firearm_" + type, ItemType.Firearm, 1, posX, posY);
            //     this.createItem("bullet_" + this.getFirearm(item.name).bulletType, ItemType.Bullet, 5, posX + this.randomRange(-100, 100), posY + this.randomRange(-100, 100));
            // }
            Game.instance.updatePickItem(player);
            Game.instance.updatePlayerWeight(player);
            Game.instance.updateMedicine(player.medicineList);
            Game.instance.updateThrowing(player.throwingList);
            Game.instance.updateFirearm(player);
            Game.instance.updateFirearmBullet(player);
            Game.instance.updatePlayerPack(player);
        }
    }

    /**
     * 创建子弹
     */
    private createBullet(parentId: number, teamId: number, type: number, attack: number, x: number, y: number, vectorX: number, vectorY: number, speed: number, count: number): void {
        let bullet: lBullet = new lBullet(this.getId(), parentId, teamId, type, attack, x, y, vectorX, vectorY, speed, count);
        this.bulletList.push(bullet);
        Game.instance.createBullet(bullet);
    }

    /**
     * 创建烟雾
     */
    private createSmoke(x: number, y: number, scale: number): void {
        let smoke: lSmoke = new lSmoke(this.getId(), x, y, scale);
        this.smokeList.push(smoke);
        Game.instance.createSmoke(smoke);
    }

    /**
     * 创建物资
     */
    private createItem(name: string, type: number, count: number, x: number, y: number): lItem {
        let item: lItem = new lItem(this.getId(), type, name, count, x, y);
        this.collidePhysics(item);
        this.itemList.push(item);

        Game.instance.createItem(item);

        return item;
    }

    /**
     * 创建枪械物资
     * @param posX 
     * @param posY 
     * @param type 枪械类型
     * @param bulletCount 子弹数量
     */
    private createFirearm(posX: number, posY: number, type: number, bulletCount: number): void {
        let item: lItem = this.createItem("firearm_" + type, ItemType.Firearm, 1, posX, posY);
        this.createItem("bullet_" + this.getFirearm(item.name).bulletType, ItemType.Bullet, bulletCount, posX + this.randomRange(-100, 100), posY + this.randomRange(-100, 100));
    }

    /**
     * 逻辑数据更新
     */
    private updateData(): void {

        if (!this.isInit) {
            if (this.playerList.length == 48) {
                this.isInit = true;

                Game.instance.initPlayer(this.playerList);
                this.updateSurviveCount();
            }
            return;
        }

        if (this.isOver) {
            return;
        }

        if (this.startCount == 0) {
            this.mpCount += 1;

            this.gameTimeCount++;
            if (this.gameTimeCount == this.gameTimeMaxCount) {
                this.gameTimeCount = 0;
                this.gameTime += 1;
                Game.instance.updateTime(this.gameTime);
            }

            this.robotCount += 1;
            if (this.robotCount == this.robotMaxCount) {
                this.robotCount = 0;
                this.updateRobot();
            }
            this.updateCircle();
            this.updateThrowing();
            this.updateBullet();
            this.updatePlayer();
            this.updateSmoke();

            if (this.mpCount == this.mpMaxCount) {
                this.mpCount = 0;
            }
        } else {
            this.startCount -= 1;
            if (this.startCount == 0) {
                Game.instance.startGame();
            }
        }

    }

    /**
     * 更新毒圈范围
     */
    private updateCircle(): void {
        if (this.circleTime < this.circleMaxTime) {
            this.circleTime += 1;
            if (this.circleTime == this.circleMaxTime) {
                console.log("毒圈开始收缩");
                Game.instance.createLabel("安全区域开始收缩");
                if (this.circleAttack < 200) {
                    this.circleAttack += 5;
                }
            }
        }

        if (this.circleTime == this.circleMaxTime) {
            this.circleCount += 1;
            if (this.circleR > 3) {
                this.circleR -= 3;
                Game.instance.updateCircle(this.circleR);
            }

            if (this.circleCount == this.circleMaxCount) {
                Game.instance.createLabel("安全区域停止收缩");
                console.log("毒圈停止收缩");
                this.circleCount = 0;
                this.circleTime = 0;
            }
        }
    }

    /**
     * 更新玩家逻辑
     */
    private updatePlayer(): void {
        for (let i: number = 0; i < this.playerList.length; i++) {
            let player: lPlayer = this.playerList[i];

            if (player.state == 0 || player.state == 1) {
                // 是否不在安全区域内
                if (this.isCircle(player.x, player.y)) {
                    player.circleCount += 1;
                    if (player.circleCount == player.circleMaxCount) {
                        player.circleCount = 0;
                        if (player.state == 0) {
                            player.hp = this.sub(player.hp, this.circleAttack);
                            if (player.hp <= 0) {
                                this.playerBeat(player, <lPlayer>{ name: "毒圈" });
                            }
                        } else {
                            if (player.state == 1) {
                                player.shp = this.sub(player.shp, this.circleAttack);
                                if (player.shp <= 0) {
                                    this.playerBeat(player, <lPlayer>{ name: "毒圈" });
                                }
                            }
                        }
                    }
                } else {
                    player.circleCount = 0;
                }
            }
            if (player.state == 0) {
                if (this.mpCount == this.mpMaxCount) {
                    if (player.mp > 0 && player.mp < 250) {
                        player.hp = this.add(player.hp, 20);
                    } else {
                        if (player.mp >= 250 && player.mp < 500) {
                            player.hp = this.add(player.hp, 25);
                        } else {
                            if (player.mp >= 500 && player.mp < 750) {
                                player.hp = this.add(player.hp, 30);
                            } else {
                                if (player.mp >= 750) {
                                    player.hp = this.add(player.hp, 35);
                                }
                            }
                        }
                    }

                    player.mp -= 10;

                    this.playerUpdateHpMp(player);
                }
                if (player.useState == PlayerUseState.None) {
                    player.speed = 6;
                }
                if (player.useState == PlayerUseState.Medicine) {
                    player.speed = 2;
                    let medicine: lMedicine = player.medicineList[0];
                    medicine.time += 1;
                    if (medicine.time == medicine.timeMax) {
                        medicine.time = 0;
                        player.useState = PlayerUseState.None;
                        if (medicine.count > 1) {
                            medicine.count -= 1;
                        } else {
                            player.medicineList.splice(0, 1);
                        }

                        if (medicine.name == "medicine_0") {
                            player.hp = this.add(player.hp, 150);
                        }
                        if (medicine.name == "medicine_1") {
                            player.mp = this.add(player.mp, 200);
                        }
                        if (medicine.name == "medicine_2") {
                            player.mp = this.add(player.mp, 350);
                        }
                        this.playerUpdateHpMp(player);
                        this.updatePlayerWeight(player);

                        Game.instance.updatePlayerItem(player);
                        if (player.id == Game.instance.uid) {
                            Game.instance.updateMedicine(player.medicineList);
                            Game.instance.updatePlayerPack(player);
                            Game.instance.updatePlayerWeight(player);
                        }
                    }
                }
                if (player.useState == PlayerUseState.Reload) {
                    let firearm: lFirearm = player.firearmList[player.firearmIndex];
                    let bullet: lFirearmBullet = this.getPlayerFirearmBullet(player.bulletList, firearm.bulletType);
                    if (bullet != undefined) {
                        firearm.reloadTime += 1;
                        if (firearm.reloadTime == firearm.reloadMaxTime) {
                            firearm.reloadTime = 0;

                            let bulletCount: number = firearm.bulletMaxCount - firearm.bulletCount;
                            if (bulletCount < bullet.count) {
                                firearm.bulletCount += bulletCount;
                                bullet.count -= bulletCount;
                            } else {
                                firearm.bulletCount += bullet.count;
                                player.bulletList.splice(player.bulletList.indexOf(bullet), 1);
                            }
                            this.updatePlayerWeight(player);

                            player.useState = PlayerUseState.None;
                            if (player.id == Game.instance.uid) {
                                Game.instance.updateFirearmBullet(player);
                                Game.instance.updatePlayerPack(player);
                                Game.instance.updatePlayerWeight(player);
                            }
                        }
                    }
                }
                if (player.useState == PlayerUseState.Rescue) {
                    let otherPlayer: lPlayer = player.playerList[0];
                    if (otherPlayer != undefined) {
                        if (otherPlayer.state == 1) {
                            otherPlayer.rescueCount += 1;
                            if (otherPlayer.rescueCount == otherPlayer.rescueMaxCount) {
                                otherPlayer.rescueCount = 0;
                                otherPlayer.state = 0;
                                otherPlayer.hp = 200;
                                otherPlayer.speed = 6;
                                player.useState = PlayerUseState.None;
                            }
                        }
                    }
                }
            }

            // 处理玩家移动
            if (player.state != 2) {
                let vectorX: number = this.mul(player.vectorX, player.speed);
                let vectorY: number = this.mul(player.vectorY, player.speed);
                player.x = this.add(player.x, vectorX);
                player.y = this.add(player.y, vectorY);

                this.collidePhysics(player);
            }

            this.objCollisionMap(player);

            for (let j: number = 0; j < this.itemList.length; j++) {
                let item: lItem = this.itemList[j];
                if (this.boxBoxCollision({ x: player.x, y: player.y, width: 175, height: 175 }, { x: item.x, y: item.y, width: 50, height: 50 })) {
                    if (player.itemList.indexOf(item) == -1) {
                        player.itemList.push(item);
                        if (player.id == Game.instance.uid) {
                            Game.instance.updatePickItem(player);
                        }
                    }
                }
            }

            for (let j: number = 0; j < player.itemList.length; j++) {
                let item: lItem = player.itemList[j];
                if (!this.boxBoxCollision({ x: player.x, y: player.y, width: 200, height: 200 }, { x: item.x, y: item.y, width: 50, height: 50 })) {
                    if (player.itemList.indexOf(item) != -1) {
                        player.itemList.splice(j, 1);
                        if (player.id == Game.instance.uid) {
                            Game.instance.updatePickItem(player);
                        }
                    }
                }
            }

            for (let j: number = 0; j < this.playerList.length; j++) {
                let otherPlayer: lPlayer = this.playerList[j];
                if (otherPlayer.id != player.id) {
                    if (otherPlayer.teamId == player.teamId && otherPlayer.state == 1) {
                        if (player.playerList.indexOf(otherPlayer) == -1) {
                            if (this.boxBoxCollision({ x: player.x, y: player.y, width: 100, height: 100 }, { x: otherPlayer.x, y: otherPlayer.y, width: 100, height: 100 })) {
                                player.playerList.push(otherPlayer);
                            }
                        }
                    }
                }
            }

            for (let j: number = 0; j < player.playerList.length; j++) {
                let otherPlayer: lPlayer = player.playerList[j];
                if (!this.boxBoxCollision({ x: player.x, y: player.y, width: 125, height: 125 }, { x: otherPlayer.x, y: otherPlayer.y, width: 125, height: 125 }) || otherPlayer.state == 0) {
                    if (player.useState == PlayerUseState.Rescue) {
                        if (otherPlayer.state == 1) {
                            otherPlayer.rescueCount = 0;
                            player.useState = PlayerUseState.None;
                        }
                    }
                    player.playerList.splice(j, 1);
                }
            }

            // 处理玩家攻击
            if (player.state == 0) {
                if (player.useState == PlayerUseState.None) {
                    let firearm: lFirearm = player.firearmList[player.firearmIndex];
                    if (firearm != undefined) {
                        if (player.isAttack) {
                            if (firearm.attackCount == firearm.attackCountMax) {
                                if (firearm.attackType == 0) {
                                    firearm.attackCount = 0;
                                    if (firearm.bulletCount > 0) {
                                        firearm.bulletCount -= 1;
                                        Game.instance.playerFirearmAudio(0, player.x, player.y);
                                        if (firearm.type == 0 || firearm.type == 3) {
                                            this.createBullet(player.id, player.teamId, firearm.bulletType, firearm.attack, player.x, player.y, player.angleX, player.angleY, firearm.bulletSpeed, firearm.bulletRange);
                                        }
                                        if (player.id == Game.instance.uid) {
                                            Game.instance.updateFirearmBullet(player);
                                            Game.instance.updatePlayerPack(player);
                                        }
                                    }
                                }
                            } else {
                                firearm.attackCount += 1;
                            }
                        } else {
                            firearm.attackCount = 0;
                        }
                    }
                }
            }
        }
    }

    /**
     * 更新机器人逻辑
     */
    private updateRobot(): void {
        for (let i: number = 0; i < this.playerList.length; i++) {
            let player: lPlayer = this.playerList[i];
            if (player.isRobot) {
                if (player.state == 0) {
                    if (this.randomInt(6) < 2) {
                        let angle: number = this.randomRangeInt(-180, 180);
                        let vector: { x: number, y: number } = this.getAngleVector(angle);
                        // this.setPlayerVector([player.id, vector.x, vector.y]);
                        player.vectorX = vector.x;
                        player.vectorY = vector.y;
                    }
                    if (this.randomInt(12) < 8) {
                        let distancePlayers: { player: lPlayer, distance: number }[] = [];

                        for (let j: number = 0; j < this.playerList.length; j++) {
                            let otherPlayer: lPlayer = this.playerList[j];
                            if (otherPlayer.state == 0) {
                                if (otherPlayer.teamId != player.teamId) {
                                    let distance: number = this.distance(player.x, player.y, otherPlayer.x, otherPlayer.y);
                                    if (distance < 640) {
                                        distancePlayers.push({ player: otherPlayer, distance: distance });
                                    }
                                }
                            }
                        }

                        if (distancePlayers.length > 0) {
                            // 排序--->
                            distancePlayers.sort((a: { player: lPlayer, distance: number }, b: { player: lPlayer, distance: number }) => {
                                return a.distance - b.distance;
                            })

                            // console.log(distancePlayers);
                            // 获取最近距离其他玩家
                            let otherPlayer: lPlayer = distancePlayers[0].player;

                            let dirX: number = this.sub(otherPlayer.x, player.x);
                            let dirY: number = this.sub(otherPlayer.y, player.y);

                            let vector: { x: number, y: number } = this.getVector(dirX, dirY);

                            player.isAttack = true;
                            let r: number = Math.atan2(vector.y, vector.x);
                            let angle: number = Math.round(r * 180 / Math.PI);
                            player.angle = angle;
                            player.angleX = vector.x;
                            player.angleY = vector.y;

                            let firearm: lFirearm = player.firearmList[player.firearmIndex];
                            if (firearm != undefined) {
                                if (firearm.attackType == 1) {
                                    if (firearm.attackCount == firearm.attackCountMax) {
                                        this.setPlayerAttack([player.id, 0]);
                                    }
                                }
                            }

                            if (this.randomInt(7) < 4) {
                                if (player.firearmList.length > 0) {
                                    player.vectorX = vector.x;
                                    player.vectorY = vector.y;
                                }
                            }
                        } else {
                            if (this.randomInt(2) != 0) {
                                player.isAttack = false;
                            }
                        }
                    }
                    if (this.randomInt(1) == 1) {
                        if (player.itemList.length > 0) {
                            this.playerPickItem([player.id, 0]);
                        }
                    }
                    if (player.firearmList.length > 0) {
                        let firearm: lFirearm = player.firearmList[player.firearmIndex];
                        if (firearm.reloadTime == 0) {
                            if (firearm.bulletCount == 0) {
                                this.setPlayerFirearmBullet([player.id, 0]);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * 更新子弹逻辑
     */
    private updateBullet(): void {
        for (let i: number = 0; i < this.bulletList.length; i++) {
            let bullet: lBullet = this.bulletList[i];

            if (bullet.count == 0) {
                if (bullet.type == 3) {
                    this.createBullet(bullet.parentId, this.getPlayer(bullet.parentId).teamId, -1, 600, bullet.x, bullet.y, 0, 0, 0, 10);
                }
                Game.instance.removeBullet(bullet);
                this.bulletList.splice(i, 1);
            } else {

                bullet.x = this.add(bullet.x, this.mul(bullet.vectorX, bullet.speed));
                bullet.y = this.add(bullet.y, this.mul(bullet.vectorY, bullet.speed));

                Game.instance.updateBullet(bullet);

                // 处理与玩家碰撞
                for (let i: number = 0; i < this.playerList.length; i++) {
                    let otherPlayer: lPlayer = this.playerList[i];
                    if (bullet.playerIds.indexOf(otherPlayer.id) == -1) {
                        if (otherPlayer.state != 2) {
                            if (this.circleCircleCollision(otherPlayer.x, otherPlayer.y, otherPlayer.width, bullet.x, bullet.y, bullet.width)) {
                                if ((bullet.parentId != otherPlayer.id && bullet.teamId != otherPlayer.teamId) || bullet.type == -1) {
                                    bullet.playerIds.push(otherPlayer.id);
                                    if (otherPlayer.state == 0) {
                                        let attack: number = bullet.attack;
                                        let armorValue: number = 0;
                                        let helmet: lHelmet = otherPlayer.helmetList[0];
                                        if (helmet != undefined) {
                                            armorValue += helmet.armor;
                                        }
                                        let armor: lArmor = otherPlayer.armorList[0];
                                        if (armor != undefined) {
                                            armorValue += armor.armor;
                                        }
                                        // 爆炸类
                                        if (bullet.type == -1) {
                                            if (helmet != undefined) {
                                                if (helmet.type == 2) {
                                                    attack = Math.ceil(this.mul(attack, 0.8));
                                                }
                                            }
                                            if (armor != undefined) {
                                                if (armor.type == 2) {
                                                    attack = Math.ceil(this.mul(attack, 0.8));
                                                }
                                            }
                                        } else {
                                            if (armorValue > 0) {
                                                attack = this.sub(attack, Math.ceil(this.mul(attack, this.mul(armorValue, 0.01))));
                                            }
                                        }
                                        otherPlayer.hp = this.sub(otherPlayer.hp, attack);
                                        if (otherPlayer.hp <= 0) {
                                            this.playerBeat(otherPlayer, this.getPlayer(bullet.parentId));
                                        }
                                    } else {
                                        if (otherPlayer.state == 1) {
                                            let attack: number = bullet.attack;
                                            let armorValue: number = 0;
                                            let helmet: lHelmet = otherPlayer.helmetList[0];
                                            if (helmet != undefined) {
                                                armorValue += helmet.armor;
                                            }
                                            let armor: lArmor = otherPlayer.armorList[0];
                                            if (armor != undefined) {
                                                armorValue += armor.armor;
                                            }
                                            // 爆炸类
                                            if (bullet.type == -1) {
                                                if (helmet != undefined) {
                                                    if (helmet.type == 2) {
                                                        attack = Math.ceil(this.mul(attack, 0.8));
                                                    }
                                                }
                                                if (armor != undefined) {
                                                    if (armor.type == 2) {
                                                        attack = Math.ceil(this.mul(attack, 0.8));
                                                    }
                                                }
                                            } else {
                                                if (armorValue > 0) {
                                                    attack = this.sub(attack, Math.ceil(this.mul(attack, this.mul(armorValue, 0.01))));
                                                }
                                            }
                                            otherPlayer.shp = this.sub(otherPlayer.shp, attack);
                                            if (otherPlayer.shp <= 0) {
                                                this.playerBeat(otherPlayer, this.getPlayer(bullet.parentId));
                                            }
                                        }
                                    }
                                }
                                if (bullet.type > -1) {
                                    if (bullet.parentId != otherPlayer.id) {
                                        if (bullet.count > 1) {
                                            bullet.count = 1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (bullet.type > -1) {
                    if (this.bulletListCollide(bullet)) {
                        if (bullet.count > 1) {
                            bullet.count = 1;
                        }
                    }
                }

                bullet.count--;
            }
        }
    }

    /**
     * 更新投掷物逻辑
     */
    private updateThrowing(): void {
        for (let i: number = 0; i < this.throwingBulletList.length; i++) {
            let throwingBullet: lThrowingBullet = this.throwingBulletList[i];

            if (throwingBullet.count == 0) {
                if (throwingBullet.type == 0) {
                    this.createBullet(throwingBullet.parentId, this.getPlayer(throwingBullet.parentId).teamId, -1, 700, throwingBullet.x, throwingBullet.y, 0, 0, 0, 10);
                } else {
                    if (throwingBullet.type == 1) {
                        for (let i: number = 0; i < 24; i++) {
                            this.createSmoke(throwingBullet.x + this.randomRange(-320, 320), throwingBullet.y + this.randomRange(-320, 320), this.randomRange(0.5, 3));
                        }
                    }
                }

                Game.instance.removeThrowing(throwingBullet);
                this.throwingBulletList.splice(i, 1);
            } else {

                throwingBullet.x = this.add(throwingBullet.x, throwingBullet.vectorX);
                throwingBullet.y = this.add(throwingBullet.y, throwingBullet.vectorY);
                this.objCollisionMap(throwingBullet);

                let count = 0;
                if (this.throwingListCollide(throwingBullet)) {
                    count += 1;
                }

                if (count > 0 || throwingBullet.count < this.frameRate * 2) {
                    throwingBullet.vectorX = 0;
                    throwingBullet.vectorY = 0;
                }

                throwingBullet.count -= 1;
            }
        }
    }

    /**
     * 更新烟雾逻辑
     */
    private updateSmoke(): void {
        for (let i: number = 0; i < this.smokeList.length; i++) {
            let smoke: lSmoke = this.smokeList[i];
            if (smoke.count == smoke.countMax) {
                if (smoke.countOver > 0) {
                    smoke.countOver -= 1;
                    smoke.scale = this.sub(smoke.scale, 0.03);
                    Game.instance.updateSmoke(smoke);
                } else {
                    Game.instance.removeSmoke(smoke);
                    this.smokeList.splice(i, 1);
                }
            } else {
                smoke.count += 1;
                smoke.scale = this.add(smoke.scale, 0.02);
                Game.instance.updateSmoke(smoke);
            }
        }
    }

    /**
     * 更新存活计数
     */
    private updateSurviveCount(): void {

        let count: number = 0;

        for (let i: number = 0; i < this.playerList.length; i++) {
            let player: lPlayer = this.playerList[i];
            if (player.state != 2) {
                count += 1;
            }
        }

        this.surviveCount = count;
        Game.instance.updateSurvive(this.surviveCount);
        console.log("存活: " + this.surviveCount);
    }

    /**
     * 更新玩家背包重量
     */
    private updatePlayerWeight(player: lPlayer): void {
        let weight: number = 0;
        for (let i: number = 0; i < player.medicineList.length; i++) {
            let obj: lMedicine = player.medicineList[i];
            let w: number = this.getWeight(obj);
            weight += w;
        }
        for (let i: number = 0; i < player.throwingList.length; i++) {
            let obj: lThrowing = player.throwingList[i];
            let w: number = this.getWeight(obj);
            weight += w;
        }
        for (let i: number = 0; i < player.bulletList.length; i++) {
            let obj: lFirearmBullet = player.bulletList[i];
            let w: number = this.getWeight(obj);
            weight += w;
        }

        player.weight = weight;
        let weightMax: number = 0;
        let pack: lPack = player.packList[0];
        if (pack != undefined) {
            weightMax = pack.weight;
        }
        player.weightMax = 400 + weightMax;

        if (player.id == Game.instance.uid) {
            Game.instance.updatePlayerWeight(player);
        }
    }

    /**
     * 玩家拾取物资
     */
    private playerPickItem(msg: any[]): void {
        let data: { id: number, index: number } = {
            id: msg[0],
            index: msg[1],
        };

        let player: lPlayer = this.getPlayer(data.id);
        if (player == undefined) {
            return;
        }

        if (player.state != 0) {
            return;
        }

        if (player.useState != PlayerUseState.None && player.useState != PlayerUseState.Throwing) {
            return;
        }

        let item: lItem = player.itemList[data.index];
        if (item == undefined) {
            return;
        }

        let isPick: boolean = true;

        if (item.type == ItemType.Medicine) {
            let medicine: lMedicine = this.getPlayerMedicine(player, item.name);

            let weight: number = this.getWeight(this.getMedicine(item.name, item.count));
            if (this.getIsPlayerWeight(player, weight)) {
                if (medicine == undefined) {
                    medicine = this.getMedicine(item.name, item.count);
                    player.medicineList.push(medicine);
                } else {
                    medicine.count += item.count;
                }
            } else {
                isPick = false;
            }

            if (player.id == Game.instance.uid) {
                Game.instance.updateMedicine(player.medicineList);
            }
        }

        if (item.type == ItemType.Throwing) {
            let throwing: lThrowing = this.getPlayerThrowing(player, item.name);

            let weight: number = this.getWeight(this.getThrowing(item.name, item.count));
            if (this.getIsPlayerWeight(player, weight)) {
                if (throwing == undefined) {
                    throwing = this.getThrowing(item.name, item.count);
                    throwing.parentId = player.id;
                    player.throwingList.push(throwing);
                } else {
                    throwing.count += item.count;
                }
            } else {
                isPick = false;
            }

            if (player.id == Game.instance.uid) {
                Game.instance.updateThrowing(player.throwingList);
            }
        }

        if (item.type == ItemType.Firearm) {
            let firearmCount: number = player.firearmList.length;
            if (firearmCount == 2) {
                let firearm: lFirearm = player.firearmList[player.firearmIndex];
                let firearmItem: lItem = this.createItem(firearm.name, ItemType.Firearm, 1, player.x + this.randomRange(-100, 100), player.y + this.randomRange(-100, 100));
                firearmItem.value = { bulletCount: firearm.bulletCount };

                player.firearmList.splice(player.firearmIndex, 1);
            }

            let firearm: lFirearm = this.getFirearm(item.name);
            if (item.value != undefined) {
                for (let value in item.value) {
                    firearm[value] = item.value[value];
                }
            }

            player.firearmList.push(firearm);

            if (player.firearmIndex == 0 && firearmCount == 2) {
                player.firearmList = this.arrIndexA(player.firearmList, 1);
            }

            Game.instance.updatePlayerItem(player);

            if (player.id == Game.instance.uid) {
                Game.instance.updateFirearm(player);
                Game.instance.updateFirearmBullet(player);
            }

        }

        if (item.type == ItemType.Bullet) {
            let bullet: lFirearmBullet = this.getPlayerBullet(player, item.name);

            let weight: number = this.getWeight(this.getBullet(item.name, item.count));
            if (this.getIsPlayerWeight(player, weight)) {
                if (bullet == undefined) {
                    bullet = this.getBullet(item.name, item.count);
                    player.bulletList.push(bullet);
                } else {
                    bullet.count += item.count;
                }
            } else {
                isPick = false;
            }

            if (player.id == Game.instance.uid) {
                Game.instance.updateFirearmBullet(player);
            }
        }

        if (item.type == ItemType.Helmet) {
            if (player.helmetList.length == 0) {
                let helmet: lHelmet = this.getHelmet(item.name);
                player.helmetList.push(helmet);
            } else {
                let helmet0: lHelmet = player.helmetList[0];
                this.createItem(helmet0.name, ItemType.Helmet, 1, player.x + this.randomRange(-100, 100), player.y + this.randomRange(-100, 100));

                player.helmetList.splice(0, 1);

                let helmet: lHelmet = this.getHelmet(item.name);
                player.helmetList.push(helmet);
            }
            Game.instance.updatePlayerHelmet(player);
        }

        if (item.type == ItemType.Armor) {
            if (player.armorList.length == 0) {
                let armor: lArmor = this.getArmor(item.name);
                player.armorList.push(armor);
            } else {
                let armor0: lArmor = player.armorList[0];
                this.createItem(armor0.name, ItemType.Armor, 1, player.x + this.randomRange(-100, 100), player.y + this.randomRange(-100, 100));

                player.armorList.splice(0, 1);

                let armor: lHelmet = this.getArmor(item.name);
                player.armorList.push(armor);
            }
        }

        if (item.type == ItemType.Pack) {
            if (player.packList.length == 0) {
                let pack: lPack = this.getPack(item.name);
                player.packList.push(pack);
            } else {

                let pack0: lPack = player.packList[0];

                let weight: number = player.weightMax - pack0.weight + this.getPack(item.name).weight;
                if (weight >= player.weight) {
                    this.createItem(pack0.name, ItemType.Pack, 1, player.x + this.randomRange(-100, 100), player.y + this.randomRange(-100, 100));
                    player.packList.splice(0, 1);

                    let pack: lPack = this.getPack(item.name);
                    player.packList.push(pack);
                } else {
                    isPick = false;
                }
            }
        }

        this.updatePlayerWeight(player);

        if (isPick) {

            if (player.id == Game.instance.uid) {
                Game.instance.updatePlayerPack(player);
            }

            Game.instance.removeItem(item.id);

            // 处理被拾取的物资
            for (let i: number = 0; i < this.playerList.length; i++) {
                let otherPlayer: lPlayer = this.playerList[i];
                let index: number = otherPlayer.itemList.indexOf(item);
                if (index != -1) {
                    otherPlayer.itemList.splice(index, 1);
                    if (otherPlayer.id == Game.instance.uid) {
                        Game.instance.updatePickItem(otherPlayer);
                    }
                }
            }

            this.itemList.splice(this.itemList.indexOf(item), 1);
        }
    }

    /**
     * 玩家丢弃物资
     */
    private playerThrowItem(msg: any[]): void {
        let data: { id: number, index: number } = {
            id: msg[0],
            index: msg[1],
        };

        let player: lPlayer = this.getPlayer(data.id);
        if (player == undefined) {
            return;
        }

        if (player.state != 0) {
            return;
        }

        if (player.useState != PlayerUseState.None) {
            return;
        }

        let count: number = 0;

        for (let i: number = 0; i < player.firearmList.length; i++) {
            let firearm: lFirearm = player.firearmList[i];
            if (count == data.index) {
                let posX: number = this.randomRange(-100, 100);
                let posY: number = this.randomRange(-100, 100);
                let firearmItem: lItem = this.createItem(firearm.name, ItemType.Firearm, 1, player.x + posX, player.y + posY);
                firearmItem.value = { bulletCount: firearm.bulletCount };
                player.firearmList.splice(i, 1);

                if (player.firearmIndex == 1) {
                    if (player.firearmList.length == 1) {
                        player.firearmIndex = 0;
                    }
                }

                Game.instance.updatePlayerItem(player);
                if (Game.instance.uid == player.id) {
                    Game.instance.updateFirearm(player);
                    Game.instance.updatePlayerPack(player);
                }
                return;
            }
            count++;
        }

        count = 2;

        for (let i: number = 0; i < player.helmetList.length; i++) {
            let helmet: lHelmet = player.helmetList[i];
            if (count == data.index) {
                let posX: number = this.randomRange(-100, 100);
                let posY: number = this.randomRange(-100, 100);
                this.createItem(helmet.name, ItemType.Helmet, 1, player.x + posX, player.y + posY);
                player.helmetList.splice(i, 1);

                Game.instance.updatePlayerHelmet(player);
                if (Game.instance.uid == player.id) {
                    Game.instance.updatePlayerPack(player);
                }
                return;
            }
            count++;
        }

        count = 3;

        for (let i: number = 0; i < player.armorList.length; i++) {
            let armor: lArmor = player.armorList[i];
            if (count == data.index) {
                let posX: number = this.randomRange(-100, 100);
                let posY: number = this.randomRange(-100, 100);
                this.createItem(armor.name, ItemType.Armor, 1, player.x + posX, player.y + posY);
                player.armorList.splice(i, 1);

                if (Game.instance.uid == player.id) {
                    Game.instance.updatePlayerPack(player);
                }
                return;
            }
            count++;
        }

        count = 4;

        for (let i: number = 0; i < player.packList.length; i++) {
            let pack: lPack = player.packList[i];
            if (count == data.index) {
                let posX: number = this.randomRange(-100, 100);
                let posY: number = this.randomRange(-100, 100);

                let weight: number = player.weightMax - pack.weight;
                if (weight >= player.weight) {
                    this.createItem(pack.name, ItemType.Pack, 1, player.x + posX, player.y + posY);
                    player.packList.splice(i, 1);

                    this.updatePlayerWeight(player);
                    if (Game.instance.uid == player.id) {
                        Game.instance.updatePlayerPack(player);
                    }
                }
                return;
            }
            count++;
        }

        count = 5;

        for (let i: number = 0; i < player.medicineList.length; i++) {
            let medicine: lMedicine = player.medicineList[i];
            if (count == data.index) {
                let posX: number = this.randomRange(-100, 100);
                let posY: number = this.randomRange(-100, 100);
                this.createItem(medicine.name, ItemType.Medicine, medicine.count, player.x + posX, player.y + posY);
                player.medicineList.splice(i, 1);

                this.updatePlayerWeight(player);
                if (Game.instance.uid == player.id) {
                    Game.instance.updateMedicine(player.medicineList);
                    Game.instance.updatePlayerPack(player);
                }
                return;
            }
            count++;
        }

        for (let i: number = 0; i < player.throwingList.length; i++) {
            let throwing: lThrowing = player.throwingList[i];
            if (count == data.index) {
                let posX: number = this.randomRange(-100, 100);
                let posY: number = this.randomRange(-100, 100);
                this.createItem(throwing.name, ItemType.Throwing, throwing.count, player.x + posX, player.y + posY);
                player.throwingList.splice(i, 1);

                this.updatePlayerWeight(player);
                if (Game.instance.uid == player.id) {
                    Game.instance.updateThrowing(player.throwingList);
                    Game.instance.updatePlayerPack(player);
                }
                return;
            }
            count++;
        }

        for (let i: number = 0; i < player.bulletList.length; i++) {
            let bullet: lFirearmBullet = player.bulletList[i];
            if (count == data.index) {
                let posX: number = this.randomRange(-100, 100);
                let posY: number = this.randomRange(-100, 100);
                this.createItem(bullet.name, ItemType.Bullet, bullet.count, player.x + posX, player.y + posY);
                player.bulletList.splice(i, 1);

                this.updatePlayerWeight(player);
                if (Game.instance.uid == player.id) {
                    Game.instance.updateFirearmBullet(player);
                    Game.instance.updatePlayerPack(player);
                }
                return;
            }
            count++;
        }

    }

    /**
     * 玩家操作救助
     */
    private playerRescue(msg: any[]): void {
        let data: { id: number, type: number } = {
            id: msg[0],
            type: msg[1],
        };

        let player: lPlayer = this.getPlayer(data.id);
        if (player == undefined) {
            return;
        }

        if (player.playerList[0] == undefined) {
            return;
        }

        // 取消救助
        if (data.type == 0) {
            player.playerList[0].rescueCount = 0;
            if (player.useState == PlayerUseState.Rescue) {
                player.useState = PlayerUseState.None;
            }
        }

        // 开始救助
        if (data.type == 1) {
            if (player.useState == PlayerUseState.None) {
                player.useState = PlayerUseState.Rescue;
            }
        }
    }

    /**
     * 玩家属性更新
     */
    private playerUpdateHpMp(player: lPlayer): void {
        if (player.hp < 0) {
            player.hp = 0;
        }
        if (player.mp < 0) {
            player.mp = 0;
        }
        if (player.hp > player.hpMax) {
            player.hp = player.hpMax;
        }
        if (player.mp > player.mpMax) {
            player.mp = player.mpMax;
        }
    }

    /**
     * 玩家hp<=0 处理
     * @param beatPlayer 被击倒玩家
     * @param player 玩家
     */
    private playerBeat(beatPlayer: lPlayer, player: lPlayer): void {
        // 队伍存活人数
        // let teamIdCount: number = this.getTeamCount(beatPlayer.teamId);
        let teamIdCount: number = 0;

        // 计算人数 存活(state 0)
        for (let i: number = 0; i < this.playerList.length; i++) {
            let otherPlayer: lPlayer = this.playerList[i];
            if (beatPlayer.teamId == otherPlayer.teamId) {
                if (otherPlayer.hp > 0) {
                    teamIdCount += 1;
                }
            }
        }

        // 还有其他队友存活
        if (teamIdCount > 0) {
            if (beatPlayer.state == 0) {
                beatPlayer.useState = PlayerUseState.None;
                if (beatPlayer.medicineList.length > 0) {
                    beatPlayer.medicineList[0].time = 0;
                }
                beatPlayer.shp = beatPlayer.shpMax;
                beatPlayer.speed = 1;
                beatPlayer.state = 1;
                console.log(beatPlayer.name + " 被" + player.name + " 击倒");
            } else {
                if (beatPlayer.state == 1) {
                    beatPlayer.state = 2;
                    this.playerByBeat(beatPlayer, player);
                }
            }
        } else {
            // 队伍全部被击败
            beatPlayer.state = 2;
            beatPlayer.useState = PlayerUseState.None;
            if (beatPlayer.medicineList.length > 0) {
                beatPlayer.medicineList[0].time = 0;
            }

            // 处理...
            for (let i: number = 0; i < this.playerList.length; i++) {
                let otherPlayer: lPlayer = this.playerList[i];
                if (otherPlayer.teamId == beatPlayer.teamId) {
                    if (otherPlayer.hp <= 0 && otherPlayer.state != 2) {
                        otherPlayer.shp = 0;
                        otherPlayer.state = 2;
                        Game.instance.playerBeat(otherPlayer);

                        if (otherPlayer.id == Game.instance.uid) {
                            Game.instance.playerByBeat(this.surviveCount);
                        }
                    }
                }
            }

            this.playerByBeat(beatPlayer, player);
        }
    }

    /**
     * 玩家被击败
     */
    private playerByBeat(beatPlayer: lPlayer, player: lPlayer): void {
        this.updateSurviveCount();
        console.log(beatPlayer.name + " 被 " + player.name + " 击败");
        Game.instance.createLabel(player.name + " 击败 " + beatPlayer.name);

        Game.instance.playerBeat(beatPlayer);

        let posX: number = beatPlayer.x;
        let posY: number = beatPlayer.y;

        for (let i: number = 0; i < beatPlayer.medicineList.length; i++) {
            let medicine: lMedicine = beatPlayer.medicineList[i];
            this.createItem(medicine.name, ItemType.Medicine, medicine.count, posX, posY);
        }
        for (let i: number = 0; i < beatPlayer.throwingList.length; i++) {
            let throwing: lThrowing = beatPlayer.throwingList[i];
            this.createItem(throwing.name, ItemType.Throwing, throwing.count, posX, posY);
        }
        for (let i: number = 0; i < beatPlayer.firearmList.length; i++) {
            let firearm: lFirearm = beatPlayer.firearmList[i];
            let item: lItem = this.createItem(firearm.name, ItemType.Firearm, 1, posX, posY);
            item.value = { bulletCount: firearm.bulletCount };
        }
        for (let i: number = 0; i < beatPlayer.bulletList.length; i++) {
            let bullet: lFirearmBullet = beatPlayer.bulletList[i];
            this.createItem(bullet.name, ItemType.Bullet, bullet.count, posX, posY);
        }
        for (let i: number = 0; i < beatPlayer.helmetList.length; i++) {
            let helmet: lHelmet = beatPlayer.helmetList[i];
            this.createItem(helmet.name, ItemType.Helmet, 1, posX, posY);
        }
        for (let i: number = 0; i < beatPlayer.armorList.length; i++) {
            let armor: lArmor = beatPlayer.armorList[i];
            this.createItem(armor.name, ItemType.Armor, 1, posX, posY);
        }
        for (let i: number = 0; i < beatPlayer.packList.length; i++) {
            let pack: lPack = beatPlayer.packList[i];
            this.createItem(pack.name, ItemType.Pack, 1, posX, posY);
        }
        // console.log("掉落物资");

        if (Game.instance.uid == beatPlayer.id) {
            Game.instance.playerByBeat(this.surviveCount + 1);
        }

        if (this.surviveCount <= 3) {
            for (let i: number = 0; i < this.playerList.length; i++) {
                let otherPlayer: lPlayer = this.playerList[i];
                if (otherPlayer.state != 2) {
                    let teamCount: number = this.getTeamCount(otherPlayer.teamId);
                    // console.log(teamCount);
                    if (teamCount == this.surviveCount) {
                        if (Game.instance.uid == otherPlayer.id) {
                            Game.instance.playerByBeat(1);
                        }

                        this.isOver = true;
                    }
                }
            }
        }

        if (this.surviveCount <= 1) {
            this.isOver = true;
        }
    }

    /**
     * 固定帧率执行
     */
    private fixedUpdate(): void {
        this.actuatedFrame();
    }

    /**
     * 逻辑层更新
     * @param dt dt
     */
    public update(dt: number) {

        this.dtNum += dt;

        if (this.dtNum >= this.fpsNum) {
            let count: number = Math.floor(this.dtNum / this.fpsNum);

            for (let i: number = 0; i < count; i++) {
                this.fixedUpdate();
            }

            this.dtNum -= count * this.fpsNum;
        }
    }

    /**
     * 是否不在安全区域
     */
    private isCircle(x: number, y: number) {
        let dx: number = -x;
        let dy: number = -y;
        return (this.add(this.mul(dx, dx), this.mul(dy, dy)) > (this.mul(this.circleR, 0.5)) * (this.mul(this.circleR, 0.5)));
    }

    /**
     * 数组索引位 元素 排到第一位
     */
    private arrIndexA(arr: any[], index: number): any[] {
        let arr2: any[] = [];
        arr2.push(arr[index]);
        arr.splice(index, 1);
        for (let i: number = 0; i < arr.length; i++) {
            arr2.push(arr[i]);
        }
        return arr2;
    }

    /**
     * 子弹是否碰撞 玩家
     * @param bullet 子弹
     * @returns 玩家
     */
    private bulletPlayerCollide(bullet: lBullet): lPlayer {
        for (let i: number = 0; i < this.playerList.length; i++) {
            let player: lPlayer = this.playerList[i];
            if (bullet.playerIds.indexOf(player.id) != -1) {
                if (player.state != 2) {
                    if (this.circleCircleCollision(player.x, player.y, player.width, bullet.x, bullet.y, bullet.width)) {
                        return player;
                    }
                }
            }
        }
        return undefined;
    }

    /**
     * 子弹是否碰撞 碰撞列表
     * @param bullet 子弹
     * @returns 是否
     */
    private bulletListCollide(bullet: lBullet): boolean {
        for (let i: number = 0; i < this.collideList.length; i++) {
            let collide: Collide = this.collideList[i];
            if (this.boxBoxCollision({ x: collide.x, y: collide.y, width: collide.width, height: collide.height }, { x: bullet.x, y: bullet.y, width: bullet.width, height: bullet.height })) {
                return true;
            }
        }

        return false;
    }

    /**
    * 投掷物是否碰撞 玩家
    * @param bullet 子弹
    * @returns 玩家
    */
    private throwingPlayerCollide(throwingBullet: lThrowingBullet): boolean {
        for (let i: number = 0; i < this.playerList.length; i++) {
            let player: lPlayer = this.playerList[i];
            if (this.circleCircleCollision(player.x, player.y, player.width, throwingBullet.x, throwingBullet.y, throwingBullet.width)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 投掷物是否碰撞 碰撞列表
     * @param bullet 子弹
     * @returns 是否
     */
    private throwingListCollide(throwingBullet: lThrowingBullet): boolean {
        for (let i: number = 0; i < this.collideList.length; i++) {
            let collide: Collide = this.collideList[i];
            if (this.boxBoxCollision({ x: collide.x, y: collide.y, width: collide.width, height: collide.height }, { x: throwingBullet.x, y: throwingBullet.y, width: throwingBullet.width, height: throwingBullet.height })) {
                return true;
            }
        }

        return false;
    }

    /**
     * 碰撞地图边界处理
     * @param obj 对象
     */
    private objCollisionMap(obj: any): void {
        let width: number = this.mul(obj.width, 0.5);
        let height: number = this.mul(obj.height, 0.5);

        if (this.add(obj.x, width) > this.mapX) {
            obj.x = this.sub(this.mapX, width);
        }
        if (this.sub(obj.x, width) < -this.mapX) {
            obj.x = this.add(-this.mapX, width);
        }
        if (this.add(obj.y, height) > this.mapY) {
            obj.y = this.sub(this.mapY, height);
        }
        if (this.sub(obj.y, height) < -this.mapY) {
            obj.y = this.add(-this.mapY, height);
        }
    }

    /**
     * 碰撞 碰撞列表 处理
     * @param obj 
     */
    private collidePhysics(obj: any): void {
        for (let i: number = 0; i < this.collideList.length; i++) {
            let collide: Collide = this.collideList[i];
            let isCollide: boolean = this.boxBoxCollision({ x: obj.x, y: obj.y, width: obj.width, height: obj.height }, collide);
            if (isCollide) {
                let width1: number = this.mul(obj.width, 0.5);
                let height1: number = this.mul(obj.height, 0.5);
                let width2: number = this.mul(collide.width, 0.5);
                let height2: number = this.mul(collide.height, 0.5);

                let lerfX: number = this.sub(collide.x, width2);
                let rightX: number = this.add(collide.x, width2);
                let upY: number = this.add(collide.y, height2);
                let downY: number = this.sub(collide.y, height2);

                // x轴碰撞
                if (obj.y < upY && obj.y > downY) {
                    if (obj.x < collide.x) {
                        obj.x = this.sub3(collide.x, width1, width2);
                    }
                    if (obj.x > collide.x) {
                        obj.x = this.add3(collide.x, width1, width2);
                    }
                }

                // y轴碰撞
                if (obj.x < rightX && obj.x > lerfX) {
                    if (obj.y < collide.y) {
                        obj.y = this.sub3(collide.y, height1, height2);
                    }
                    if (obj.y > collide.y) {
                        obj.y = this.add3(collide.y, height1, height2);
                    }
                }

            }
        }
    }

    /**
     * 圆形与圆形碰撞检测
     */
    private circleCircleCollision(x1: number, y1: number, r1: number, x2: number, y2: number, r2: number): boolean {

        let isCollision = false;

        let s1: number = this.mul(r1, 0.5);
        let s2: number = this.mul(r2, 0.5);
        let r: number = this.add(s1, s2);

        if (this.distance(x1, y1, x2, y2) < r) {
            isCollision = true;
        }

        return isCollision;
    }

    /**
     * 矩形与圆形碰撞检测
     * @param obj1 矩形
     * @param obj2 圆形
     * @returns 是否发生碰撞 boolean
     */
    private boxCircleCollision(obj1: Collide, obj2: Collide): boolean {

        let isCollision = false;

        let circle: Collide = obj2;
        let rect: Collide = obj1;
        let w: number = this.mul(rect.width, 0.5);
        let h: number = this.mul(rect.height, 0.5);
        let r: number = this.mul(circle.width, 0.5);
        let x: number = this.sub(circle.x, rect.x);
        let y: number = this.sub(circle.y, rect.y);
        let minX: number = Math.min(x, w);
        let maxX: number = Math.max(minX, -w);
        let minY: number = Math.min(y, h);
        let maxY: number = Math.max(minY, -h);

        if (this.add(this.mul(this.sub(maxX, x), this.sub(maxX, x)), this.mul(this.sub(maxY, y), this.sub(maxY, y))) < this.mul(r, r)) {
            isCollision = true;
        }

        return isCollision;
    }

    /**
     * 矩形与矩形碰撞检测
     * @param obj1 矩形1
     * @param obj2 矩形2
     * @returns 是否发生碰撞 boolean
     */
    private boxBoxCollision(obj1: Collide, obj2: Collide): boolean {

        let isCollision = false;

        let width1: number = this.mul(obj1.width, 0.5);
        let height1: number = this.mul(obj1.height, 0.5);
        let width2: number = this.mul(obj2.width, 0.5);
        let height2: number = this.mul(obj2.height, 0.5);

        if (obj1.x > obj2.x && obj2.x < this.sub3(obj1.x, width1, width2)) {
        } else {
            if (obj1.x < obj2.x && obj2.x > this.add3(obj1.x, width1, width2)) {
            } else {
                if (obj1.y > obj2.y && obj2.y < this.sub3(obj1.y, height1, height2)) {
                } else {
                    if (obj1.y < obj2.y && obj2.y > this.add3(obj1.y, height1, height2)) {
                    } else {
                        isCollision = true;
                    }
                }
            }
        }

        return isCollision;
    }

    /**
     * 玩家背包重量可以拾取
     */
    private getIsPlayerWeight(player: lPlayer, weight: number): boolean {
        if (player.weight + weight <= player.weightMax) {
            return true;
        }
        return false;
    }

    /**
     * 获取物资重量
     */
    private getWeight(obj: any): number {
        return obj.weight * obj.count;
    }

    /**
     * 获取药品
     * @param name 名称
     */
    private getMedicine(name: string, count: number): lMedicine {
        for (let i: number = 0; i < this.medicineList.length; i++) {
            let medicine: lMedicine = this.medicineList[i];
            if (medicine.name == name) {

                let copyObj: lMedicine = new lMedicine(0, "", 0, 0, 0);

                for (let value in medicine) {
                    copyObj[value] = medicine[value];
                }

                copyObj.count = count;

                copyObj.id = this.getId();

                return copyObj;
            }
        }
    }

    /**
     * 获取投资物
     * @param name 名称
     */
    private getThrowing(name: string, count: number): lThrowing {
        for (let i: number = 0; i < this.throwingList.length; i++) {
            let throwing: lThrowing = this.throwingList[i];
            if (throwing.name == name) {

                let copyObj: lThrowing = new lThrowing(0, 0, "", 0, 0, 0, 0);

                for (let value in throwing) {
                    copyObj[value] = throwing[value];
                }

                copyObj.count = count;

                copyObj.id = this.getId();

                return copyObj;
            }
        }
    }

    /**
     * 获取子弹
     * @param name 名称
     */
    private getBullet(name: string, count: number): lFirearmBullet {
        for (let i: number = 0; i < this.firearmBulletList.length; i++) {
            let bullet: lFirearmBullet = this.firearmBulletList[i];
            if (bullet.name == name) {

                let copyObj: lFirearmBullet = new lFirearmBullet(0, "", 0, 0, 0);

                for (let value in bullet) {
                    copyObj[value] = bullet[value];
                }

                copyObj.count = count;

                copyObj.id = this.getId();

                return copyObj;
            }
        }
    }

    /**
     * 获取枪械
     * @param name 名称
     */
    private getFirearm(name: string): lFirearm {
        for (let i: number = 0; i < this.firearmList.length; i++) {
            let firearm: lFirearm = this.firearmList[i];
            if (firearm.name == name) {

                let copyObj: lFirearm = new lFirearm(0, "", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

                for (let value in firearm) {
                    copyObj[value] = firearm[value];
                }

                copyObj.id = this.getId();

                return copyObj;
            }
        }
    }

    /**
     * 获取头盔
     * @param name 名称
     */
    private getHelmet(name: string): lHelmet {
        for (let i: number = 0; i < this.helmetList.length; i++) {
            let helmet: lHelmet = this.helmetList[i];
            if (helmet.name == name) {

                let copyObj: lHelmet = new lHelmet(0, "", 0, 0);

                for (let value in helmet) {
                    copyObj[value] = helmet[value];
                }

                copyObj.id = this.getId();

                return copyObj;
            }
        }
    }

    /**
     * 获取盔甲
     * @param name 名称
     */
    private getArmor(name: string): lArmor {
        for (let i: number = 0; i < this.armorList.length; i++) {
            let armor: lArmor = this.armorList[i];
            if (armor.name == name) {

                let copyObj: lArmor = new lArmor(0, "", 0, 0);

                for (let value in armor) {
                    copyObj[value] = armor[value];
                }

                copyObj.id = this.getId();

                return copyObj;
            }
        }
    }

    /**
     * 获取背包
     * @param name 名称
     */
    private getPack(name: string): lPack {
        for (let i: number = 0; i < this.packList.length; i++) {
            let pack: lPack = this.packList[i];
            if (pack.name == name) {

                let copyObj: lPack = new lPack(0, "", 0, 0);

                for (let value in pack) {
                    copyObj[value] = pack[value];
                }

                copyObj.id = this.getId();

                return copyObj;
            }
        }
    }

    /**
     * 获取指定队伍存活数量
     */
    private getTeamCount(teamId: number): number {
        // 队伍存活人数
        let teamIdCount: number = 0;

        // 计算人数
        for (let i: number = 0; i < this.playerList.length; i++) {
            let otherPlayer: lPlayer = this.playerList[i];
            if (otherPlayer.teamId == teamId) {
                if (otherPlayer.state != 2) {
                    teamIdCount += 1;
                }
            }
        }

        return teamIdCount;
    }

    /**
     * 获取玩家背包中枪械的的子弹
     */
    private getPlayerFirearmBullet(bulletList: lFirearmBullet[], type: number): lFirearmBullet {
        for (let i: number = 0; i < bulletList.length; i++) {
            if (bulletList[i].type == type) {
                return bulletList[i];
            }
        }

        return undefined;
    }

    /**
     * 获取玩家背包中的药品
     */
    private getPlayerMedicine(player: lPlayer, name: string): lMedicine {
        for (let i: number = 0; i < player.medicineList.length; i++) {
            let medicine: lMedicine = player.medicineList[i];
            if (medicine.name == name) {
                return medicine;
            }
        }

        return undefined;
    }

    /**
     * 获取玩家背包中的投掷物
     */
    private getPlayerThrowing(player: lPlayer, name: string): lThrowing {
        for (let i: number = 0; i < player.throwingList.length; i++) {
            let throwing: lThrowing = player.throwingList[i];
            if (throwing.name == name) {
                return throwing;
            }
        }

        return undefined;
    }

    /**
     * 获取玩家背包中的子弹
     */
    private getPlayerBullet(player: lPlayer, name: string): lFirearmBullet {
        for (let i: number = 0; i < player.bulletList.length; i++) {
            let bullet: lFirearmBullet = player.bulletList[i];
            if (bullet.name == name) {
                return bullet;
            }
        }

        return undefined;
    }

    /**
     * 求向量
     * @param x x
     * @param y y
     * @returns // { x: vectorX, y: vecotrY }
     */
    private getVector(x: number, y: number): { x: number, y: number } {
        // let vectorX: number = y / (Math.sqrt(x * x + y * y));
        // let vecotrY: number = -x / (Math.sqrt(x * x + y * y));
        let vector: Vec2 = new Vec2(x, y);
        vector.normalize();
        let vectorX: number = Math.floor(vector.x * 1000) / 1000;
        let vecotrY: number = Math.floor(vector.y * 1000) / 1000;
        return { x: vectorX, y: vecotrY };
    }

    /**
     * 修正角度
     * @param angle 角度
     * @returns -180 ~ 180
     */
    private getAngleR(angle: number): number {
        let r: number = angle;
        if (angle > 180) {
            r = -180 + (angle - 180);
        } else {
            if (angle < -180) {
                r = 180 + (angle + 180);
            }
        }

        return r;
    }

    /**
     * 获取唯一id
     */
    private getId(): number {
        this.id++;
        let id: number = this.id;
        return id;
    }

    /**
     * 获取玩家对象
     * @param id 玩家id
     * @returns 玩家对象
     */
    private getPlayer(id: number): lPlayer {
        for (let i: number = 0; i < this.playerList.length; i++) {
            let player: lPlayer = this.playerList[i];
            if (player.id == id) {
                return player;
            }
        }

        return undefined;
    }

    /**
     * 获取指定角度向量
     * @param angle 角度
     * @returns 向量
     */
    private getAngleVector(angle: number): { x: number, y: number } {
        // let r: number = angle / 180 * Math.PI;
        // let v2: Vec2 = new Vec2(Math.cos(r), Math.sin(r));
        // v2.normalize();
        // let dir: { x: number, y: number } = { x: this.floor3(v2.x), y: this.floor3(v2.y) };
        // return dir;
        return this.vectorList[angle];
    }

    /**
     * 随机数
     * @param max 最大数
     * @returns 0 ~ max
     */
    private random(max: number): number {
        this.seed = (this.seed * 9301 + 49297) % 233280;
        let seed_: number = this.seed / 233280.0;
        let value: number = seed_ * max;
        return value;
    }

    /**
     * 随机整数
     * @param max 最大数
     * @returns 0 ~ max
     */
    private randomInt(max: number): number {
        return Math.round(this.random(max));
    }

    /**
     * 指定范围随机数
     * @param min 最小数
     * @param max 最大数
     * @returns min ~ max
     */
    private randomRange(min: number, max: number) {
        let value: number = this.random(max - min) + min;
        return value;
    }

    /**
     * 指定范围随机整数
     * @param min 最小数
     * @param max 最大数
     * @returns min ~ max
     */
    private randomRangeInt(min: number, max: number) {
        return Math.round(this.randomRange(min, max));
    }

    /**
     * 两个坐标之间的距离
     * @param x1 x1坐标
     * @param y1 y1坐标
     * @param x2 x2坐标
     * @param y2 y2坐标
     * @returns 两点距离
     */
    private distance(x1: number, y1: number, x2: number, y2: number): number {
        return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
    }

    /**
     * 获取一个值floor身保留三位小数
     * @param num 值
     * @returns 
     */
    private floor3(num: number): number {
        return Math.floor(num * 1000) / 1000;
    }

    /**
     * 两数相加
     * @param num1 数1
     * @param num2 数2
     * @returns num1 + num2
     */
    private add(num1: number, num2: number): number {
        return Math.floor(num1 * 1000 + num2 * 1000) / 1000;
    }

    /**
     * 三数相加
     * @param num1 数1
     * @param num2 数2
     * @param num3 数3
     * @returns num1 + num2 + num3
     */
    private add3(num1: number, num2: number, num3: number): number {
        return Math.floor(num1 * 1000 + num2 * 1000 + num3 * 1000) / 1000;
    }

    /**
     * 四数相加
     * @param num1 数1
     * @param num2 数2
     * @param num3 数3
     * @param num4 数4
     * @returns num1 + num2 + num3 + num4
     */
    private add4(num1: number, num2: number, num3: number, num4: number): number {
        return Math.floor(num1 * 1000 + num2 * 1000 + num3 * 1000 + num4 * 1000) / 1000;
    }

    /**
     * 两数相减
     * @param num1 数1
     * @param num2 数2
     * @returns num1 - num2
     */
    private sub(num1: number, num2: number): number {
        return Math.floor(num1 * 1000 - num2 * 1000) / 1000;
    }

    /**
     * 三数相减
     * @param num1 数1
     * @param num2 数2
     * @param num3 数3
     * @returns num1 - num2 - num3
     */
    private sub3(num1: number, num2: number, num3: number): number {
        return Math.floor(num1 * 1000 - num2 * 1000 - num3 * 1000) / 1000;
    }

    /**
     * 四数相减
     * @param num1 数1
     * @param num2 数2
     * @param num3 数3
     * @param num4 数4
     * @returns num1 - num2 - num3 - num4
     */
    private sub4(num1: number, num2: number, num3: number, num4: number): number {
        return Math.floor(num1 * 1000 - num2 * 1000 - num3 * 1000 - num4 * 1000) / 1000;
    }

    /**
     * 两数相乘
     * @param num1 数1
     * @param num2 数2
     * @returns num1 * num2
     */
    private mul(num1: number, num2: number): number {
        return Math.floor((num1 * 1000) * (num2 * 1000)) / 1000000;
    }

    /**
     * 两数相除
     * @param num1 数1
     * @param num2 数2
     * @returns num1 / num2
     */
    private div(num1: number, num2: number): number {
        return Math.floor((num1 * 1000) / (num2 * 1000));
    }

    // /**
    //  * 圆形与圆形碰撞检测
    //  */
    // private circleCircleCollision(x1: number, y1: number, r1: number, x2: number, y2: number, r2: number): boolean {
    //     return intersects.circleCircle(x1, y1, this.mul(r1, 0.5), x2, y2, this.mul(r2, 0.5));
    // }

    // /**
    //  * 矩形与圆形碰撞检测
    //  */
    // private boxCircleCollision(x1: number, y1: number, width1: number, height1: number, x2: number, y2: number, r2: number): boolean {
    //     return intersects.boxCircle(this.sub(x1, this.mul(width1, 0.5)), this.sub(y1, this.mul(height1, 0.5)), width1, height1, x2, y2, r2);
    // }

    // /**
    //  * 矩形与矩形碰撞检测
    //  */
    // private boxBoxCollision(x1: number, y1: number, width1: number, height1: number, x2: number, y2: number, width2: number, height2: number): boolean {
    //     return intersects.boxBox(this.sub(x1, this.mul(width1, 0.5)), this.sub(y1, this.mul(height1, 0.5)), width1, height1, this.sub(x2, this.mul(width2, 0.5)), this.sub(y2, this.mul(height2, 0.5)), width2, height2);
    // }

    // /**
    //  * 矩形与线段碰撞检测
    //  */
    // private boxLineCollision(x1: number, y1: number, width1: number, height1: number, x2: number, y2: number, x3: number, y3: number): boolean {
    //     return intersects.boxLine(this.sub(x1, this.mul(width1, 0.5)), this.sub(y1, this.mul(height1, 0.5)), width1, height1, x2, y2, x3, y3);
    // }

    // /**
    //  * 圆形与线段碰撞检测
    //  */
    // private circleLineCollision(x1: number, y1: number, r1: number, x2: number, y2: number, x3: number, y3: number): boolean {
    //     return intersects.circleLine(x1, y1, this.mul(r1, 0.5), x2, y2, x3, y3);
    // }

}
