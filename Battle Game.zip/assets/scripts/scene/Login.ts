
import { _decorator, Component, Node, EditBox } from 'cc';
import { MessageManager } from '../manager/MessageManager';
import { NetManager } from '../manager/NetManager';
import { ResourceManager } from '../manager/ResourceManager';
import { UIManager } from '../manager/UIManager';
const { ccclass, property } = _decorator;

@ccclass('Login')
export class Login extends Component {

    // 登录
    public login(): void {
        let name: string = UIManager.instance.getUI("EditBoxName").getComponent(EditBox).string;
        if (name.length == 0) {
            console.log("昵称不能为空");
            MessageManager.instance.createMessage("昵称不能为空", 0, 1);
            return;
        }
        console.log(name);
        NetManager.instance.login(name);
    }

    public getRandomName(): void {
        UIManager.instance.getUI("EditBoxName").getComponent(EditBox).string = ResourceManager.instance.getRandomName();
    }

}
