export const enum cmd {
	/**
	 * ping测试
	 */
	connector_main_ping = "connector.main.ping",
	/**
	 * 登录
	 */
	connector_main_login = "connector.main.login",
	/**
	 * 队组
	 */
	connector_main_group = "connector.main.group",
	/**
	 * 匹配
	 */
	connector_main_match = "connector.main.match",
	/**
	 * 帧数据
	 */
	connector_main_frame = "connector.main.frame",
	/**
	 * 房间
	 */
	connector_main_room = "connector.main.room",
	/**
	 * 错误码
	 */
	connector_main_error = "connector.main.error",
}