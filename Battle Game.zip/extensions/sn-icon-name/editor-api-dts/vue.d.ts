declare interface vue {
    // shadowRoot?: any;
    el: any;
    data: any;
    methods: any;
    init: ()=> void;
    created: ()=> void;
}