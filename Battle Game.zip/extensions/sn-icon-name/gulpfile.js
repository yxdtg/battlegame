const gulp = require("gulp");
const packageJson = require("./package.json");
const defaultPatterns = ["dist/**/*", "package.json"];
const execa = require("execa");
const path = require("path");

const fs = require("fs");
const clean = require("gulp-clean");
const pkgPath = `publish/${packageJson.name}`;

const publishConfig = require("./publish-pkg.json");

gulp.task("build", async (done) => {
    try {
        console.log(`[publish-pkg]开始构建js`);
        const { stdout } = await execa("npm", ["run", "build"])
        console.log(stdout);
        console.log(`[publish-pkg]构建js结束`);
        done()
    } catch (err) {
        console.log(error);
        done()
    }
});
gulp.task("clean", () => {
    return gulp.src(pkgPath, { allowEmpty: true }).pipe(clean());
});

gulp.task("copy", () => {

    let patterns = publishConfig.files;
    if (!patterns) {
        patterns = defaultPatterns;
    } else {
        let pattern;
        for (let i = 0; i < defaultPatterns.length; i++) {
            pattern = defaultPatterns[i];
            if (!patterns.includes(pattern)) {
                patterns.push(pattern);
            }
        }
    }
    console.log(`[publish-pkg]开始复制文件:${patterns}`);
    return gulp.src(patterns, { base: ".", allowEmpty: true }).pipe(gulp.dest(pkgPath));
});
gulp.task("installDeps", async (done) => {
    const includeDep = publishConfig.includeDep;
    const dependencies = packageJson.dependencies;
    if (!dependencies || Object.keys(dependencies).length <= 0
        || !includeDep || includeDep.length <= 0) {
        done();
    }
    let newDeps;
    if (!includeDep.includes("*")) {
        newDeps = {};
        let key;
        for (let i = 0; i < includeDep.length; i++) {
            key = includeDep[i];
            if (dependencies[key]) {
                newDeps[key] = dependencies[key]
            }
        }
    } else {
        newDeps = dependencies;
    }
    if (!newDeps || Object.keys(newDeps).length <= 0) {
        done();
    }
    packageJson.dependencies = newDeps;
    const newPkgPath = path.join(__dirname, pkgPath, "package.json");
    fs.writeFileSync(newPkgPath, JSON.stringify(packageJson, null, "\t"), { encoding: "utf-8" });

    console.log(`[publish-pkg]开始安装依赖`);
    const installArgs = ["install"];
    if (publishConfig.installRegitstry) {
        installArgs.push("--registry");
        installArgs.push(publishConfig.installRegitstry);

    } else {
        installArgs.push("--registry");
        installArgs.push("https://registry.npm.taobao.org");
    }
    if (publishConfig.onlyDependencies || publishConfig.onlyDependencies === undefined) {
        installArgs.push("--production");
        console.log(`[publish-pkg]:npm依赖:${JSON.stringify(newDeps)}`);
    } else {
        console.log(`[publish-pkg]:npm依赖:${JSON.stringify(Object.assign(newDeps, packageJson.devDependencies))}`);
    }
    try {
        const { stdout } = await execa("npm", installArgs, { cwd: path.join(__dirname, `publish/${packageJson.name}`) });
        console.log(stdout);
        console.log(`[publish-pkg]🔚安装依赖结束`)
        done()
    } catch (err) {
        console.log(`[publish-pkg]❌安装依赖错误`)
        console.log(error);

        done()
    }
});

gulp.task("zip", async (done) => {
    let version = packageJson.version;
    // version = version.replace(/\./g, "-");
    const dirPath = path.join(__dirname, pkgPath);

    const zipFilePath = path.join(__dirname, pkgPath + `_v${version}_.zip`);

    console.log(`[publish-pkg]开始生成压缩包:${zipFilePath}`);
    const compressing = require("compressing");
    await compressing.zip.compressDir(dirPath, zipFilePath);
    // await zipDir(dirPath, zipFilePath);
    console.log(`[publish-pkg]生成压缩包结束`);
    done();

})

gulp.task("default", gulp.series("clean", "build", "copy", "installDeps", "zip"));
// gulp.task("zip",()=>{
//     zlib.zip
// })