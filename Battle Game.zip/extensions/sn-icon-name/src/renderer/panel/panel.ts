import { MainRenderCommon } from '../../common/main-render-common';
import { PanelCommon } from '../panel-common';
import { App } from "@ailhc/egf-core"
// console.log(new App());
let app = new App()

const fs = require("fs");
import panelcss from "./css/panel.css";
import panelHtml from "./html/panel.html";
import { pluginName } from '../../common/const';
(new PanelCommon()).sayCommon("启动插件 游戏名称更改: " + new Date().toLocaleString())
new MainRenderCommon().doSommonCommon()
const panel: Editor.IPanel = {
    // 监听面板事件
    linsteners: {
        // 面板显示的时候触发的钩子
        show() {

        },
        // 面板隐藏的时候触发的钩子
        hide() { },
    },
    /**
     * 面板的内容
     */
    template: panelHtml,
    /**
     * 面板上的样式
     */
    style: panelcss,
    /**
     * 快捷选择器
     */
    $: {
        elem: "div",
        btn: '#btn',
        input_en: "#input_en",
        input_zh: "#input_zh",
        checkbox_translatable: "#checkbox_translatable",
    },
    methods: {
        hello() {

        }
    },
    /**面板启动后触发的钩子函数 */
    ready(): void {
        this.$.btn.addEventListener('confirm', () => {

            let app_name_en: string = this.$.input_en.value;
            let app_name_zh: string = this.$.input_zh.value;
            let app_name_translatable: boolean = this.$.checkbox_translatable.value;
            let count: number = 0;
            if (app_name_en.length == 0) {
                console.log("---请填写游戏名称(en)---");
                count++;
            }
            if (app_name_zh.length == 0) {
                console.log("---请填写游戏名称(zh)---");
                count++;
            }
            console.log("-------");
            if (count == 0) {
                Editor.Message.send(pluginName, 'clicked', [[app_name_en, app_name_zh], app_name_translatable]);
            }
        });
    },
    /**
     * 面板准备关闭的时候会触发的函数，return false 的话，会终止关闭面板
     */
    beforeClose(): boolean {
        return undefined;
    },
    /**面板关闭后的钩子函数 */
    close(): void {
        console.log("关闭插件 游戏名称更改: " + new Date().toLocaleString());
    }
}
module.exports = panel;