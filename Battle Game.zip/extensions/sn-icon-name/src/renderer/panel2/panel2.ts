import { pluginName } from '../../common/const';
import { PanelCommon } from '../panel-common';

// panel/index.js, this filename needs to match the one registered in package.json
import panelcss from "./css/panel2.css";
import panelhtml from "./html/panel2.html"
(new PanelCommon()).sayCommon("启动插件 游戏图标更换: " + new Date().toLocaleString());
const panel2: Editor.IPanel = {
  // 监听面板事件
  linsteners: {
    // 面板显示的时候触发的钩子
    show() {

    },
    // 面板隐藏的时候触发的钩子
    hide() { },
  },
  // css style for panel
  style: panelcss,

  // html template for panel
  template: panelhtml,

  // element and variable binding
  $: {
    elem: "div",
    btn: '#btn',
    icon_48: "#icon_48",
    icon_72: "#icon_72",
    icon_96: "#icon_96",
    icon_144: "#icon_144",
    icon_192: "#icon_192",
    img_48: "#img_48",
    img_72: "#img_72",
    img_96: "#img_96",
    img_144: "#img_144",
    img_192: "#img_192",
  },

  // method executed when template and styles are successfully loaded and initialized
  ready() {

    let bufferList: { [name: string]: Buffer } = {
      "48": undefined,
      "72": undefined,
      "96": undefined,
      "144": undefined,
      "192": undefined,
    };

    let img_48: any = this.$.img_48;
    let img_72: any = this.$.img_72;
    let img_96: any = this.$.img_96;
    let img_144: any = this.$.img_144;
    let img_192: any = this.$.img_192;
    this.$.icon_48.onchange = function (e) {
      let file: any = e.target['files'];
      for (let i = 0; i < file.length; i++) {
        let reader: FileReader = new FileReader();
        let file1: any = file[i];
        reader.readAsDataURL(file1);
        reader.onload = function (result) {
          //reader对象的result属性存储流读取的数据
          let baseData: any = reader.result;
          img_48.innerHTML = '<img src="' + baseData + '" alt=""/>';

          var base64Data = baseData.replace(/^data:image\/\w+;base64,/, "");
          bufferList["48"] = base64Data;
        }
      }
    }
    this.$.icon_72.onchange = function (e) {
      let file: any = e.target['files'];
      for (let i = 0; i < file.length; i++) {
        let reader: FileReader = new FileReader();
        let file1: any = file[i];
        reader.readAsDataURL(file1);
        reader.onload = function (result) {
          //reader对象的result属性存储流读取的数据
          let baseData: any = reader.result;
          img_72.innerHTML = '<img src="' + baseData + '" alt=""/>';

          var base64Data = baseData.replace(/^data:image\/\w+;base64,/, "");
          bufferList["72"] = base64Data;
        }
      }
    }
    this.$.icon_96.onchange = function (e) {
      let file: any = e.target['files'];
      for (let i = 0; i < file.length; i++) {
        let reader: FileReader = new FileReader();
        let file1: any = file[i];
        reader.readAsDataURL(file1);
        reader.onload = function (result) {
          //reader对象的result属性存储流读取的数据
          let baseData: any = reader.result;
          img_96.innerHTML = '<img src="' + baseData + '" alt=""/>';

          var base64Data = baseData.replace(/^data:image\/\w+;base64,/, "");
          bufferList["96"] = base64Data;
        }
      }
    }
    this.$.icon_144.onchange = function (e) {
      let file: any = e.target['files'];
      for (let i = 0; i < file.length; i++) {
        let reader: FileReader = new FileReader();
        let file1: any = file[i];
        reader.readAsDataURL(file1);
        reader.onload = function (result) {
          //reader对象的result属性存储流读取的数据
          let baseData: any = reader.result;
          img_144.innerHTML = '<img src="' + baseData + '" alt=""/>';

          var base64Data = baseData.replace(/^data:image\/\w+;base64,/, "");
          bufferList["144"] = base64Data;
        }
      }
    }
    this.$.icon_192.onchange = function (e) {
      let file: any = e.target['files'];
      for (let i = 0; i < file.length; i++) {
        let reader: FileReader = new FileReader();
        let file1: any = file[i];
        reader.readAsDataURL(file1);
        reader.onload = function (result) {
          //reader对象的result属性存储流读取的数据
          let baseData: any = reader.result;
          img_192.innerHTML = '<img src="' + baseData + '" alt=""/>';

          var base64Data = baseData.replace(/^data:image\/\w+;base64,/, "");
          bufferList["192"] = base64Data;
        }
      }
    }

    this.$.btn.addEventListener('confirm', () => {
      Editor.Message.send(pluginName, "clicked1", [bufferList]);
    });
  },

  /**
     * 面板准备关闭的时候会触发的函数，return false 的话，会终止关闭面板
     */
  beforeClose(): boolean {
    return undefined;
  },
  /**面板关闭后的钩子函数 */
  close(): void {
    console.log("关闭插件 游戏图标更换: " + new Date().toLocaleString());
  },

  // register your ipc messages here
  methods: {
    helloPanel2(event) {

    }
  }
}
module.exports = panel2;