import { app } from "mydog";
import { Lobby } from "./lobby";
import { Player } from "./player";

/**
 * 队组类
 */
export class Group {

    /**
     * 队组最大玩家数量
     */
    public maxPlayer: number = 3;

    /**
     * 队组id
     */
    public id: number = -1;

    /**
     * 队组是否在匹配中
     */
    public isMatch: boolean = false;

    /**
     * 队组玩家列表
     */
    public playerList: Player[] = [];

    constructor(id: number) {
        this.id = id;
    }

    /**
     * 加入玩家对象
     * @param player 玩家对象
     */
    public addPlayer(player: Player): void {
        player.groupId = this.id;
        this.playerList.push(player);
    }

    /**
     * 移除玩家对象
     * @param player 玩家对象
     */
    public removePlayer(player: Player): void {
        let index: number = this.playerList.indexOf(player);
        if (index != -1) {
            player.groupId = -1;
            this.playerList.splice(index, 1);
            if (this.playerList.length == 0) {
                let lobby: Lobby = app.get("Lobby");
                delete lobby.groupList[this.id];
            }
        }
    }

    /**
     * 队组是否可以加入
     * @returns boolean
     */
    public isJoin(): boolean {
        let is: boolean = false;
        if (this.playerList.length < this.maxPlayer) {
            is = true;
        }
        if (this.isMatch) {
            is = false;
        }
        return is;
    }

    /**
     * 队组是否可以离开
     * @returns boolean
     */
    public isLeave(): boolean {
        let is: boolean = false;
        if (!this.isMatch) {
            is = true;
        }
        return is;
    }

}