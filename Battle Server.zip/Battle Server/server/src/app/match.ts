import { app } from "mydog";
import { Lobby } from "./lobby";
import { Player } from "./player";

/**
 * 匹配类
 */
export class Match {

    /**
     * 匹配队列长度
     */
    public matchCount: number = 48;

    /**
     * 匹配id
     */
    public id: number = -1;

    /**
     * 匹配玩家列表
     */
    public playerList: Player[] = [];

    constructor(id: number) {
        this.id = id;
    }

    /**
     * 将队组加入匹配
     * @param players 玩家列表
     */
    public addGroup(players: Player[]): void {
        let lobby: Lobby = app.get("Lobby");
        lobby.getGroup(players[0].groupId).isMatch = true;
        for (let i: number = 0; i < players.length; i++) {
            let player: Player = players[i];
            player.matchId = this.id;
            this.playerList.push(player);
        }
    }

    /**
     * 将队组移除匹配
     * @param players 玩家列表
     */
    public removeGroup(players: Player[]): void {
        let lobby: Lobby = app.get("Lobby");
        lobby.getGroup(players[0].groupId).isMatch = false;

        for (let i: number = 0; i < players.length; i++) {
            let player: Player = players[i];
            player.matchId = -1;
            this.playerList.splice(this.playerList.indexOf(player), 1);
        }

        // if (this.playerList.length == 0) {
        //     delete lobby.matchList[this.id];
        //     return;
        // }

        // 若匹配列队没有真实玩家，则移除匹配列队, 同时移除机器人队组, 和机器人
        let count: number = 0;
        let groupIds: number[] = [];
        let robotIds: number[] = [];
        for (let i: number = 0; i < this.playerList.length; i++) {
            let player: Player = this.playerList[i];
            // 真实玩家
            if (!player.isRobot) {
                count++;
            } else {
                // 机器人
                robotIds.push(player.id);
                groupIds.push(player.groupId);
            }
        }

        // console.log(this.playerList);
        // console.log("Match Count: " + count);
        // console.log(robotIds);

        if (count == 0) {

            // 移除队组
            for (let i: number = 0; i < groupIds.length; i++) {
                let groupId: number = groupIds[i];
                delete lobby.groupList[groupId];
            }

            // 移除机器人
            for (let i: number = 0; i < robotIds.length; i++) {
                let robotId: number = robotIds[i];
                delete lobby.playerList[robotId];
            }

            delete lobby.matchList[this.id];
        }
    }

    /**
     * 是否匹配成功
     */
    public isMatch(): boolean {
        let is: boolean = false;
        if (this.playerList.length == this.matchCount) {
            is = true;
        }
        return is;
    }

}