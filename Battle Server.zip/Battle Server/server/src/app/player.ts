
/**
 * 玩家类
 */
export class Player {

    /**
     * 玩家id
     */
    public id: number = -1;

    /**
     * 玩家昵称
     */
    public name: string = "";

    /**
     * 是否是机器人
     */
    public isRobot: boolean = false;

    /**
     * 心跳
     */
    public heartbeat: number = 60;

    /**
     * 最大心跳
     */
    public maxHeartbeat: number = 60;

    /**
     * 队组id
     */
    public groupId: number = -1;

    /**
     * 匹配id
     */
    public matchId: number = -1;

    /**
     * 房间id
     */
    public roomId: number = -1;

    /**
     * 队伍id
     */
    public teamId: number = -1;

    /**
     * 记录队组id
     */
    public gId: number = -1;

    /**
     * 帧索引
     */
    public frameIndex: number = -1;

    /**
     * 是否是重连状态
     */
    public isReconnect: boolean = false;

    /**
     * 连接状态
     */
    public connectState: boolean = true;

    constructor(id: number, name: string, isRobot: boolean) {
        this.id = id;
        this.name = name;
        this.isRobot = isRobot;
        this.init();
    }

    /**
     * 初始化
     */
    public init(): void {
        this.heartbeat = this.maxHeartbeat;
        this.groupId = -1;
        this.matchId = -1;
        this.roomId = -1;
        this.teamId = -1;
        this.gId = -1;
        this.frameIndex = -1;
        this.isReconnect = false;
        this.connectState = true;
    }

}