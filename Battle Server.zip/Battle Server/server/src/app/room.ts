import { app } from "mydog";
import { cmd } from "../config/cmd";
import { Lobby } from "./lobby";
import { Player } from "./player";

/**
 * 帧数据
 */
type Frame = {
    c: number,
    d: any[]
};

/**
 * 房间类
 */
export class Room {

    /**
     * 房间id
     */
    public id: number = -1;

    /**
     * 房间玩家列表
     */
    public playerList: Player[] = [];

    private seed: number = 999; // 随机数种子
    private frameList: Frame[][] = []; // 帧数据列表
    private frameIndex: number = 0; // 帧索引
    private frameRate: number = 1000 / 20; // 帧速率

    private gameTime: number = (20 * (20 * 60)) + 5; // 游戏时间

    constructor(id: number, players: Player[]) {
        this.id = id;
        this.playerList = players;

        this.init();
    }

    // 初始化
    public init(): void {

        let gIds: number[] = [];

        for (let i: number = 0; i < this.playerList.length; i++) {
            let player: Player = this.playerList[i];
            // console.log(player.gId);
            if (gIds.indexOf(player.gId) == -1) {
                gIds.push(player.gId);
            }
        }

        for (let i: number = 0; i < this.playerList.length; i++) {
            let player: Player = this.playerList[i];
            for (let j: number = 0; j < gIds.length; j++) {
                if (player.gId == gIds[j]) {
                    player.teamId = j;
                }
            }
        }

        // console.log(gIds);

        this.seed = Math.floor(Math.random() * 100000000);

        this.frameList.push([]);

        let frame: Frame = { c: 0, d: [this.seed] };
        this.frameList[this.frameIndex].push(frame);

        for (let i: number = 0; i < this.playerList.length; i++) {
            let player: Player = this.playerList[i];
            player.roomId = this.id;
            let frame: Frame = { c: 1, d: [player.id, player.name, player.isRobot, player.teamId] };
            this.frameList[this.frameIndex].push(frame);
        }

        setTimeout(this.update.bind(this), 1000);
    }



    // 更新房间循环
    public update(): void {

        if (this.gameTime == 0) {
            return;
        }

        setTimeout(this.update.bind(this), this.frameRate);

        this.sendFrame();
        this.updateTime();
    }

    /**
     * 加入帧数据
     * @param frameData 帧数据包
     */
    public addFrame(frameData: Frame[]): void {
        for (let i: number = 0; i < frameData.length; i++) {
            this.frameList[this.frameIndex].push(frameData[i]);
        }
    }

    /**
     * 退出房间
     * @param uid 玩家uid
     */
    public quitRoom(uid: number): void {
        let player: Player = this.getPlayer(uid);
        let index: number = this.playerList.indexOf(player);
        if (index != -1) {
            // console.log("玩家" + uid + "退出房间");
            player.init();
            this.playerList.splice(index, 1);
        }
    }

    /**
     * 断线重连
     * @param uid 玩家uid
     * @param frameIndex 玩家帧索引
     */
    public reconnect(uid: number, frameIndex: number): void {
        let player: Player = this.getPlayer(uid);
        player.connectState = true;
        player.frameIndex = frameIndex;
        player.isReconnect = true;
    }

    /**
     * 发送帧数据
     */
    public sendFrame(): void {
        let uidList: number[] = [];
        let reconnectList: number[] = [];

        for (let i: number = 0; i < this.playerList.length; i++) {
            let player: Player = this.playerList[i];
            if (!player.isRobot) {
                if (!player.isReconnect) {
                    uidList.push(player.id);
                } else {
                    reconnectList.push(player.id);
                }
            }
        }

        if (reconnectList.length > 0) {
            // console.log(reconnectList);
            for (let i: number = 0; i < reconnectList.length; i++) {
                let frameData: Frame[][] = [];

                let player: Player = this.getPlayer(reconnectList[i]);
                // console.log(player);
                for (let j: number = player.frameIndex; j < this.frameList.length; j++) {
                    frameData.push(this.frameList[j]);
                }

                app.sendMsgByUid(cmd.connector_main_room, { type: 1, data: frameData }, [player.id]);

                player.isReconnect = false;
            }
        }
        if (uidList.length > 0) {
            let frameData: Frame[] = this.frameList[this.frameIndex];
            app.sendMsgByUid(cmd.connector_main_frame, { type: 0, data: frameData }, uidList);
        }

        this.frameList.push([]);
        this.frameIndex++;
    }

    /**
     * 更新房间时间
     */
    private updateTime(): void {
        this.gameTime -= 1;
        if (this.gameTime == 0) {
            console.log("游戏结束");

            let lobby: Lobby = app.get("Lobby");

            // 移除机器人
            let uids: number[] = [];
            for (let i: number = 0; i < this.playerList.length; i++) {
                let player: Player = this.playerList[i];
                if (player.isRobot) {
                    uids.push(player.id);
                } else {
                    player.init();
                }
            }
            for (let i: number = 0; i < uids.length; i++) {
                let uid: number = uids[i];
                delete lobby.playerList[uid];
            }

            // 房间销毁
            delete lobby.roomList[this.id];
        }
    }

    /**
     * 获取玩家对象
     * @param uid 玩家uid
     * @returns 玩家对象
     */
    private getPlayer(uid: number): Player {
        let index: number = -1;
        for (let i: number = 0; i < this.playerList.length; i++) {
            let player: Player = this.playerList[i];
            if (player.id == uid) {
                index = i;
                break;
            }
        }

        return this.playerList[index];
    }

}