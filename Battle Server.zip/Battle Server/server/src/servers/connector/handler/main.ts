import { app, Application, Session } from "mydog";
import { Lobby } from "../../../app/lobby";
import { Player } from "../../../app/player";
import { Room } from "../../../app/room";
import { cmd } from "../../../config/cmd";

export default class Handler {
    app: Application;
    lobby: Lobby;
    constructor(app: Application) {
        this.app = app;
        this.lobby = this.app.get("Lobby");
    }

    // ping测试
    public ping(data: any, session: Session, next: Function): void {
        let msgList: string[] = ["uid"];
        let msg: { uid: number } = this.getMsg(data, msgList);
        let player: Player = this.lobby.getPlayer(msg.uid);
        if (player != undefined) {
            player.heartbeat = player.maxHeartbeat;
        }
        next({});
    }

    // 登录
    public login(data: any, session: Session, next: Function): void {
        if (session.uid) {
            console.log("uid已绑定...");
            return;
        }
        let msgList: string[] = ["name"];
        let msg: { name: string } = this.getMsg(data, msgList);
        let uid: number = this.lobby.login(msg.name, next);
        session.bind(uid);
    }

    // 队组
    public group(data: any, session: Session, next: Function): void {
        let msgList: string[] = ["type", "uid", "groupId", "removeId"];
        let msg: { type: number, uid: number, groupId: number, removeId: number } = this.getMsg(data, msgList);
        this.lobby.group(msg);
    }

    // 匹配
    public match(data: any, session: Session, next: Function): void {
        let msgList: string[] = ["type", "uid", "groupId"];
        let msg: { type: number, uid: number, groupId: number } = this.getMsg(data, msgList);
        this.lobby.match(msg);
    }

    // 帧数据
    public frame(data: any): void {
        let msgList: string[] = ["roomId", "data"];
        let msg: { roomId: number, data: any } = this.getMsg(data, msgList);
        this.lobby.frame(msg);
    }

    // 房间
    public room(data: any, session: Session): void {
        let msgList: string[] = ["type", "uid", "name", "roomId", "frame"];
        let msg: { type: number, uid: number, name: string, roomId: number, frame: number } = this.getMsg(data, msgList);

        let type: number = msg.type;
        let uid: number = msg.uid;
        let name: string = msg.name;
        let roomId: number = msg.roomId;
        let frame: number = msg.frame;

        // console.log("room房间", type);
        if (type == 0) {
            // 查询客户端是否存在，存在则断开
            let client: Session = app.getSession(uid);
            if (client != undefined) {
                client.close();
            }

            // 重新绑定uid
            session.bind(uid);

            console.log("roomId: " + roomId);
            // 重连大厅
            if (roomId == -1) {
                console.log("重连大厅");
                // 创建玩家
                this.lobby.createPlayer(uid, name, false);
                let player: Player = this.lobby.getPlayer(uid);

                app.sendMsgByUid(cmd.connector_main_room, { type: 0, data: player }, [uid]);
            } else {
                // 重连房间 未完善 2022年4月2日22:36:30 明天继续 拜拜 晚安
                // 完成 2022年4月3日11:35:45
                console.log("重连房间");
                let room: Room = this.lobby.getRoom(roomId);
                if (room != undefined) {
                    room.reconnect(uid, frame);
                } else {
                    // 房间不存在
                    // 创建玩家
                    this.lobby.createPlayer(uid, name, false);
                    let player: Player = this.lobby.getPlayer(uid);
                    app.sendMsgByUid(cmd.connector_main_room, { type: 2, data: player }, [uid]);
                }
            }

        }

        if (type == 1) {
            let room: Room = this.lobby.getRoom(roomId);
            if (room != undefined) {
                room.quitRoom(uid);
            }
        }
    }

    private getMsg(data: any[], msgList: string[]): any {
        let msg: any = {};
        for (let i: number = 0; i < msgList.length; i++) {
            msg[msgList[i]] = data[i];
        }
        return msg;
    }
}
